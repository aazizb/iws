﻿
namespace IWSProject.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Data.Linq;
    using System.Data.Linq.Mapping;
    using System.Linq;
    using System.Reflection;


    [global::System.Data.Linq.Mapping.DatabaseAttribute(Name = "IWSConnectionString")]
    public partial class IWSDataContext : System.Data.Linq.DataContext
    {

        private static System.Data.Linq.Mapping.MappingSource mappingSource = new AttributeMappingSource();

        #region Extensibility Method Definitions
        partial void OnCreated();
        partial void InsertAccount(Account instance);
        partial void UpdateAccount(Account instance);
        partial void DeleteAccount(Account instance);
        partial void InsertBankStatement(BankStatement instance);
        partial void UpdateBankStatement(BankStatement instance);
        partial void DeleteBankStatement(BankStatement instance);
        partial void InsertAffectationJournal(AffectationJournal instance);
        partial void UpdateAffectationJournal(AffectationJournal instance);
        partial void DeleteAffectationJournal(AffectationJournal instance);
        partial void InsertArticle(Article instance);
        partial void UpdateArticle(Article instance);
        partial void DeleteArticle(Article instance);
        partial void InsertAspNetRole(AspNetRole instance);
        partial void UpdateAspNetRole(AspNetRole instance);
        partial void DeleteAspNetRole(AspNetRole instance);
        partial void InsertAspNetUserClaim(AspNetUserClaim instance);
        partial void UpdateAspNetUserClaim(AspNetUserClaim instance);
        partial void DeleteAspNetUserClaim(AspNetUserClaim instance);
        partial void InsertAspNetUserLogin(AspNetUserLogin instance);
        partial void UpdateAspNetUserLogin(AspNetUserLogin instance);
        partial void DeleteAspNetUserLogin(AspNetUserLogin instance);
        partial void InsertAspNetUserRole(AspNetUserRole instance);
        partial void UpdateAspNetUserRole(AspNetUserRole instance);
        partial void DeleteAspNetUserRole(AspNetUserRole instance);
        partial void InsertAspNetUser(AspNetUser instance);
        partial void UpdateAspNetUser(AspNetUser instance);
        partial void DeleteAspNetUser(AspNetUser instance);
        partial void InsertBank(Bank instance);
        partial void UpdateBank(Bank instance);
        partial void DeleteBank(Bank instance);
        partial void InsertBankAccount(BankAccount instance);
        partial void UpdateBankAccount(BankAccount instance);
        partial void DeleteBankAccount(BankAccount instance);
        partial void InsertBrouillard(Brouillard instance);
        partial void UpdateBrouillard(Brouillard instance);
        partial void DeleteBrouillard(Brouillard instance);
        partial void InsertCash(Cash instance);
        partial void UpdateCash(Cash instance);
        partial void DeleteCash(Cash instance);
        partial void InsertCashLine(CashLine instance);
        partial void UpdateCashLine(CashLine instance);
        partial void DeleteCashLine(CashLine instance);
        partial void InsertCategory(Category instance);
        partial void UpdateCategory(Category instance);
        partial void DeleteCategory(Category instance);
        partial void InsertClassSetup(ClassSetup instance);
        partial void UpdateClassSetup(ClassSetup instance);
        partial void DeleteClassSetup(ClassSetup instance);
        partial void InsertCompany(Company instance);
        partial void UpdateCompany(Company instance);
        partial void DeleteCompany(Company instance);
        partial void InsertCostCenter(CostCenter instance);
        partial void UpdateCostCenter(CostCenter instance);
        partial void DeleteCostCenter(CostCenter instance);
        partial void InsertCurrency(Currency instance);
        partial void UpdateCurrency(Currency instance);
        partial void DeleteCurrency(Currency instance);
        partial void InsertCustomer(Customer instance);
        partial void UpdateCustomer(Customer instance);
        partial void DeleteCustomer(Customer instance);
        partial void InsertDetailCompta(DetailCompta instance);
        partial void UpdateDetailCompta(DetailCompta instance);
        partial void DeleteDetailCompta(DetailCompta instance);
        partial void InsertDetailDetailCompta(DetailDetailCompta instance);
        partial void UpdateDetailDetailCompta(DetailDetailCompta instance);
        partial void DeleteDetailDetailCompta(DetailDetailCompta instance);
        partial void InsertDetailLogistic(DetailLogistic instance);
        partial void UpdateDetailLogistic(DetailLogistic instance);
        partial void DeleteDetailLogistic(DetailLogistic instance);
        partial void InsertFiscalYear(FiscalYear instance);
        partial void UpdateFiscalYear(FiscalYear instance);
        partial void DeleteFiscalYear(FiscalYear instance);
        partial void InsertJournal(Journal instance);
        partial void UpdateJournal(Journal instance);
        partial void DeleteJournal(Journal instance);
        partial void InsertJournalStock(JournalStock instance);
        partial void UpdateJournalStock(JournalStock instance);
        partial void DeleteJournalStock(JournalStock instance);
        partial void InsertLocalization(Localization instance);
        partial void UpdateLocalization(Localization instance);
        partial void DeleteLocalization(Localization instance);
        partial void InsertLogException(LogException instance);
        partial void UpdateLogException(LogException instance);
        partial void DeleteLogException(LogException instance);
        partial void InsertLookupAccountAmount(LookupAccountAmount instance);
        partial void UpdateLookupAccountAmount(LookupAccountAmount instance);
        partial void DeleteLookupAccountAmount(LookupAccountAmount instance);
        partial void InsertMasterCompta(MasterCompta instance);
        partial void UpdateMasterCompta(MasterCompta instance);
        partial void DeleteMasterCompta(MasterCompta instance);
        partial void InsertMasterLogistic(MasterLogistic instance);
        partial void UpdateMasterLogistic(MasterLogistic instance);
        partial void DeleteMasterLogistic(MasterLogistic instance);
        partial void InsertMenu(Menu instance);
        partial void UpdateMenu(Menu instance);
        partial void DeleteMenu(Menu instance);
        partial void InsertPeriodicAccountBalance(PeriodicAccountBalance instance);
        partial void UpdatePeriodicAccountBalance(PeriodicAccountBalance instance);
        partial void DeletePeriodicAccountBalance(PeriodicAccountBalance instance);
        partial void InsertQuantityUnit(QuantityUnit instance);
        partial void UpdateQuantityUnit(QuantityUnit instance);
        partial void DeleteQuantityUnit(QuantityUnit instance);
        partial void InsertStock(Stock instance);
        partial void UpdateStock(Stock instance);
        partial void DeleteStock(Stock instance);
        partial void InsertStore(Store instance);
        partial void UpdateStore(Store instance);
        partial void DeleteStore(Store instance);
        partial void InsertSupplier(Supplier instance);
        partial void UpdateSupplier(Supplier instance);
        partial void DeleteSupplier(Supplier instance);
        partial void InserttempAccountAmount(tempAccountAmount instance);
        partial void UpdatetempAccountAmount(tempAccountAmount instance);
        partial void DeletetempAccountAmount(tempAccountAmount instance);
        partial void InsertTypeBrouillard(TypeBrouillard instance);
        partial void UpdateTypeBrouillard(TypeBrouillard instance);
        partial void DeleteTypeBrouillard(TypeBrouillard instance);
        partial void InsertTypeJournal(TypeJournal instance);
        partial void UpdateTypeJournal(TypeJournal instance);
        partial void DeleteTypeJournal(TypeJournal instance);
        partial void InsertVat(Vat instance);
        partial void UpdateVat(Vat instance);
        partial void DeleteVat(Vat instance);
        #endregion

        public IWSDataContext() :
        base(global::System.Configuration.ConfigurationManager.ConnectionStrings["IWSConnectionString"].ConnectionString, mappingSource)
        {
            OnCreated();
        }
        public IWSDataContext(string connection) :
                base(connection, mappingSource)
        {
            OnCreated();
        }
        public IWSDataContext(IDbConnection connection) :
                base(connection, mappingSource)
        {
            OnCreated();
        }
        public IWSDataContext(string connection, MappingSource mappingSource) :
                base(connection, mappingSource)
        {
            OnCreated();
        }
        public IWSDataContext(IDbConnection connection, MappingSource mappingSource) :
                base(connection, mappingSource)
        {
            OnCreated();
        }

        public System.Data.Linq.Table<Account> Accounts
        {
            get
            {
                return this.GetTable<Account>();
            }
        }

        public System.Data.Linq.Table<BankStatement> BankStatements
        {
            get
            {
                return this.GetTable<BankStatement>();
            }
        }

        public System.Data.Linq.Table<AffectationJournal> AffectationJournals
        {
            get
            {
                return this.GetTable<AffectationJournal>();
            }
        }

        public System.Data.Linq.Table<Article> Articles
        {
            get
            {
                return this.GetTable<Article>();
            }
        }

        public System.Data.Linq.Table<AspNetRole> AspNetRoles
        {
            get
            {
                return this.GetTable<AspNetRole>();
            }
        }

        public System.Data.Linq.Table<AspNetUserClaim> AspNetUserClaims
        {
            get
            {
                return this.GetTable<AspNetUserClaim>();
            }
        }

        public System.Data.Linq.Table<AspNetUserLogin> AspNetUserLogins
        {
            get
            {
                return this.GetTable<AspNetUserLogin>();
            }
        }

        public System.Data.Linq.Table<AspNetUserRole> AspNetUserRoles
        {
            get
            {
                return this.GetTable<AspNetUserRole>();
            }
        }

        public System.Data.Linq.Table<AspNetUser> AspNetUsers
        {
            get
            {
                return this.GetTable<AspNetUser>();
            }
        }

        public System.Data.Linq.Table<Bank> Banks
        {
            get
            {
                return this.GetTable<Bank>();
            }
        }

        public System.Data.Linq.Table<BankAccount> BankAccounts
        {
            get
            {
                return this.GetTable<BankAccount>();
            }
        }

        public System.Data.Linq.Table<Brouillard> Brouillards
        {
            get
            {
                return this.GetTable<Brouillard>();
            }
        }

        public System.Data.Linq.Table<Cash> Cashes
        {
            get
            {
                return this.GetTable<Cash>();
            }
        }

        public System.Data.Linq.Table<CashLine> CashLines
        {
            get
            {
                return this.GetTable<CashLine>();
            }
        }

        public System.Data.Linq.Table<Category> Categories
        {
            get
            {
                return this.GetTable<Category>();
            }
        }

        public System.Data.Linq.Table<ClassSetup> ClassSetups
        {
            get
            {
                return this.GetTable<ClassSetup>();
            }
        }

        public System.Data.Linq.Table<Company> Companies
        {
            get
            {
                return this.GetTable<Company>();
            }
        }

        public System.Data.Linq.Table<CostCenter> CostCenters
        {
            get
            {
                return this.GetTable<CostCenter>();
            }
        }

        public System.Data.Linq.Table<Currency> Currencies
        {
            get
            {
                return this.GetTable<Currency>();
            }
        }

        public System.Data.Linq.Table<Customer> Customers
        {
            get
            {
                return this.GetTable<Customer>();
            }
        }

        public System.Data.Linq.Table<DetailCompta> DetailComptas
        {
            get
            {
                return this.GetTable<DetailCompta>();
            }
        }

        public System.Data.Linq.Table<DetailDetailCompta> DetailDetailComptas
        {
            get
            {
                return this.GetTable<DetailDetailCompta>();
            }
        }

        public System.Data.Linq.Table<DetailLogistic> DetailLogistics
        {
            get
            {
                return this.GetTable<DetailLogistic>();
            }
        }

        public System.Data.Linq.Table<FiscalYear> FiscalYears
        {
            get
            {
                return this.GetTable<FiscalYear>();
            }
        }

        public System.Data.Linq.Table<Journal> Journals
        {
            get
            {
                return this.GetTable<Journal>();
            }
        }

        public System.Data.Linq.Table<JournalStock> JournalStocks
        {
            get
            {
                return this.GetTable<JournalStock>();
            }
        }

        public System.Data.Linq.Table<Localization> Localizations
        {
            get
            {
                return this.GetTable<Localization>();
            }
        }

        public System.Data.Linq.Table<LogException> LogExceptions
        {
            get
            {
                return this.GetTable<LogException>();
            }
        }

        public System.Data.Linq.Table<LookupAccountAmount> LookupAccountAmounts
        {
            get
            {
                return this.GetTable<LookupAccountAmount>();
            }
        }

        public System.Data.Linq.Table<MasterCompta> MasterComptas
        {
            get
            {
                return this.GetTable<MasterCompta>();
            }
        }

        public System.Data.Linq.Table<MasterLogistic> MasterLogistics
        {
            get
            {
                return this.GetTable<MasterLogistic>();
            }
        }

        public System.Data.Linq.Table<Menu> Menus
        {
            get
            {
                return this.GetTable<Menu>();
            }
        }

        public System.Data.Linq.Table<PeriodicAccountBalance> PeriodicAccountBalances
        {
            get
            {
                return this.GetTable<PeriodicAccountBalance>();
            }
        }

        public System.Data.Linq.Table<QuantityUnit> QuantityUnits
        {
            get
            {
                return this.GetTable<QuantityUnit>();
            }
        }

        public System.Data.Linq.Table<Stock> Stocks
        {
            get
            {
                return this.GetTable<Stock>();
            }
        }

        public System.Data.Linq.Table<Store> Stores
        {
            get
            {
                return this.GetTable<Store>();
            }
        }

        public System.Data.Linq.Table<Supplier> Suppliers
        {
            get
            {
                return this.GetTable<Supplier>();
            }
        }

        public System.Data.Linq.Table<tempAccountAmount> tempAccountAmounts
        {
            get
            {
                return this.GetTable<tempAccountAmount>();
            }
        }

        public System.Data.Linq.Table<TypeBrouillard> TypeBrouillards
        {
            get
            {
                return this.GetTable<TypeBrouillard>();
            }
        }

        public System.Data.Linq.Table<TypeJournal> TypeJournals
        {
            get
            {
                return this.GetTable<TypeJournal>();
            }
        }

        public System.Data.Linq.Table<Vat> Vats
        {
            get
            {
                return this.GetTable<Vat>();
            }
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.account1To7")]
        public ISingleResult<account1To7Result> account1To7([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string start, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string end, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string companyid)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), start, end, companyid);
            return ((ISingleResult<account1To7Result>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.ClassAccountBalance")]
        public ISingleResult<ClassAccountBalanceResult> ClassAccountBalance([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "class", DbType = "NVarChar(12)")] string @class, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string start, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string end, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string companyid)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), @class, start, end, companyid);
            return ((ISingleResult<ClassAccountBalanceResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.ClassAccountBalances")]
        public ISingleResult<ClassAccountBalancesResult> ClassAccountBalances([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string start, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string end, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string companyid)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), start, end, companyid);
            return ((ISingleResult<ClassAccountBalancesResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.GetAccountBalance", IsComposable = true)]
        public IQueryable<GetAccountBalanceResult> GetAccountBalance([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string id, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string start, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string end, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string companyid)
        {
            return this.CreateMethodCallQuery<GetAccountBalanceResult>(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), id, start, end, companyid);
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.GetAccountBalances", IsComposable = true)]
        public IQueryable<GetAccountBalancesResult> GetAccountBalances([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "class", DbType = "NVarChar(12)")] string @class, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string start, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string end, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string companyid)
        {
            return this.CreateMethodCallQuery<GetAccountBalancesResult>(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), @class, start, end, companyid);
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.GetBalanceSheetChildren", IsComposable = true)]
        public IQueryable<GetBalanceSheetChildrenResult> GetBalanceSheetChildren([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string id, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string companyid, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "Bit")] System.Nullable<bool> isBalanceSheetAccount)
        {
            return this.CreateMethodCallQuery<GetBalanceSheetChildrenResult>(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), id, companyid, isBalanceSheetAccount);
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.GetChildren", IsComposable = true)]
        public IQueryable<GetChildrenResult> GetChildren([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string id, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string companyid)
        {
            return this.CreateMethodCallQuery<GetChildrenResult>(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), id, companyid);
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.GetParents", IsComposable = true)]
        public IQueryable<GetParentsResult> GetParents([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string id, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string companyid)
        {
            return this.CreateMethodCallQuery<GetParentsResult>(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), id, companyid);
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.LogException")]
        public int LogException([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "Message", DbType = "NVarChar(256)")] string message, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "Type", DbType = "NVarChar(256)")] string type, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "Source", DbType = "NVarChar(256)")] string source, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "URL", DbType = "NVarChar(256)")] string uRL, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "Target", DbType = "NVarChar(256)")] string target, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "ComapnyId", DbType = "NVarChar(6)")] string comapnyId, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "UserName", DbType = "NVarChar(6)")] string userName)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), message, type, source, uRL, target, comapnyId, userName);
            return ((int)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.GetFiscalYears")]
        public ISingleResult<GetFiscalYearsResult> GetFiscalYears([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string companyid)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), companyid);
            return ((ISingleResult<GetFiscalYearsResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.CloseFiscalYear")]
        public ISingleResult<CloseFiscalYearResult> CloseFiscalYear([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string companyId)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), companyId);
            return ((ISingleResult<CloseFiscalYearResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.OpenFiscalYear")]
        public int OpenFiscalYear([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "NStart", DbType = "VarChar(6)")] string nStart, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "NEnd", DbType = "VarChar(6)")] string nEnd, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "CompanyId", DbType = "VarChar(50)")] string companyId, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "Current", DbType = "Bit")] System.Nullable<bool> current, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "Open", DbType = "Bit")] System.Nullable<bool> open)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), nStart, nEnd, companyId, current, open);
            return ((int)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.GetBrouillard")]
        public ISingleResult<GetBrouillardResult> GetBrouillard([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "TypeDoc", DbType = "VarChar(2)")] string typeDoc, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "NumPiece", DbType = "VarChar(15)")] string numPiece, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "CompanyId", DbType = "VarChar(15)")] string companyId, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "ItemId", DbType = "Int")] System.Nullable<int> itemId)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), typeDoc, numPiece, companyId, itemId);
            return ((ISingleResult<GetBrouillardResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.PeriodicBalances")]
        public ISingleResult<PeriodicBalancesResult> PeriodicBalances([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(550)")] string selectedIDs, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(4)")] string companyid)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), selectedIDs, companyid);
            return ((ISingleResult<PeriodicBalancesResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.SetTypeJournal")]
        public int SetTypeJournal([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "VarChar(100)")] string typedoc, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "Int")] System.Nullable<int> transid, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string companyid)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), typedoc, transid, companyid);
            return ((int)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.GetChild", IsComposable = true)]
        public IQueryable<GetChildResult> GetChild([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string classId, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string companyid)
        {
            return this.CreateMethodCallQuery<GetChildResult>(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), classId, companyid);
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.ClassChildren")]
        public ISingleResult<ClassChildrenResult> ClassChildren([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string classId, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string company)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), classId, company);
            return ((ISingleResult<ClassChildrenResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.ClassChild")]
        public ISingleResult<ClassChildResult> ClassChild([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string classId, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string company)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), classId, company);
            return ((ISingleResult<ClassChildResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.AccountBalance")]
        public ISingleResult<AccountBalanceResult> AccountBalance([global::System.Data.Linq.Mapping.ParameterAttribute(Name = "class", DbType = "NVarChar(50)")] string @class, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string start, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string end, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string companyid, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "Bit")] System.Nullable<bool> isBalance)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), @class, start, end, companyid, isBalance);
            return ((ISingleResult<AccountBalanceResult>)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.SetJournal")]
        public int SetJournal([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "Int")] System.Nullable<int> transid, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(50)")] string companyid)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), transid, companyid);
            return ((int)(result.ReturnValue));
        }

        [global::System.Data.Linq.Mapping.FunctionAttribute(Name = "dbo.GetJournal")]
        public ISingleResult<GetJournalResult> GetJournal([global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string start, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(6)")] string end, [global::System.Data.Linq.Mapping.ParameterAttribute(DbType = "NVarChar(5)")] string uiculture, [global::System.Data.Linq.Mapping.ParameterAttribute(Name = "Companyid", DbType = "NVarChar(6)")] string companyid)
        {
            IExecuteResult result = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), start, end, uiculture, companyid);
            return ((ISingleResult<GetJournalResult>)(result.ReturnValue));
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Account")]
    public partial class Account : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _id;

        private string _name;

        private string _description;

        private System.DateTime _dateofopen;

        private System.DateTime _dateofclose;

        private decimal _balance;

        private string _CompanyID;

        private string _ParentId;

        private bool _IsUsed;

        private bool _IsBalanceSheetAccount;

        private System.DateTime _Posted;

        private System.DateTime _Updated;

        private string _TypeJournal;

        private int _ModelId;

        private bool _IsResultAccount;

        private EntitySet<AffectationJournal> _AffectationJournals;

        private EntitySet<AffectationJournal> _AffectationJournals1;

        private EntitySet<ClassSetup> _ClassSetups;

        private EntitySet<CostCenter> _CostCenters;

        private EntitySet<DetailCompta> _DetailComptas;

        private EntitySet<DetailCompta> _DetailComptas1;

        private EntitySet<Journal> _Journals;

        private EntitySet<Journal> _Journals1;

        private EntitySet<MasterCompta> _MasterComptas;

        private EntitySet<PeriodicAccountBalance> _PeriodicAccountBalances;

        private EntitySet<Store> _Stores;

        private EntityRef<TypeJournal> _TypeJournal1;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(string value);
        partial void OnidChanged();
        partial void OnnameChanging(string value);
        partial void OnnameChanged();
        partial void OndescriptionChanging(string value);
        partial void OndescriptionChanged();
        partial void OndateofopenChanging(System.DateTime value);
        partial void OndateofopenChanged();
        partial void OndateofcloseChanging(System.DateTime value);
        partial void OndateofcloseChanged();
        partial void OnbalanceChanging(decimal value);
        partial void OnbalanceChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnParentIdChanging(string value);
        partial void OnParentIdChanged();
        partial void OnIsUsedChanging(bool value);
        partial void OnIsUsedChanged();
        partial void OnIsBalanceSheetAccountChanging(bool value);
        partial void OnIsBalanceSheetAccountChanged();
        partial void OnPostedChanging(System.DateTime value);
        partial void OnPostedChanged();
        partial void OnUpdatedChanging(System.DateTime value);
        partial void OnUpdatedChanged();
        partial void OnTypeJournalChanging(string value);
        partial void OnTypeJournalChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        partial void OnIsResultAccountChanging(bool value);
        partial void OnIsResultAccountChanged();
        #endregion

        public Account()
        {
            this._AffectationJournals = new EntitySet<AffectationJournal>(new Action<AffectationJournal>(this.attach_AffectationJournals), new Action<AffectationJournal>(this.detach_AffectationJournals));
            this._AffectationJournals1 = new EntitySet<AffectationJournal>(new Action<AffectationJournal>(this.attach_AffectationJournals1), new Action<AffectationJournal>(this.detach_AffectationJournals1));
            this._ClassSetups = new EntitySet<ClassSetup>(new Action<ClassSetup>(this.attach_ClassSetups), new Action<ClassSetup>(this.detach_ClassSetups));
            this._CostCenters = new EntitySet<CostCenter>(new Action<CostCenter>(this.attach_CostCenters), new Action<CostCenter>(this.detach_CostCenters));
            this._DetailComptas = new EntitySet<DetailCompta>(new Action<DetailCompta>(this.attach_DetailComptas), new Action<DetailCompta>(this.detach_DetailComptas));
            this._DetailComptas1 = new EntitySet<DetailCompta>(new Action<DetailCompta>(this.attach_DetailComptas1), new Action<DetailCompta>(this.detach_DetailComptas1));
            this._Journals = new EntitySet<Journal>(new Action<Journal>(this.attach_Journals), new Action<Journal>(this.detach_Journals));
            this._Journals1 = new EntitySet<Journal>(new Action<Journal>(this.attach_Journals1), new Action<Journal>(this.detach_Journals1));
            this._MasterComptas = new EntitySet<MasterCompta>(new Action<MasterCompta>(this.attach_MasterComptas), new Action<MasterCompta>(this.detach_MasterComptas));
            this._PeriodicAccountBalances = new EntitySet<PeriodicAccountBalance>(new Action<PeriodicAccountBalance>(this.attach_PeriodicAccountBalances), new Action<PeriodicAccountBalance>(this.detach_PeriodicAccountBalances));
            this._Stores = new EntitySet<Store>(new Action<Store>(this.attach_Stores), new Action<Store>(this.detach_Stores));
            this._TypeJournal1 = default(EntityRef<TypeJournal>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this.OnnameChanging(value);
                    this.SendPropertyChanging();
                    this._name = value;
                    this.SendPropertyChanged("name");
                    this.OnnameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_description", DbType = "NVarChar(255)")]
        public string description
        {
            get
            {
                return this._description;
            }
            set
            {
                if ((this._description != value))
                {
                    this.OndescriptionChanging(value);
                    this.SendPropertyChanging();
                    this._description = value;
                    this.SendPropertyChanged("description");
                    this.OndescriptionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_dateofopen", DbType = "DateTime2 NOT NULL")]
        public System.DateTime dateofopen
        {
            get
            {
                return this._dateofopen;
            }
            set
            {
                if ((this._dateofopen != value))
                {
                    this.OndateofopenChanging(value);
                    this.SendPropertyChanging();
                    this._dateofopen = value;
                    this.SendPropertyChanged("dateofopen");
                    this.OndateofopenChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_dateofclose", DbType = "DateTime2 NOT NULL")]
        public System.DateTime dateofclose
        {
            get
            {
                return this._dateofclose;
            }
            set
            {
                if ((this._dateofclose != value))
                {
                    this.OndateofcloseChanging(value);
                    this.SendPropertyChanging();
                    this._dateofclose = value;
                    this.SendPropertyChanged("dateofclose");
                    this.OndateofcloseChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_balance", DbType = "Money NOT NULL")]
        public decimal balance
        {
            get
            {
                return this._balance;
            }
            set
            {
                if ((this._balance != value))
                {
                    this.OnbalanceChanging(value);
                    this.SendPropertyChanging();
                    this._balance = value;
                    this.SendPropertyChanged("balance");
                    this.OnbalanceChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ParentId", DbType = "NVarChar(50)")]
        public string ParentId
        {
            get
            {
                return this._ParentId;
            }
            set
            {
                if ((this._ParentId != value))
                {
                    this.OnParentIdChanging(value);
                    this.SendPropertyChanging();
                    this._ParentId = value;
                    this.SendPropertyChanged("ParentId");
                    this.OnParentIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsUsed", DbType = "Bit NOT NULL")]
        public bool IsUsed
        {
            get
            {
                return this._IsUsed;
            }
            set
            {
                if ((this._IsUsed != value))
                {
                    this.OnIsUsedChanging(value);
                    this.SendPropertyChanging();
                    this._IsUsed = value;
                    this.SendPropertyChanged("IsUsed");
                    this.OnIsUsedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsBalanceSheetAccount", DbType = "Bit NOT NULL")]
        public bool IsBalanceSheetAccount
        {
            get
            {
                return this._IsBalanceSheetAccount;
            }
            set
            {
                if ((this._IsBalanceSheetAccount != value))
                {
                    this.OnIsBalanceSheetAccountChanging(value);
                    this.SendPropertyChanging();
                    this._IsBalanceSheetAccount = value;
                    this.SendPropertyChanged("IsBalanceSheetAccount");
                    this.OnIsBalanceSheetAccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Posted", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Posted
        {
            get
            {
                return this._Posted;
            }
            set
            {
                if ((this._Posted != value))
                {
                    this.OnPostedChanging(value);
                    this.SendPropertyChanging();
                    this._Posted = value;
                    this.SendPropertyChanged("Posted");
                    this.OnPostedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Updated", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Updated
        {
            get
            {
                return this._Updated;
            }
            set
            {
                if ((this._Updated != value))
                {
                    this.OnUpdatedChanging(value);
                    this.SendPropertyChanging();
                    this._Updated = value;
                    this.SendPropertyChanged("Updated");
                    this.OnUpdatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TypeJournal", DbType = "VarChar(50)")]
        public string TypeJournal
        {
            get
            {
                return this._TypeJournal;
            }
            set
            {
                if ((this._TypeJournal != value))
                {
                    if (this._TypeJournal1.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnTypeJournalChanging(value);
                    this.SendPropertyChanging();
                    this._TypeJournal = value;
                    this.SendPropertyChanged("TypeJournal");
                    this.OnTypeJournalChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsResultAccount", DbType = "Bit NOT NULL")]
        public bool IsResultAccount
        {
            get
            {
                return this._IsResultAccount;
            }
            set
            {
                if ((this._IsResultAccount != value))
                {
                    this.OnIsResultAccountChanging(value);
                    this.SendPropertyChanging();
                    this._IsResultAccount = value;
                    this.SendPropertyChanged("IsResultAccount");
                    this.OnIsResultAccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_AffectationJournal", Storage = "_AffectationJournals", ThisKey = "id", OtherKey = "AccountID")]
        public EntitySet<AffectationJournal> AffectationJournals
        {
            get
            {
                return this._AffectationJournals;
            }
            set
            {
                this._AffectationJournals.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_AffectationJournal1", Storage = "_AffectationJournals1", ThisKey = "id", OtherKey = "OAccountID")]
        public EntitySet<AffectationJournal> AffectationJournals1
        {
            get
            {
                return this._AffectationJournals1;
            }
            set
            {
                this._AffectationJournals1.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_ClassSetup", Storage = "_ClassSetups", ThisKey = "id", OtherKey = "ClassID")]
        public EntitySet<ClassSetup> ClassSetups
        {
            get
            {
                return this._ClassSetups;
            }
            set
            {
                this._ClassSetups.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_CostCenter", Storage = "_CostCenters", ThisKey = "id", OtherKey = "accountid")]
        public EntitySet<CostCenter> CostCenters
        {
            get
            {
                return this._CostCenters;
            }
            set
            {
                this._CostCenters.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_DetailCompta", Storage = "_DetailComptas", ThisKey = "id", OtherKey = "account")]
        public EntitySet<DetailCompta> DetailComptas
        {
            get
            {
                return this._DetailComptas;
            }
            set
            {
                this._DetailComptas.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_DetailCompta1", Storage = "_DetailComptas1", ThisKey = "id", OtherKey = "oaccount")]
        public EntitySet<DetailCompta> DetailComptas1
        {
            get
            {
                return this._DetailComptas1;
            }
            set
            {
                this._DetailComptas1.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_Journal", Storage = "_Journals", ThisKey = "id", OtherKey = "Account")]
        public EntitySet<Journal> Journals
        {
            get
            {
                return this._Journals;
            }
            set
            {
                this._Journals.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_Journal1", Storage = "_Journals1", ThisKey = "id", OtherKey = "OAccount")]
        public EntitySet<Journal> Journals1
        {
            get
            {
                return this._Journals1;
            }
            set
            {
                this._Journals1.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_MasterCompta", Storage = "_MasterComptas", ThisKey = "id", OtherKey = "account")]
        public EntitySet<MasterCompta> MasterComptas
        {
            get
            {
                return this._MasterComptas;
            }
            set
            {
                this._MasterComptas.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_PeriodicAccountBalance", Storage = "_PeriodicAccountBalances", ThisKey = "id", OtherKey = "AccountId")]
        public EntitySet<PeriodicAccountBalance> PeriodicAccountBalances
        {
            get
            {
                return this._PeriodicAccountBalances;
            }
            set
            {
                this._PeriodicAccountBalances.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_Store", Storage = "_Stores", ThisKey = "id", OtherKey = "accountid")]
        public EntitySet<Store> Stores
        {
            get
            {
                return this._Stores;
            }
            set
            {
                this._Stores.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "TypeJournal_Account", Storage = "_TypeJournal1", ThisKey = "TypeJournal", OtherKey = "Id", IsForeignKey = true)]
        public TypeJournal TypeJournal1
        {
            get
            {
                return this._TypeJournal1.Entity;
            }
            set
            {
                TypeJournal previousValue = this._TypeJournal1.Entity;
                if (((previousValue != value)
                            || (this._TypeJournal1.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._TypeJournal1.Entity = null;
                        previousValue.Accounts.Remove(this);
                    }
                    this._TypeJournal1.Entity = value;
                    if ((value != null))
                    {
                        value.Accounts.Add(this);
                        this._TypeJournal = value.Id;
                    }
                    else
                    {
                        this._TypeJournal = default(string);
                    }
                    this.SendPropertyChanged("TypeJournal1");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_AffectationJournals(AffectationJournal entity)
        {
            this.SendPropertyChanging();
            entity.Account = this;
        }

        private void detach_AffectationJournals(AffectationJournal entity)
        {
            this.SendPropertyChanging();
            entity.Account = null;
        }

        private void attach_AffectationJournals1(AffectationJournal entity)
        {
            this.SendPropertyChanging();
            entity.Account1 = this;
        }

        private void detach_AffectationJournals1(AffectationJournal entity)
        {
            this.SendPropertyChanging();
            entity.Account1 = null;
        }

        private void attach_ClassSetups(ClassSetup entity)
        {
            this.SendPropertyChanging();
            entity.Account = this;
        }

        private void detach_ClassSetups(ClassSetup entity)
        {
            this.SendPropertyChanging();
            entity.Account = null;
        }

        private void attach_CostCenters(CostCenter entity)
        {
            this.SendPropertyChanging();
            entity.Account = this;
        }

        private void detach_CostCenters(CostCenter entity)
        {
            this.SendPropertyChanging();
            entity.Account = null;
        }

        private void attach_DetailComptas(DetailCompta entity)
        {
            this.SendPropertyChanging();
            entity.Account1 = this;
        }

        private void detach_DetailComptas(DetailCompta entity)
        {
            this.SendPropertyChanging();
            entity.Account1 = null;
        }

        private void attach_DetailComptas1(DetailCompta entity)
        {
            this.SendPropertyChanging();
            entity.Account2 = this;
        }

        private void detach_DetailComptas1(DetailCompta entity)
        {
            this.SendPropertyChanging();
            entity.Account2 = null;
        }

        private void attach_Journals(Journal entity)
        {
            this.SendPropertyChanging();
            entity.Account1 = this;
        }

        private void detach_Journals(Journal entity)
        {
            this.SendPropertyChanging();
            entity.Account1 = null;
        }

        private void attach_Journals1(Journal entity)
        {
            this.SendPropertyChanging();
            entity.Account2 = this;
        }

        private void detach_Journals1(Journal entity)
        {
            this.SendPropertyChanging();
            entity.Account2 = null;
        }

        private void attach_MasterComptas(MasterCompta entity)
        {
            this.SendPropertyChanging();
            entity.Account1 = this;
        }

        private void detach_MasterComptas(MasterCompta entity)
        {
            this.SendPropertyChanging();
            entity.Account1 = null;
        }

        private void attach_PeriodicAccountBalances(PeriodicAccountBalance entity)
        {
            this.SendPropertyChanging();
            entity.Account = this;
        }

        private void detach_PeriodicAccountBalances(PeriodicAccountBalance entity)
        {
            this.SendPropertyChanging();
            entity.Account = null;
        }

        private void attach_Stores(Store entity)
        {
            this.SendPropertyChanging();
            entity.Account = this;
        }

        private void detach_Stores(Store entity)
        {
            this.SendPropertyChanging();
            entity.Account = null;
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.BankStatement")]
    public partial class BankStatement : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _id;

        private string _Auftragskonto;

        private System.Nullable<System.DateTime> _Buchungstag;

        private System.Nullable<System.DateTime> _Valutadatum;

        private string _Buchungstext;

        private string _Verwendungszweck;

        private string _BeguenstigterZahlungspflichtiger;

        private string _Kontonummer;

        private string _BLZ;

        private System.Nullable<decimal> _Betrag;

        private string _Waehrung;

        private string _Info;

        private string _CompanyID;

        private string _CompanyIBAN;

        private System.Nullable<bool> _IsValidated;

        private System.Nullable<int> _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(int value);
        partial void OnidChanged();
        partial void OnAuftragskontoChanging(string value);
        partial void OnAuftragskontoChanged();
        partial void OnBuchungstagChanging(System.Nullable<System.DateTime> value);
        partial void OnBuchungstagChanged();
        partial void OnValutadatumChanging(System.Nullable<System.DateTime> value);
        partial void OnValutadatumChanged();
        partial void OnBuchungstextChanging(string value);
        partial void OnBuchungstextChanged();
        partial void OnVerwendungszweckChanging(string value);
        partial void OnVerwendungszweckChanged();
        partial void OnBeguenstigterZahlungspflichtigerChanging(string value);
        partial void OnBeguenstigterZahlungspflichtigerChanged();
        partial void OnKontonummerChanging(string value);
        partial void OnKontonummerChanged();
        partial void OnBLZChanging(string value);
        partial void OnBLZChanged();
        partial void OnBetragChanging(System.Nullable<decimal> value);
        partial void OnBetragChanged();
        partial void OnWaehrungChanging(string value);
        partial void OnWaehrungChanged();
        partial void OnInfoChanging(string value);
        partial void OnInfoChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnCompanyIBANChanging(string value);
        partial void OnCompanyIBANChanged();
        partial void OnIsValidatedChanging(System.Nullable<bool> value);
        partial void OnIsValidatedChanged();
        partial void OnModelIdChanging(System.Nullable<int> value);
        partial void OnModelIdChanged();
        #endregion

        public BankStatement()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Auftragskonto", DbType = "NVarChar(50)")]
        public string Auftragskonto
        {
            get
            {
                return this._Auftragskonto;
            }
            set
            {
                if ((this._Auftragskonto != value))
                {
                    this.OnAuftragskontoChanging(value);
                    this.SendPropertyChanging();
                    this._Auftragskonto = value;
                    this.SendPropertyChanged("Auftragskonto");
                    this.OnAuftragskontoChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Buchungstag", DbType = "DateTime")]
        public System.Nullable<System.DateTime> Buchungstag
        {
            get
            {
                return this._Buchungstag;
            }
            set
            {
                if ((this._Buchungstag != value))
                {
                    this.OnBuchungstagChanging(value);
                    this.SendPropertyChanging();
                    this._Buchungstag = value;
                    this.SendPropertyChanged("Buchungstag");
                    this.OnBuchungstagChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Valutadatum", DbType = "DateTime")]
        public System.Nullable<System.DateTime> Valutadatum
        {
            get
            {
                return this._Valutadatum;
            }
            set
            {
                if ((this._Valutadatum != value))
                {
                    this.OnValutadatumChanging(value);
                    this.SendPropertyChanging();
                    this._Valutadatum = value;
                    this.SendPropertyChanged("Valutadatum");
                    this.OnValutadatumChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Buchungstext", DbType = "NVarChar(200)")]
        public string Buchungstext
        {
            get
            {
                return this._Buchungstext;
            }
            set
            {
                if ((this._Buchungstext != value))
                {
                    this.OnBuchungstextChanging(value);
                    this.SendPropertyChanging();
                    this._Buchungstext = value;
                    this.SendPropertyChanged("Buchungstext");
                    this.OnBuchungstextChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Verwendungszweck", DbType = "NVarChar(250)")]
        public string Verwendungszweck
        {
            get
            {
                return this._Verwendungszweck;
            }
            set
            {
                if ((this._Verwendungszweck != value))
                {
                    this.OnVerwendungszweckChanging(value);
                    this.SendPropertyChanging();
                    this._Verwendungszweck = value;
                    this.SendPropertyChanged("Verwendungszweck");
                    this.OnVerwendungszweckChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_BeguenstigterZahlungspflichtiger", DbType = "NVarChar(250)")]
        public string BeguenstigterZahlungspflichtiger
        {
            get
            {
                return this._BeguenstigterZahlungspflichtiger;
            }
            set
            {
                if ((this._BeguenstigterZahlungspflichtiger != value))
                {
                    this.OnBeguenstigterZahlungspflichtigerChanging(value);
                    this.SendPropertyChanging();
                    this._BeguenstigterZahlungspflichtiger = value;
                    this.SendPropertyChanged("BeguenstigterZahlungspflichtiger");
                    this.OnBeguenstigterZahlungspflichtigerChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Kontonummer", DbType = "NVarChar(50)")]
        public string Kontonummer
        {
            get
            {
                return this._Kontonummer;
            }
            set
            {
                if ((this._Kontonummer != value))
                {
                    this.OnKontonummerChanging(value);
                    this.SendPropertyChanging();
                    this._Kontonummer = value;
                    this.SendPropertyChanged("Kontonummer");
                    this.OnKontonummerChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_BLZ", DbType = "NVarChar(50)")]
        public string BLZ
        {
            get
            {
                return this._BLZ;
            }
            set
            {
                if ((this._BLZ != value))
                {
                    this.OnBLZChanging(value);
                    this.SendPropertyChanging();
                    this._BLZ = value;
                    this.SendPropertyChanged("BLZ");
                    this.OnBLZChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Betrag", DbType = "Money")]
        public System.Nullable<decimal> Betrag
        {
            get
            {
                return this._Betrag;
            }
            set
            {
                if ((this._Betrag != value))
                {
                    this.OnBetragChanging(value);
                    this.SendPropertyChanging();
                    this._Betrag = value;
                    this.SendPropertyChanged("Betrag");
                    this.OnBetragChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Waehrung", DbType = "NVarChar(200)")]
        public string Waehrung
        {
            get
            {
                return this._Waehrung;
            }
            set
            {
                if ((this._Waehrung != value))
                {
                    this.OnWaehrungChanging(value);
                    this.SendPropertyChanging();
                    this._Waehrung = value;
                    this.SendPropertyChanged("Waehrung");
                    this.OnWaehrungChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Info", DbType = "NVarChar(250)")]
        public string Info
        {
            get
            {
                return this._Info;
            }
            set
            {
                if ((this._Info != value))
                {
                    this.OnInfoChanging(value);
                    this.SendPropertyChanging();
                    this._Info = value;
                    this.SendPropertyChanged("Info");
                    this.OnInfoChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50)")]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyIBAN", DbType = "NVarChar(50)")]
        public string CompanyIBAN
        {
            get
            {
                return this._CompanyIBAN;
            }
            set
            {
                if ((this._CompanyIBAN != value))
                {
                    this.OnCompanyIBANChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyIBAN = value;
                    this.SendPropertyChanged("CompanyIBAN");
                    this.OnCompanyIBANChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsValidated", DbType = "Bit")]
        public System.Nullable<bool> IsValidated
        {
            get
            {
                return this._IsValidated;
            }
            set
            {
                if ((this._IsValidated != value))
                {
                    this.OnIsValidatedChanging(value);
                    this.SendPropertyChanging();
                    this._IsValidated = value;
                    this.SendPropertyChanged("IsValidated");
                    this.OnIsValidatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int")]
        public System.Nullable<int> ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.AffectationJournal")]
    public partial class AffectationJournal : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _AccountID;

        private bool _Side;

        private string _OAccountID;

        private string _TypeJournalID;

        private string _Description;

        private string _CompanyID;

        private System.Nullable<int> _ModelId;

        private int _Id;

        private EntityRef<Account> _Account;

        private EntityRef<Account> _Account1;

        private EntityRef<Company> _Company;

        private EntityRef<TypeJournal> _TypeJournal;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnAccountIDChanging(string value);
        partial void OnAccountIDChanged();
        partial void OnSideChanging(bool value);
        partial void OnSideChanged();
        partial void OnOAccountIDChanging(string value);
        partial void OnOAccountIDChanged();
        partial void OnTypeJournalIDChanging(string value);
        partial void OnTypeJournalIDChanged();
        partial void OnDescriptionChanging(string value);
        partial void OnDescriptionChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnModelIdChanging(System.Nullable<int> value);
        partial void OnModelIdChanged();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        #endregion

        public AffectationJournal()
        {
            this._Account = default(EntityRef<Account>);
            this._Account1 = default(EntityRef<Account>);
            this._Company = default(EntityRef<Company>);
            this._TypeJournal = default(EntityRef<TypeJournal>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string AccountID
        {
            get
            {
                return this._AccountID;
            }
            set
            {
                if ((this._AccountID != value))
                {
                    if (this._Account.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnAccountIDChanging(value);
                    this.SendPropertyChanging();
                    this._AccountID = value;
                    this.SendPropertyChanged("AccountID");
                    this.OnAccountIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Side", DbType = "Bit NOT NULL")]
        public bool Side
        {
            get
            {
                return this._Side;
            }
            set
            {
                if ((this._Side != value))
                {
                    this.OnSideChanging(value);
                    this.SendPropertyChanging();
                    this._Side = value;
                    this.SendPropertyChanged("Side");
                    this.OnSideChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OAccountID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string OAccountID
        {
            get
            {
                return this._OAccountID;
            }
            set
            {
                if ((this._OAccountID != value))
                {
                    if (this._Account1.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnOAccountIDChanging(value);
                    this.SendPropertyChanging();
                    this._OAccountID = value;
                    this.SendPropertyChanged("OAccountID");
                    this.OnOAccountIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TypeJournalID", DbType = "VarChar(50) NOT NULL", CanBeNull = false)]
        public string TypeJournalID
        {
            get
            {
                return this._TypeJournalID;
            }
            set
            {
                if ((this._TypeJournalID != value))
                {
                    if (this._TypeJournal.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnTypeJournalIDChanging(value);
                    this.SendPropertyChanging();
                    this._TypeJournalID = value;
                    this.SendPropertyChanged("TypeJournalID");
                    this.OnTypeJournalIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Description", DbType = "NVarChar(255)")]
        public string Description
        {
            get
            {
                return this._Description;
            }
            set
            {
                if ((this._Description != value))
                {
                    this.OnDescriptionChanging(value);
                    this.SendPropertyChanging();
                    this._Description = value;
                    this.SendPropertyChanged("Description");
                    this.OnDescriptionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    if (this._Company.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int")]
        public System.Nullable<int> ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_AffectationJournal", Storage = "_Account", ThisKey = "AccountID", OtherKey = "id", IsForeignKey = true)]
        public Account Account
        {
            get
            {
                return this._Account.Entity;
            }
            set
            {
                Account previousValue = this._Account.Entity;
                if (((previousValue != value)
                            || (this._Account.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Account.Entity = null;
                        previousValue.AffectationJournals.Remove(this);
                    }
                    this._Account.Entity = value;
                    if ((value != null))
                    {
                        value.AffectationJournals.Add(this);
                        this._AccountID = value.id;
                    }
                    else
                    {
                        this._AccountID = default(string);
                    }
                    this.SendPropertyChanged("Account");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_AffectationJournal1", Storage = "_Account1", ThisKey = "OAccountID", OtherKey = "id", IsForeignKey = true)]
        public Account Account1
        {
            get
            {
                return this._Account1.Entity;
            }
            set
            {
                Account previousValue = this._Account1.Entity;
                if (((previousValue != value)
                            || (this._Account1.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Account1.Entity = null;
                        previousValue.AffectationJournals1.Remove(this);
                    }
                    this._Account1.Entity = value;
                    if ((value != null))
                    {
                        value.AffectationJournals1.Add(this);
                        this._OAccountID = value.id;
                    }
                    else
                    {
                        this._OAccountID = default(string);
                    }
                    this.SendPropertyChanged("Account1");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Company_AffectationJournal", Storage = "_Company", ThisKey = "CompanyID", OtherKey = "id", IsForeignKey = true)]
        public Company Company
        {
            get
            {
                return this._Company.Entity;
            }
            set
            {
                Company previousValue = this._Company.Entity;
                if (((previousValue != value)
                            || (this._Company.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Company.Entity = null;
                        previousValue.AffectationJournals.Remove(this);
                    }
                    this._Company.Entity = value;
                    if ((value != null))
                    {
                        value.AffectationJournals.Add(this);
                        this._CompanyID = value.id;
                    }
                    else
                    {
                        this._CompanyID = default(string);
                    }
                    this.SendPropertyChanged("Company");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "TypeJournal_AffectationJournal", Storage = "_TypeJournal", ThisKey = "TypeJournalID", OtherKey = "Id", IsForeignKey = true)]
        public TypeJournal TypeJournal
        {
            get
            {
                return this._TypeJournal.Entity;
            }
            set
            {
                TypeJournal previousValue = this._TypeJournal.Entity;
                if (((previousValue != value)
                            || (this._TypeJournal.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._TypeJournal.Entity = null;
                        previousValue.AffectationJournals.Remove(this);
                    }
                    this._TypeJournal.Entity = value;
                    if ((value != null))
                    {
                        value.AffectationJournals.Add(this);
                        this._TypeJournalID = value.Id;
                    }
                    else
                    {
                        this._TypeJournalID = default(string);
                    }
                    this.SendPropertyChanged("TypeJournal");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Article")]
    public partial class Article : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _id;

        private string _name;

        private string _description;

        private decimal _price;

        private decimal _avgprice;

        private decimal _salesprice;

        private string _qttyunit;

        private string _packunit;

        private string _VatCode;

        private bool _IsService;

        private string _CompanyID;

        private string _StockAccount;

        private string _ExpenseAccount;

        private string _Currency;

        private string _GroupId;

        private string _RevenuAccountId;

        private System.DateTime _Posted;

        private System.DateTime _Updated;

        private int _ModelId;

        private EntitySet<DetailLogistic> _DetailLogistics;

        private EntitySet<Stock> _Stocks;

        private EntityRef<Vat> _Vat;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(string value);
        partial void OnidChanged();
        partial void OnnameChanging(string value);
        partial void OnnameChanged();
        partial void OndescriptionChanging(string value);
        partial void OndescriptionChanged();
        partial void OnpriceChanging(decimal value);
        partial void OnpriceChanged();
        partial void OnavgpriceChanging(decimal value);
        partial void OnavgpriceChanged();
        partial void OnsalespriceChanging(decimal value);
        partial void OnsalespriceChanged();
        partial void OnqttyunitChanging(string value);
        partial void OnqttyunitChanged();
        partial void OnpackunitChanging(string value);
        partial void OnpackunitChanged();
        partial void OnVatCodeChanging(string value);
        partial void OnVatCodeChanged();
        partial void OnIsServiceChanging(bool value);
        partial void OnIsServiceChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnStockAccountChanging(string value);
        partial void OnStockAccountChanged();
        partial void OnExpenseAccountChanging(string value);
        partial void OnExpenseAccountChanged();
        partial void OnCurrencyChanging(string value);
        partial void OnCurrencyChanged();
        partial void OnGroupIdChanging(string value);
        partial void OnGroupIdChanged();
        partial void OnRevenuAccountIdChanging(string value);
        partial void OnRevenuAccountIdChanged();
        partial void OnPostedChanging(System.DateTime value);
        partial void OnPostedChanged();
        partial void OnUpdatedChanging(System.DateTime value);
        partial void OnUpdatedChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public Article()
        {
            this._DetailLogistics = new EntitySet<DetailLogistic>(new Action<DetailLogistic>(this.attach_DetailLogistics), new Action<DetailLogistic>(this.detach_DetailLogistics));
            this._Stocks = new EntitySet<Stock>(new Action<Stock>(this.attach_Stocks), new Action<Stock>(this.detach_Stocks));
            this._Vat = default(EntityRef<Vat>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this.OnnameChanging(value);
                    this.SendPropertyChanging();
                    this._name = value;
                    this.SendPropertyChanged("name");
                    this.OnnameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_description", DbType = "NVarChar(255)")]
        public string description
        {
            get
            {
                return this._description;
            }
            set
            {
                if ((this._description != value))
                {
                    this.OndescriptionChanging(value);
                    this.SendPropertyChanging();
                    this._description = value;
                    this.SendPropertyChanged("description");
                    this.OndescriptionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_price", DbType = "Money NOT NULL")]
        public decimal price
        {
            get
            {
                return this._price;
            }
            set
            {
                if ((this._price != value))
                {
                    this.OnpriceChanging(value);
                    this.SendPropertyChanging();
                    this._price = value;
                    this.SendPropertyChanged("price");
                    this.OnpriceChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_avgprice", DbType = "Money NOT NULL")]
        public decimal avgprice
        {
            get
            {
                return this._avgprice;
            }
            set
            {
                if ((this._avgprice != value))
                {
                    this.OnavgpriceChanging(value);
                    this.SendPropertyChanging();
                    this._avgprice = value;
                    this.SendPropertyChanged("avgprice");
                    this.OnavgpriceChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_salesprice", DbType = "Money NOT NULL")]
        public decimal salesprice
        {
            get
            {
                return this._salesprice;
            }
            set
            {
                if ((this._salesprice != value))
                {
                    this.OnsalespriceChanging(value);
                    this.SendPropertyChanging();
                    this._salesprice = value;
                    this.SendPropertyChanged("salesprice");
                    this.OnsalespriceChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_qttyunit", DbType = "NVarChar(255)")]
        public string qttyunit
        {
            get
            {
                return this._qttyunit;
            }
            set
            {
                if ((this._qttyunit != value))
                {
                    this.OnqttyunitChanging(value);
                    this.SendPropertyChanging();
                    this._qttyunit = value;
                    this.SendPropertyChanged("qttyunit");
                    this.OnqttyunitChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_packunit", DbType = "NVarChar(255)")]
        public string packunit
        {
            get
            {
                return this._packunit;
            }
            set
            {
                if ((this._packunit != value))
                {
                    this.OnpackunitChanging(value);
                    this.SendPropertyChanging();
                    this._packunit = value;
                    this.SendPropertyChanged("packunit");
                    this.OnpackunitChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_VatCode", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string VatCode
        {
            get
            {
                return this._VatCode;
            }
            set
            {
                if ((this._VatCode != value))
                {
                    if (this._Vat.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnVatCodeChanging(value);
                    this.SendPropertyChanging();
                    this._VatCode = value;
                    this.SendPropertyChanged("VatCode");
                    this.OnVatCodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsService", DbType = "Bit NOT NULL")]
        public bool IsService
        {
            get
            {
                return this._IsService;
            }
            set
            {
                if ((this._IsService != value))
                {
                    this.OnIsServiceChanging(value);
                    this.SendPropertyChanging();
                    this._IsService = value;
                    this.SendPropertyChanged("IsService");
                    this.OnIsServiceChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_StockAccount", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string StockAccount
        {
            get
            {
                return this._StockAccount;
            }
            set
            {
                if ((this._StockAccount != value))
                {
                    this.OnStockAccountChanging(value);
                    this.SendPropertyChanging();
                    this._StockAccount = value;
                    this.SendPropertyChanged("StockAccount");
                    this.OnStockAccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ExpenseAccount", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string ExpenseAccount
        {
            get
            {
                return this._ExpenseAccount;
            }
            set
            {
                if ((this._ExpenseAccount != value))
                {
                    this.OnExpenseAccountChanging(value);
                    this.SendPropertyChanging();
                    this._ExpenseAccount = value;
                    this.SendPropertyChanged("ExpenseAccount");
                    this.OnExpenseAccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this.OnCurrencyChanging(value);
                    this.SendPropertyChanging();
                    this._Currency = value;
                    this.SendPropertyChanged("Currency");
                    this.OnCurrencyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_GroupId", DbType = "NVarChar(50)")]
        public string GroupId
        {
            get
            {
                return this._GroupId;
            }
            set
            {
                if ((this._GroupId != value))
                {
                    this.OnGroupIdChanging(value);
                    this.SendPropertyChanging();
                    this._GroupId = value;
                    this.SendPropertyChanged("GroupId");
                    this.OnGroupIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_RevenuAccountId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string RevenuAccountId
        {
            get
            {
                return this._RevenuAccountId;
            }
            set
            {
                if ((this._RevenuAccountId != value))
                {
                    this.OnRevenuAccountIdChanging(value);
                    this.SendPropertyChanging();
                    this._RevenuAccountId = value;
                    this.SendPropertyChanged("RevenuAccountId");
                    this.OnRevenuAccountIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Posted", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Posted
        {
            get
            {
                return this._Posted;
            }
            set
            {
                if ((this._Posted != value))
                {
                    this.OnPostedChanging(value);
                    this.SendPropertyChanging();
                    this._Posted = value;
                    this.SendPropertyChanged("Posted");
                    this.OnPostedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Updated", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Updated
        {
            get
            {
                return this._Updated;
            }
            set
            {
                if ((this._Updated != value))
                {
                    this.OnUpdatedChanging(value);
                    this.SendPropertyChanging();
                    this._Updated = value;
                    this.SendPropertyChanged("Updated");
                    this.OnUpdatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Article_DetailLogistic", Storage = "_DetailLogistics", ThisKey = "id", OtherKey = "item")]
        public EntitySet<DetailLogistic> DetailLogistics
        {
            get
            {
                return this._DetailLogistics;
            }
            set
            {
                this._DetailLogistics.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Article_Stock", Storage = "_Stocks", ThisKey = "id", OtherKey = "itemid")]
        public EntitySet<Stock> Stocks
        {
            get
            {
                return this._Stocks;
            }
            set
            {
                this._Stocks.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Vat_Article", Storage = "_Vat", ThisKey = "VatCode", OtherKey = "id", IsForeignKey = true)]
        public Vat Vat
        {
            get
            {
                return this._Vat.Entity;
            }
            set
            {
                Vat previousValue = this._Vat.Entity;
                if (((previousValue != value)
                            || (this._Vat.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Vat.Entity = null;
                        previousValue.Articles.Remove(this);
                    }
                    this._Vat.Entity = value;
                    if ((value != null))
                    {
                        value.Articles.Add(this);
                        this._VatCode = value.id;
                    }
                    else
                    {
                        this._VatCode = default(string);
                    }
                    this.SendPropertyChanged("Vat");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_DetailLogistics(DetailLogistic entity)
        {
            this.SendPropertyChanging();
            entity.Article = this;
        }

        private void detach_DetailLogistics(DetailLogistic entity)
        {
            this.SendPropertyChanging();
            entity.Article = null;
        }

        private void attach_Stocks(Stock entity)
        {
            this.SendPropertyChanging();
            entity.Article = this;
        }

        private void detach_Stocks(Stock entity)
        {
            this.SendPropertyChanging();
            entity.Article = null;
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.AspNetRoles")]
    public partial class AspNetRole : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _Id;

        private string _Name;

        private EntitySet<AspNetUserRole> _AspNetUserRoles;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(string value);
        partial void OnIdChanged();
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        #endregion

        public AspNetRole()
        {
            this._AspNetUserRoles = new EntitySet<AspNetUserRole>(new Action<AspNetUserRole>(this.attach_AspNetUserRoles), new Action<AspNetUserRole>(this.detach_AspNetUserRoles));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", DbType = "NVarChar(128) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(256) NOT NULL", CanBeNull = false)]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this.OnNameChanging(value);
                    this.SendPropertyChanging();
                    this._Name = value;
                    this.SendPropertyChanged("Name");
                    this.OnNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "AspNetRole_AspNetUserRole", Storage = "_AspNetUserRoles", ThisKey = "Id", OtherKey = "RoleId")]
        public EntitySet<AspNetUserRole> AspNetUserRoles
        {
            get
            {
                return this._AspNetUserRoles;
            }
            set
            {
                this._AspNetUserRoles.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_AspNetUserRoles(AspNetUserRole entity)
        {
            this.SendPropertyChanging();
            entity.AspNetRole = this;
        }

        private void detach_AspNetUserRoles(AspNetUserRole entity)
        {
            this.SendPropertyChanging();
            entity.AspNetRole = null;
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.AspNetUserClaims")]
    public partial class AspNetUserClaim : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private string _UserId;

        private string _ClaimType;

        private string _ClaimValue;

        private EntityRef<AspNetUser> _AspNetUser;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnUserIdChanging(string value);
        partial void OnUserIdChanged();
        partial void OnClaimTypeChanging(string value);
        partial void OnClaimTypeChanged();
        partial void OnClaimValueChanging(string value);
        partial void OnClaimValueChanged();
        #endregion

        public AspNetUserClaim()
        {
            this._AspNetUser = default(EntityRef<AspNetUser>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserId", DbType = "NVarChar(128) NOT NULL", CanBeNull = false)]
        public string UserId
        {
            get
            {
                return this._UserId;
            }
            set
            {
                if ((this._UserId != value))
                {
                    if (this._AspNetUser.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserIdChanging(value);
                    this.SendPropertyChanging();
                    this._UserId = value;
                    this.SendPropertyChanged("UserId");
                    this.OnUserIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ClaimType", DbType = "NVarChar(MAX)")]
        public string ClaimType
        {
            get
            {
                return this._ClaimType;
            }
            set
            {
                if ((this._ClaimType != value))
                {
                    this.OnClaimTypeChanging(value);
                    this.SendPropertyChanging();
                    this._ClaimType = value;
                    this.SendPropertyChanged("ClaimType");
                    this.OnClaimTypeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ClaimValue", DbType = "NVarChar(MAX)")]
        public string ClaimValue
        {
            get
            {
                return this._ClaimValue;
            }
            set
            {
                if ((this._ClaimValue != value))
                {
                    this.OnClaimValueChanging(value);
                    this.SendPropertyChanging();
                    this._ClaimValue = value;
                    this.SendPropertyChanged("ClaimValue");
                    this.OnClaimValueChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "AspNetUser_AspNetUserClaim", Storage = "_AspNetUser", ThisKey = "UserId", OtherKey = "Id", IsForeignKey = true, DeleteOnNull = true, DeleteRule = "CASCADE")]
        public AspNetUser AspNetUser
        {
            get
            {
                return this._AspNetUser.Entity;
            }
            set
            {
                AspNetUser previousValue = this._AspNetUser.Entity;
                if (((previousValue != value)
                            || (this._AspNetUser.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._AspNetUser.Entity = null;
                        previousValue.AspNetUserClaims.Remove(this);
                    }
                    this._AspNetUser.Entity = value;
                    if ((value != null))
                    {
                        value.AspNetUserClaims.Add(this);
                        this._UserId = value.Id;
                    }
                    else
                    {
                        this._UserId = default(string);
                    }
                    this.SendPropertyChanged("AspNetUser");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.AspNetUserLogins")]
    public partial class AspNetUserLogin : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _LoginProvider;

        private string _ProviderKey;

        private string _UserId;

        private EntityRef<AspNetUser> _AspNetUser;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnLoginProviderChanging(string value);
        partial void OnLoginProviderChanged();
        partial void OnProviderKeyChanging(string value);
        partial void OnProviderKeyChanged();
        partial void OnUserIdChanging(string value);
        partial void OnUserIdChanged();
        #endregion

        public AspNetUserLogin()
        {
            this._AspNetUser = default(EntityRef<AspNetUser>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LoginProvider", DbType = "NVarChar(128) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string LoginProvider
        {
            get
            {
                return this._LoginProvider;
            }
            set
            {
                if ((this._LoginProvider != value))
                {
                    this.OnLoginProviderChanging(value);
                    this.SendPropertyChanging();
                    this._LoginProvider = value;
                    this.SendPropertyChanged("LoginProvider");
                    this.OnLoginProviderChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ProviderKey", DbType = "NVarChar(128) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string ProviderKey
        {
            get
            {
                return this._ProviderKey;
            }
            set
            {
                if ((this._ProviderKey != value))
                {
                    this.OnProviderKeyChanging(value);
                    this.SendPropertyChanging();
                    this._ProviderKey = value;
                    this.SendPropertyChanged("ProviderKey");
                    this.OnProviderKeyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserId", DbType = "NVarChar(128) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string UserId
        {
            get
            {
                return this._UserId;
            }
            set
            {
                if ((this._UserId != value))
                {
                    if (this._AspNetUser.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserIdChanging(value);
                    this.SendPropertyChanging();
                    this._UserId = value;
                    this.SendPropertyChanged("UserId");
                    this.OnUserIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "AspNetUser_AspNetUserLogin", Storage = "_AspNetUser", ThisKey = "UserId", OtherKey = "Id", IsForeignKey = true, DeleteOnNull = true, DeleteRule = "CASCADE")]
        public AspNetUser AspNetUser
        {
            get
            {
                return this._AspNetUser.Entity;
            }
            set
            {
                AspNetUser previousValue = this._AspNetUser.Entity;
                if (((previousValue != value)
                            || (this._AspNetUser.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._AspNetUser.Entity = null;
                        previousValue.AspNetUserLogins.Remove(this);
                    }
                    this._AspNetUser.Entity = value;
                    if ((value != null))
                    {
                        value.AspNetUserLogins.Add(this);
                        this._UserId = value.Id;
                    }
                    else
                    {
                        this._UserId = default(string);
                    }
                    this.SendPropertyChanged("AspNetUser");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.AspNetUserRoles")]
    public partial class AspNetUserRole : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _UserId;

        private string _RoleId;

        private EntityRef<AspNetRole> _AspNetRole;

        private EntityRef<AspNetUser> _AspNetUser;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnUserIdChanging(string value);
        partial void OnUserIdChanged();
        partial void OnRoleIdChanging(string value);
        partial void OnRoleIdChanged();
        #endregion

        public AspNetUserRole()
        {
            this._AspNetRole = default(EntityRef<AspNetRole>);
            this._AspNetUser = default(EntityRef<AspNetUser>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserId", DbType = "NVarChar(128) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string UserId
        {
            get
            {
                return this._UserId;
            }
            set
            {
                if ((this._UserId != value))
                {
                    if (this._AspNetUser.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnUserIdChanging(value);
                    this.SendPropertyChanging();
                    this._UserId = value;
                    this.SendPropertyChanged("UserId");
                    this.OnUserIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_RoleId", DbType = "NVarChar(128) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string RoleId
        {
            get
            {
                return this._RoleId;
            }
            set
            {
                if ((this._RoleId != value))
                {
                    if (this._AspNetRole.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnRoleIdChanging(value);
                    this.SendPropertyChanging();
                    this._RoleId = value;
                    this.SendPropertyChanged("RoleId");
                    this.OnRoleIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "AspNetRole_AspNetUserRole", Storage = "_AspNetRole", ThisKey = "RoleId", OtherKey = "Id", IsForeignKey = true, DeleteOnNull = true, DeleteRule = "CASCADE")]
        public AspNetRole AspNetRole
        {
            get
            {
                return this._AspNetRole.Entity;
            }
            set
            {
                AspNetRole previousValue = this._AspNetRole.Entity;
                if (((previousValue != value)
                            || (this._AspNetRole.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._AspNetRole.Entity = null;
                        previousValue.AspNetUserRoles.Remove(this);
                    }
                    this._AspNetRole.Entity = value;
                    if ((value != null))
                    {
                        value.AspNetUserRoles.Add(this);
                        this._RoleId = value.Id;
                    }
                    else
                    {
                        this._RoleId = default(string);
                    }
                    this.SendPropertyChanged("AspNetRole");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "AspNetUser_AspNetUserRole", Storage = "_AspNetUser", ThisKey = "UserId", OtherKey = "Id", IsForeignKey = true, DeleteOnNull = true, DeleteRule = "CASCADE")]
        public AspNetUser AspNetUser
        {
            get
            {
                return this._AspNetUser.Entity;
            }
            set
            {
                AspNetUser previousValue = this._AspNetUser.Entity;
                if (((previousValue != value)
                            || (this._AspNetUser.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._AspNetUser.Entity = null;
                        previousValue.AspNetUserRoles.Remove(this);
                    }
                    this._AspNetUser.Entity = value;
                    if ((value != null))
                    {
                        value.AspNetUserRoles.Add(this);
                        this._UserId = value.Id;
                    }
                    else
                    {
                        this._UserId = default(string);
                    }
                    this.SendPropertyChanged("AspNetUser");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.AspNetUsers")]
    public partial class AspNetUser : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _Id;

        private System.Nullable<System.DateTime> _BirthDate;

        private string _FirstName;

        private string _LastName;

        private string _Company;

        private int _Gender;

        private string _Email;

        private bool _EmailConfirmed;

        private string _PasswordHash;

        private string _SecurityStamp;

        private string _PhoneNumber;

        private bool _PhoneNumberConfirmed;

        private bool _TwoFactorEnabled;

        private System.Nullable<System.DateTime> _LockoutEndDateUtc;

        private bool _LockoutEnabled;

        private int _AccessFailedCount;

        private string _UserName;

        private EntitySet<AspNetUserClaim> _AspNetUserClaims;

        private EntitySet<AspNetUserLogin> _AspNetUserLogins;

        private EntitySet<AspNetUserRole> _AspNetUserRoles;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(string value);
        partial void OnIdChanged();
        partial void OnBirthDateChanging(System.Nullable<System.DateTime> value);
        partial void OnBirthDateChanged();
        partial void OnFirstNameChanging(string value);
        partial void OnFirstNameChanged();
        partial void OnLastNameChanging(string value);
        partial void OnLastNameChanged();
        partial void OnCompanyChanging(string value);
        partial void OnCompanyChanged();
        partial void OnGenderChanging(int value);
        partial void OnGenderChanged();
        partial void OnEmailChanging(string value);
        partial void OnEmailChanged();
        partial void OnEmailConfirmedChanging(bool value);
        partial void OnEmailConfirmedChanged();
        partial void OnPasswordHashChanging(string value);
        partial void OnPasswordHashChanged();
        partial void OnSecurityStampChanging(string value);
        partial void OnSecurityStampChanged();
        partial void OnPhoneNumberChanging(string value);
        partial void OnPhoneNumberChanged();
        partial void OnPhoneNumberConfirmedChanging(bool value);
        partial void OnPhoneNumberConfirmedChanged();
        partial void OnTwoFactorEnabledChanging(bool value);
        partial void OnTwoFactorEnabledChanged();
        partial void OnLockoutEndDateUtcChanging(System.Nullable<System.DateTime> value);
        partial void OnLockoutEndDateUtcChanged();
        partial void OnLockoutEnabledChanging(bool value);
        partial void OnLockoutEnabledChanged();
        partial void OnAccessFailedCountChanging(int value);
        partial void OnAccessFailedCountChanged();
        partial void OnUserNameChanging(string value);
        partial void OnUserNameChanged();
        #endregion

        public AspNetUser()
        {
            this._AspNetUserClaims = new EntitySet<AspNetUserClaim>(new Action<AspNetUserClaim>(this.attach_AspNetUserClaims), new Action<AspNetUserClaim>(this.detach_AspNetUserClaims));
            this._AspNetUserLogins = new EntitySet<AspNetUserLogin>(new Action<AspNetUserLogin>(this.attach_AspNetUserLogins), new Action<AspNetUserLogin>(this.detach_AspNetUserLogins));
            this._AspNetUserRoles = new EntitySet<AspNetUserRole>(new Action<AspNetUserRole>(this.attach_AspNetUserRoles), new Action<AspNetUserRole>(this.detach_AspNetUserRoles));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", DbType = "NVarChar(128) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_BirthDate", DbType = "DateTime")]
        public System.Nullable<System.DateTime> BirthDate
        {
            get
            {
                return this._BirthDate;
            }
            set
            {
                if ((this._BirthDate != value))
                {
                    this.OnBirthDateChanging(value);
                    this.SendPropertyChanging();
                    this._BirthDate = value;
                    this.SendPropertyChanged("BirthDate");
                    this.OnBirthDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FirstName", DbType = "NVarChar(MAX)")]
        public string FirstName
        {
            get
            {
                return this._FirstName;
            }
            set
            {
                if ((this._FirstName != value))
                {
                    this.OnFirstNameChanging(value);
                    this.SendPropertyChanging();
                    this._FirstName = value;
                    this.SendPropertyChanged("FirstName");
                    this.OnFirstNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LastName", DbType = "NVarChar(MAX)")]
        public string LastName
        {
            get
            {
                return this._LastName;
            }
            set
            {
                if ((this._LastName != value))
                {
                    this.OnLastNameChanging(value);
                    this.SendPropertyChanging();
                    this._LastName = value;
                    this.SendPropertyChanged("LastName");
                    this.OnLastNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Company", DbType = "NVarChar(MAX)")]
        public string Company
        {
            get
            {
                return this._Company;
            }
            set
            {
                if ((this._Company != value))
                {
                    this.OnCompanyChanging(value);
                    this.SendPropertyChanging();
                    this._Company = value;
                    this.SendPropertyChanged("Company");
                    this.OnCompanyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Gender", DbType = "Int NOT NULL")]
        public int Gender
        {
            get
            {
                return this._Gender;
            }
            set
            {
                if ((this._Gender != value))
                {
                    this.OnGenderChanging(value);
                    this.SendPropertyChanging();
                    this._Gender = value;
                    this.SendPropertyChanged("Gender");
                    this.OnGenderChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Email", DbType = "NVarChar(256)")]
        public string Email
        {
            get
            {
                return this._Email;
            }
            set
            {
                if ((this._Email != value))
                {
                    this.OnEmailChanging(value);
                    this.SendPropertyChanging();
                    this._Email = value;
                    this.SendPropertyChanged("Email");
                    this.OnEmailChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_EmailConfirmed", DbType = "Bit NOT NULL")]
        public bool EmailConfirmed
        {
            get
            {
                return this._EmailConfirmed;
            }
            set
            {
                if ((this._EmailConfirmed != value))
                {
                    this.OnEmailConfirmedChanging(value);
                    this.SendPropertyChanging();
                    this._EmailConfirmed = value;
                    this.SendPropertyChanged("EmailConfirmed");
                    this.OnEmailConfirmedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PasswordHash", DbType = "NVarChar(MAX)")]
        public string PasswordHash
        {
            get
            {
                return this._PasswordHash;
            }
            set
            {
                if ((this._PasswordHash != value))
                {
                    this.OnPasswordHashChanging(value);
                    this.SendPropertyChanging();
                    this._PasswordHash = value;
                    this.SendPropertyChanged("PasswordHash");
                    this.OnPasswordHashChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SecurityStamp", DbType = "NVarChar(MAX)")]
        public string SecurityStamp
        {
            get
            {
                return this._SecurityStamp;
            }
            set
            {
                if ((this._SecurityStamp != value))
                {
                    this.OnSecurityStampChanging(value);
                    this.SendPropertyChanging();
                    this._SecurityStamp = value;
                    this.SendPropertyChanged("SecurityStamp");
                    this.OnSecurityStampChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PhoneNumber", DbType = "NVarChar(MAX)")]
        public string PhoneNumber
        {
            get
            {
                return this._PhoneNumber;
            }
            set
            {
                if ((this._PhoneNumber != value))
                {
                    this.OnPhoneNumberChanging(value);
                    this.SendPropertyChanging();
                    this._PhoneNumber = value;
                    this.SendPropertyChanged("PhoneNumber");
                    this.OnPhoneNumberChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PhoneNumberConfirmed", DbType = "Bit NOT NULL")]
        public bool PhoneNumberConfirmed
        {
            get
            {
                return this._PhoneNumberConfirmed;
            }
            set
            {
                if ((this._PhoneNumberConfirmed != value))
                {
                    this.OnPhoneNumberConfirmedChanging(value);
                    this.SendPropertyChanging();
                    this._PhoneNumberConfirmed = value;
                    this.SendPropertyChanged("PhoneNumberConfirmed");
                    this.OnPhoneNumberConfirmedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TwoFactorEnabled", DbType = "Bit NOT NULL")]
        public bool TwoFactorEnabled
        {
            get
            {
                return this._TwoFactorEnabled;
            }
            set
            {
                if ((this._TwoFactorEnabled != value))
                {
                    this.OnTwoFactorEnabledChanging(value);
                    this.SendPropertyChanging();
                    this._TwoFactorEnabled = value;
                    this.SendPropertyChanged("TwoFactorEnabled");
                    this.OnTwoFactorEnabledChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LockoutEndDateUtc", DbType = "DateTime")]
        public System.Nullable<System.DateTime> LockoutEndDateUtc
        {
            get
            {
                return this._LockoutEndDateUtc;
            }
            set
            {
                if ((this._LockoutEndDateUtc != value))
                {
                    this.OnLockoutEndDateUtcChanging(value);
                    this.SendPropertyChanging();
                    this._LockoutEndDateUtc = value;
                    this.SendPropertyChanged("LockoutEndDateUtc");
                    this.OnLockoutEndDateUtcChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LockoutEnabled", DbType = "Bit NOT NULL")]
        public bool LockoutEnabled
        {
            get
            {
                return this._LockoutEnabled;
            }
            set
            {
                if ((this._LockoutEnabled != value))
                {
                    this.OnLockoutEnabledChanging(value);
                    this.SendPropertyChanging();
                    this._LockoutEnabled = value;
                    this.SendPropertyChanged("LockoutEnabled");
                    this.OnLockoutEnabledChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccessFailedCount", DbType = "Int NOT NULL")]
        public int AccessFailedCount
        {
            get
            {
                return this._AccessFailedCount;
            }
            set
            {
                if ((this._AccessFailedCount != value))
                {
                    this.OnAccessFailedCountChanging(value);
                    this.SendPropertyChanging();
                    this._AccessFailedCount = value;
                    this.SendPropertyChanged("AccessFailedCount");
                    this.OnAccessFailedCountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserName", DbType = "NVarChar(256) NOT NULL", CanBeNull = false)]
        public string UserName
        {
            get
            {
                return this._UserName;
            }
            set
            {
                if ((this._UserName != value))
                {
                    this.OnUserNameChanging(value);
                    this.SendPropertyChanging();
                    this._UserName = value;
                    this.SendPropertyChanged("UserName");
                    this.OnUserNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "AspNetUser_AspNetUserClaim", Storage = "_AspNetUserClaims", ThisKey = "Id", OtherKey = "UserId")]
        public EntitySet<AspNetUserClaim> AspNetUserClaims
        {
            get
            {
                return this._AspNetUserClaims;
            }
            set
            {
                this._AspNetUserClaims.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "AspNetUser_AspNetUserLogin", Storage = "_AspNetUserLogins", ThisKey = "Id", OtherKey = "UserId")]
        public EntitySet<AspNetUserLogin> AspNetUserLogins
        {
            get
            {
                return this._AspNetUserLogins;
            }
            set
            {
                this._AspNetUserLogins.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "AspNetUser_AspNetUserRole", Storage = "_AspNetUserRoles", ThisKey = "Id", OtherKey = "UserId")]
        public EntitySet<AspNetUserRole> AspNetUserRoles
        {
            get
            {
                return this._AspNetUserRoles;
            }
            set
            {
                this._AspNetUserRoles.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_AspNetUserClaims(AspNetUserClaim entity)
        {
            this.SendPropertyChanging();
            entity.AspNetUser = this;
        }

        private void detach_AspNetUserClaims(AspNetUserClaim entity)
        {
            this.SendPropertyChanging();
            entity.AspNetUser = null;
        }

        private void attach_AspNetUserLogins(AspNetUserLogin entity)
        {
            this.SendPropertyChanging();
            entity.AspNetUser = this;
        }

        private void detach_AspNetUserLogins(AspNetUserLogin entity)
        {
            this.SendPropertyChanging();
            entity.AspNetUser = null;
        }

        private void attach_AspNetUserRoles(AspNetUserRole entity)
        {
            this.SendPropertyChanging();
            entity.AspNetUser = this;
        }

        private void detach_AspNetUserRoles(AspNetUserRole entity)
        {
            this.SendPropertyChanging();
            entity.AspNetUser = null;
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Bank")]
    public partial class Bank : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _id;

        private string _name;

        private string _description;

        private string _CompanyID;

        private System.DateTime _Posted;

        private System.DateTime _Updated;

        private int _ModelId;

        private EntitySet<BankAccount> _BankAccounts;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(string value);
        partial void OnidChanged();
        partial void OnnameChanging(string value);
        partial void OnnameChanged();
        partial void OndescriptionChanging(string value);
        partial void OndescriptionChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnPostedChanging(System.DateTime value);
        partial void OnPostedChanged();
        partial void OnUpdatedChanging(System.DateTime value);
        partial void OnUpdatedChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public Bank()
        {
            this._BankAccounts = new EntitySet<BankAccount>(new Action<BankAccount>(this.attach_BankAccounts), new Action<BankAccount>(this.detach_BankAccounts));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(250) NOT NULL", CanBeNull = false)]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this.OnnameChanging(value);
                    this.SendPropertyChanging();
                    this._name = value;
                    this.SendPropertyChanged("name");
                    this.OnnameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_description", DbType = "NVarChar(255)")]
        public string description
        {
            get
            {
                return this._description;
            }
            set
            {
                if ((this._description != value))
                {
                    this.OndescriptionChanging(value);
                    this.SendPropertyChanging();
                    this._description = value;
                    this.SendPropertyChanged("description");
                    this.OndescriptionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Posted", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Posted
        {
            get
            {
                return this._Posted;
            }
            set
            {
                if ((this._Posted != value))
                {
                    this.OnPostedChanging(value);
                    this.SendPropertyChanging();
                    this._Posted = value;
                    this.SendPropertyChanged("Posted");
                    this.OnPostedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Updated", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Updated
        {
            get
            {
                return this._Updated;
            }
            set
            {
                if ((this._Updated != value))
                {
                    this.OnUpdatedChanging(value);
                    this.SendPropertyChanging();
                    this._Updated = value;
                    this.SendPropertyChanged("Updated");
                    this.OnUpdatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Bank_BankAccount", Storage = "_BankAccounts", ThisKey = "id", OtherKey = "BIC")]
        public EntitySet<BankAccount> BankAccounts
        {
            get
            {
                return this._BankAccounts;
            }
            set
            {
                this._BankAccounts.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_BankAccounts(BankAccount entity)
        {
            this.SendPropertyChanging();
            entity.Bank = this;
        }

        private void detach_BankAccounts(BankAccount entity)
        {
            this.SendPropertyChanging();
            entity.Bank = null;
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.BankAccount")]
    public partial class BankAccount : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _IBAN;

        private string _Owner;

        private string _BIC;

        private string _Account;

        private decimal _Debit;

        private decimal _Credit;

        private string _Currency;

        private string _CompanyID;

        private int _ModelId;

        private EntityRef<Bank> _Bank;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIBANChanging(string value);
        partial void OnIBANChanged();
        partial void OnOwnerChanging(string value);
        partial void OnOwnerChanged();
        partial void OnBICChanging(string value);
        partial void OnBICChanged();
        partial void OnAccountChanging(string value);
        partial void OnAccountChanged();
        partial void OnDebitChanging(decimal value);
        partial void OnDebitChanged();
        partial void OnCreditChanging(decimal value);
        partial void OnCreditChanged();
        partial void OnCurrencyChanging(string value);
        partial void OnCurrencyChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public BankAccount()
        {
            this._Bank = default(EntityRef<Bank>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IBAN", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string IBAN
        {
            get
            {
                return this._IBAN;
            }
            set
            {
                if ((this._IBAN != value))
                {
                    this.OnIBANChanging(value);
                    this.SendPropertyChanging();
                    this._IBAN = value;
                    this.SendPropertyChanged("IBAN");
                    this.OnIBANChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Owner", DbType = "NVarChar(255) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string Owner
        {
            get
            {
                return this._Owner;
            }
            set
            {
                if ((this._Owner != value))
                {
                    this.OnOwnerChanging(value);
                    this.SendPropertyChanging();
                    this._Owner = value;
                    this.SendPropertyChanged("Owner");
                    this.OnOwnerChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_BIC", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string BIC
        {
            get
            {
                return this._BIC;
            }
            set
            {
                if ((this._BIC != value))
                {
                    if (this._Bank.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnBICChanging(value);
                    this.SendPropertyChanging();
                    this._BIC = value;
                    this.SendPropertyChanged("BIC");
                    this.OnBICChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Account", DbType = "NVarChar(50)")]
        public string Account
        {
            get
            {
                return this._Account;
            }
            set
            {
                if ((this._Account != value))
                {
                    this.OnAccountChanging(value);
                    this.SendPropertyChanging();
                    this._Account = value;
                    this.SendPropertyChanged("Account");
                    this.OnAccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Debit", DbType = "Money NOT NULL")]
        public decimal Debit
        {
            get
            {
                return this._Debit;
            }
            set
            {
                if ((this._Debit != value))
                {
                    this.OnDebitChanging(value);
                    this.SendPropertyChanging();
                    this._Debit = value;
                    this.SendPropertyChanged("Debit");
                    this.OnDebitChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Credit", DbType = "Money NOT NULL")]
        public decimal Credit
        {
            get
            {
                return this._Credit;
            }
            set
            {
                if ((this._Credit != value))
                {
                    this.OnCreditChanging(value);
                    this.SendPropertyChanging();
                    this._Credit = value;
                    this.SendPropertyChanged("Credit");
                    this.OnCreditChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10)")]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this.OnCurrencyChanging(value);
                    this.SendPropertyChanging();
                    this._Currency = value;
                    this.SendPropertyChanged("Currency");
                    this.OnCurrencyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Bank_BankAccount", Storage = "_Bank", ThisKey = "BIC", OtherKey = "id", IsForeignKey = true)]
        public Bank Bank
        {
            get
            {
                return this._Bank.Entity;
            }
            set
            {
                Bank previousValue = this._Bank.Entity;
                if (((previousValue != value)
                            || (this._Bank.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Bank.Entity = null;
                        previousValue.BankAccounts.Remove(this);
                    }
                    this._Bank.Entity = value;
                    if ((value != null))
                    {
                        value.BankAccounts.Add(this);
                        this._BIC = value.id;
                    }
                    else
                    {
                        this._BIC = default(string);
                    }
                    this.SendPropertyChanged("Bank");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Brouillard")]
    public partial class Brouillard : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private string _Date;

        private string _NumPiece;

        private string _AccountID;

        private string _OAccountID;

        private string _Owner;

        private string _Text;

        private string _Debit;

        private string _Credit;

        private string _Currency;

        private string _TypeDoc;

        private string _CompanyId;

        private System.Nullable<bool> _IsValidated;

        private System.Nullable<int> _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnDateChanging(string value);
        partial void OnDateChanged();
        partial void OnNumPieceChanging(string value);
        partial void OnNumPieceChanged();
        partial void OnAccountIDChanging(string value);
        partial void OnAccountIDChanged();
        partial void OnOAccountIDChanging(string value);
        partial void OnOAccountIDChanged();
        partial void OnOwnerChanging(string value);
        partial void OnOwnerChanged();
        partial void OnTextChanging(string value);
        partial void OnTextChanged();
        partial void OnDebitChanging(string value);
        partial void OnDebitChanged();
        partial void OnCreditChanging(string value);
        partial void OnCreditChanged();
        partial void OnCurrencyChanging(string value);
        partial void OnCurrencyChanged();
        partial void OnTypeDocChanging(string value);
        partial void OnTypeDocChanged();
        partial void OnCompanyIdChanging(string value);
        partial void OnCompanyIdChanged();
        partial void OnIsValidatedChanging(System.Nullable<bool> value);
        partial void OnIsValidatedChanged();
        partial void OnModelIdChanging(System.Nullable<int> value);
        partial void OnModelIdChanged();
        #endregion

        public Brouillard()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Date", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Date
        {
            get
            {
                return this._Date;
            }
            set
            {
                if ((this._Date != value))
                {
                    this.OnDateChanging(value);
                    this.SendPropertyChanging();
                    this._Date = value;
                    this.SendPropertyChanged("Date");
                    this.OnDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_NumPiece", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string NumPiece
        {
            get
            {
                return this._NumPiece;
            }
            set
            {
                if ((this._NumPiece != value))
                {
                    this.OnNumPieceChanging(value);
                    this.SendPropertyChanging();
                    this._NumPiece = value;
                    this.SendPropertyChanged("NumPiece");
                    this.OnNumPieceChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountID", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string AccountID
        {
            get
            {
                return this._AccountID;
            }
            set
            {
                if ((this._AccountID != value))
                {
                    this.OnAccountIDChanging(value);
                    this.SendPropertyChanging();
                    this._AccountID = value;
                    this.SendPropertyChanged("AccountID");
                    this.OnAccountIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OAccountID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string OAccountID
        {
            get
            {
                return this._OAccountID;
            }
            set
            {
                if ((this._OAccountID != value))
                {
                    this.OnOAccountIDChanging(value);
                    this.SendPropertyChanging();
                    this._OAccountID = value;
                    this.SendPropertyChanged("OAccountID");
                    this.OnOAccountIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Owner", DbType = "NVarChar(10)")]
        public string Owner
        {
            get
            {
                return this._Owner;
            }
            set
            {
                if ((this._Owner != value))
                {
                    this.OnOwnerChanging(value);
                    this.SendPropertyChanging();
                    this._Owner = value;
                    this.SendPropertyChanged("Owner");
                    this.OnOwnerChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Text", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string Text
        {
            get
            {
                return this._Text;
            }
            set
            {
                if ((this._Text != value))
                {
                    this.OnTextChanging(value);
                    this.SendPropertyChanging();
                    this._Text = value;
                    this.SendPropertyChanged("Text");
                    this.OnTextChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Debit", DbType = "NVarChar(50)")]
        public string Debit
        {
            get
            {
                return this._Debit;
            }
            set
            {
                if ((this._Debit != value))
                {
                    this.OnDebitChanging(value);
                    this.SendPropertyChanging();
                    this._Debit = value;
                    this.SendPropertyChanged("Debit");
                    this.OnDebitChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Credit", DbType = "NVarChar(50)")]
        public string Credit
        {
            get
            {
                return this._Credit;
            }
            set
            {
                if ((this._Credit != value))
                {
                    this.OnCreditChanging(value);
                    this.SendPropertyChanging();
                    this._Credit = value;
                    this.SendPropertyChanged("Credit");
                    this.OnCreditChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this.OnCurrencyChanging(value);
                    this.SendPropertyChanging();
                    this._Currency = value;
                    this.SendPropertyChanged("Currency");
                    this.OnCurrencyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TypeDoc", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string TypeDoc
        {
            get
            {
                return this._TypeDoc;
            }
            set
            {
                if ((this._TypeDoc != value))
                {
                    this.OnTypeDocChanging(value);
                    this.SendPropertyChanging();
                    this._TypeDoc = value;
                    this.SendPropertyChanged("TypeDoc");
                    this.OnTypeDocChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyId
        {
            get
            {
                return this._CompanyId;
            }
            set
            {
                if ((this._CompanyId != value))
                {
                    this.OnCompanyIdChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyId = value;
                    this.SendPropertyChanged("CompanyId");
                    this.OnCompanyIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsValidated", DbType = "Bit")]
        public System.Nullable<bool> IsValidated
        {
            get
            {
                return this._IsValidated;
            }
            set
            {
                if ((this._IsValidated != value))
                {
                    this.OnIsValidatedChanging(value);
                    this.SendPropertyChanging();
                    this._IsValidated = value;
                    this.SendPropertyChanged("IsValidated");
                    this.OnIsValidatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int")]
        public System.Nullable<int> ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Cash")]
    public partial class Cash : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private string _Account;

        private string _SYear;

        private string _SMonth;

        private System.Nullable<decimal> _Report;

        private string _CompanyId;

        private System.Nullable<bool> _IsValidated;

        private System.Nullable<int> _ModelId;

        private EntitySet<CashLine> _CashLines;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnAccountChanging(string value);
        partial void OnAccountChanged();
        partial void OnSYearChanging(string value);
        partial void OnSYearChanged();
        partial void OnSMonthChanging(string value);
        partial void OnSMonthChanged();
        partial void OnReportChanging(System.Nullable<decimal> value);
        partial void OnReportChanged();
        partial void OnCompanyIdChanging(string value);
        partial void OnCompanyIdChanged();
        partial void OnIsValidatedChanging(System.Nullable<bool> value);
        partial void OnIsValidatedChanged();
        partial void OnModelIdChanging(System.Nullable<int> value);
        partial void OnModelIdChanged();
        #endregion

        public Cash()
        {
            this._CashLines = new EntitySet<CashLine>(new Action<CashLine>(this.attach_CashLines), new Action<CashLine>(this.detach_CashLines));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Account", DbType = "NVarChar(10)")]
        public string Account
        {
            get
            {
                return this._Account;
            }
            set
            {
                if ((this._Account != value))
                {
                    this.OnAccountChanging(value);
                    this.SendPropertyChanging();
                    this._Account = value;
                    this.SendPropertyChanged("Account");
                    this.OnAccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SYear", DbType = "NChar(4) NOT NULL", CanBeNull = false)]
        public string SYear
        {
            get
            {
                return this._SYear;
            }
            set
            {
                if ((this._SYear != value))
                {
                    this.OnSYearChanging(value);
                    this.SendPropertyChanging();
                    this._SYear = value;
                    this.SendPropertyChanged("SYear");
                    this.OnSYearChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SMonth", DbType = "NChar(20) NOT NULL", CanBeNull = false)]
        public string SMonth
        {
            get
            {
                return this._SMonth;
            }
            set
            {
                if ((this._SMonth != value))
                {
                    this.OnSMonthChanging(value);
                    this.SendPropertyChanging();
                    this._SMonth = value;
                    this.SendPropertyChanged("SMonth");
                    this.OnSMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Report", DbType = "Money")]
        public System.Nullable<decimal> Report
        {
            get
            {
                return this._Report;
            }
            set
            {
                if ((this._Report != value))
                {
                    this.OnReportChanging(value);
                    this.SendPropertyChanging();
                    this._Report = value;
                    this.SendPropertyChanged("Report");
                    this.OnReportChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyId", DbType = "NChar(10) NOT NULL", CanBeNull = false)]
        public string CompanyId
        {
            get
            {
                return this._CompanyId;
            }
            set
            {
                if ((this._CompanyId != value))
                {
                    this.OnCompanyIdChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyId = value;
                    this.SendPropertyChanged("CompanyId");
                    this.OnCompanyIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsValidated", DbType = "Bit")]
        public System.Nullable<bool> IsValidated
        {
            get
            {
                return this._IsValidated;
            }
            set
            {
                if ((this._IsValidated != value))
                {
                    this.OnIsValidatedChanging(value);
                    this.SendPropertyChanging();
                    this._IsValidated = value;
                    this.SendPropertyChanged("IsValidated");
                    this.OnIsValidatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int")]
        public System.Nullable<int> ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Cash_CashLine", Storage = "_CashLines", ThisKey = "Id", OtherKey = "TransId")]
        public EntitySet<CashLine> CashLines
        {
            get
            {
                return this._CashLines;
            }
            set
            {
                this._CashLines.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_CashLines(CashLine entity)
        {
            this.SendPropertyChanging();
            entity.Cash = this;
        }

        private void detach_CashLines(CashLine entity)
        {
            this.SendPropertyChanging();
            entity.Cash = null;
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.CashLine")]
    public partial class CashLine : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private int _TransId;

        private decimal _Einnahmen;

        private decimal _Ausgaben;

        private decimal _Bestand;

        private string _Currency;

        private string _konto;

        private System.Nullable<bool> _Side;

        private string _Gegenkonto;

        private string _BelegNr;

        private System.DateTime _Datum;

        private string _SteuerSatz;

        private string _Beschreibung;

        private string _CostCenter;

        private System.Nullable<int> _ModelId;

        private EntityRef<Cash> _Cash;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnTransIdChanging(int value);
        partial void OnTransIdChanged();
        partial void OnEinnahmenChanging(decimal value);
        partial void OnEinnahmenChanged();
        partial void OnAusgabenChanging(decimal value);
        partial void OnAusgabenChanged();
        partial void OnBestandChanging(decimal value);
        partial void OnBestandChanged();
        partial void OnCurrencyChanging(string value);
        partial void OnCurrencyChanged();
        partial void OnkontoChanging(string value);
        partial void OnkontoChanged();
        partial void OnSideChanging(System.Nullable<bool> value);
        partial void OnSideChanged();
        partial void OnGegenkontoChanging(string value);
        partial void OnGegenkontoChanged();
        partial void OnBelegNrChanging(string value);
        partial void OnBelegNrChanged();
        partial void OnDatumChanging(System.DateTime value);
        partial void OnDatumChanged();
        partial void OnSteuerSatzChanging(string value);
        partial void OnSteuerSatzChanged();
        partial void OnBeschreibungChanging(string value);
        partial void OnBeschreibungChanged();
        partial void OnCostCenterChanging(string value);
        partial void OnCostCenterChanged();
        partial void OnModelIdChanging(System.Nullable<int> value);
        partial void OnModelIdChanged();
        #endregion

        public CashLine()
        {
            this._Cash = default(EntityRef<Cash>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TransId", DbType = "Int NOT NULL")]
        public int TransId
        {
            get
            {
                return this._TransId;
            }
            set
            {
                if ((this._TransId != value))
                {
                    if (this._Cash.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnTransIdChanging(value);
                    this.SendPropertyChanging();
                    this._TransId = value;
                    this.SendPropertyChanged("TransId");
                    this.OnTransIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Einnahmen", DbType = "Money NOT NULL")]
        public decimal Einnahmen
        {
            get
            {
                return this._Einnahmen;
            }
            set
            {
                if ((this._Einnahmen != value))
                {
                    this.OnEinnahmenChanging(value);
                    this.SendPropertyChanging();
                    this._Einnahmen = value;
                    this.SendPropertyChanged("Einnahmen");
                    this.OnEinnahmenChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Ausgaben", DbType = "Money NOT NULL")]
        public decimal Ausgaben
        {
            get
            {
                return this._Ausgaben;
            }
            set
            {
                if ((this._Ausgaben != value))
                {
                    this.OnAusgabenChanging(value);
                    this.SendPropertyChanging();
                    this._Ausgaben = value;
                    this.SendPropertyChanged("Ausgaben");
                    this.OnAusgabenChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Bestand", DbType = "Money NOT NULL")]
        public decimal Bestand
        {
            get
            {
                return this._Bestand;
            }
            set
            {
                if ((this._Bestand != value))
                {
                    this.OnBestandChanging(value);
                    this.SendPropertyChanging();
                    this._Bestand = value;
                    this.SendPropertyChanged("Bestand");
                    this.OnBestandChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10)")]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this.OnCurrencyChanging(value);
                    this.SendPropertyChanging();
                    this._Currency = value;
                    this.SendPropertyChanged("Currency");
                    this.OnCurrencyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_konto", DbType = "NVarChar(50)")]
        public string konto
        {
            get
            {
                return this._konto;
            }
            set
            {
                if ((this._konto != value))
                {
                    this.OnkontoChanging(value);
                    this.SendPropertyChanging();
                    this._konto = value;
                    this.SendPropertyChanged("konto");
                    this.OnkontoChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Side", DbType = "Bit")]
        public System.Nullable<bool> Side
        {
            get
            {
                return this._Side;
            }
            set
            {
                if ((this._Side != value))
                {
                    this.OnSideChanging(value);
                    this.SendPropertyChanging();
                    this._Side = value;
                    this.SendPropertyChanged("Side");
                    this.OnSideChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Gegenkonto", DbType = "NVarChar(50)")]
        public string Gegenkonto
        {
            get
            {
                return this._Gegenkonto;
            }
            set
            {
                if ((this._Gegenkonto != value))
                {
                    this.OnGegenkontoChanging(value);
                    this.SendPropertyChanging();
                    this._Gegenkonto = value;
                    this.SendPropertyChanged("Gegenkonto");
                    this.OnGegenkontoChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_BelegNr", DbType = "NVarChar(50)")]
        public string BelegNr
        {
            get
            {
                return this._BelegNr;
            }
            set
            {
                if ((this._BelegNr != value))
                {
                    this.OnBelegNrChanging(value);
                    this.SendPropertyChanging();
                    this._BelegNr = value;
                    this.SendPropertyChanged("BelegNr");
                    this.OnBelegNrChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Datum", DbType = "Date NOT NULL")]
        public System.DateTime Datum
        {
            get
            {
                return this._Datum;
            }
            set
            {
                if ((this._Datum != value))
                {
                    this.OnDatumChanging(value);
                    this.SendPropertyChanging();
                    this._Datum = value;
                    this.SendPropertyChanged("Datum");
                    this.OnDatumChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SteuerSatz", DbType = "NVarChar(50)")]
        public string SteuerSatz
        {
            get
            {
                return this._SteuerSatz;
            }
            set
            {
                if ((this._SteuerSatz != value))
                {
                    this.OnSteuerSatzChanging(value);
                    this.SendPropertyChanging();
                    this._SteuerSatz = value;
                    this.SendPropertyChanged("SteuerSatz");
                    this.OnSteuerSatzChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Beschreibung", DbType = "NVarChar(256)")]
        public string Beschreibung
        {
            get
            {
                return this._Beschreibung;
            }
            set
            {
                if ((this._Beschreibung != value))
                {
                    this.OnBeschreibungChanging(value);
                    this.SendPropertyChanging();
                    this._Beschreibung = value;
                    this.SendPropertyChanged("Beschreibung");
                    this.OnBeschreibungChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CostCenter", DbType = "NVarChar(10)")]
        public string CostCenter
        {
            get
            {
                return this._CostCenter;
            }
            set
            {
                if ((this._CostCenter != value))
                {
                    this.OnCostCenterChanging(value);
                    this.SendPropertyChanging();
                    this._CostCenter = value;
                    this.SendPropertyChanged("CostCenter");
                    this.OnCostCenterChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int")]
        public System.Nullable<int> ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Cash_CashLine", Storage = "_Cash", ThisKey = "TransId", OtherKey = "Id", IsForeignKey = true, DeleteOnNull = true, DeleteRule = "CASCADE")]
        public Cash Cash
        {
            get
            {
                return this._Cash.Entity;
            }
            set
            {
                Cash previousValue = this._Cash.Entity;
                if (((previousValue != value)
                            || (this._Cash.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Cash.Entity = null;
                        previousValue.CashLines.Remove(this);
                    }
                    this._Cash.Entity = value;
                    if ((value != null))
                    {
                        value.CashLines.Add(this);
                        this._TransId = value.Id;
                    }
                    else
                    {
                        this._TransId = default(int);
                    }
                    this.SendPropertyChanged("Cash");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Category")]
    public partial class Category : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _id;

        private string _name;

        private string _description;

        private string _CompanyID;

        private System.Nullable<int> _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(string value);
        partial void OnidChanged();
        partial void OnnameChanging(string value);
        partial void OnnameChanged();
        partial void OndescriptionChanging(string value);
        partial void OndescriptionChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnModelIdChanging(System.Nullable<int> value);
        partial void OnModelIdChanged();
        #endregion

        public Category()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this.OnnameChanging(value);
                    this.SendPropertyChanging();
                    this._name = value;
                    this.SendPropertyChanged("name");
                    this.OnnameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_description", DbType = "NVarChar(255)")]
        public string description
        {
            get
            {
                return this._description;
            }
            set
            {
                if ((this._description != value))
                {
                    this.OndescriptionChanging(value);
                    this.SendPropertyChanging();
                    this._description = value;
                    this.SendPropertyChanged("description");
                    this.OndescriptionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int")]
        public System.Nullable<int> ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.ClassSetup")]
    public partial class ClassSetup : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private string _ClassID;

        private string _RoleID;

        private string _CompanyID;

        private EntityRef<Account> _Account;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnClassIDChanging(string value);
        partial void OnClassIDChanged();
        partial void OnRoleIDChanging(string value);
        partial void OnRoleIDChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        #endregion

        public ClassSetup()
        {
            this._Account = default(EntityRef<Account>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ClassID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string ClassID
        {
            get
            {
                return this._ClassID;
            }
            set
            {
                if ((this._ClassID != value))
                {
                    if (this._Account.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnClassIDChanging(value);
                    this.SendPropertyChanging();
                    this._ClassID = value;
                    this.SendPropertyChanged("ClassID");
                    this.OnClassIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_RoleID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string RoleID
        {
            get
            {
                return this._RoleID;
            }
            set
            {
                if ((this._RoleID != value))
                {
                    this.OnRoleIDChanging(value);
                    this.SendPropertyChanging();
                    this._RoleID = value;
                    this.SendPropertyChanged("RoleID");
                    this.OnRoleIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_ClassSetup", Storage = "_Account", ThisKey = "ClassID", OtherKey = "id", IsForeignKey = true)]
        public Account Account
        {
            get
            {
                return this._Account.Entity;
            }
            set
            {
                Account previousValue = this._Account.Entity;
                if (((previousValue != value)
                            || (this._Account.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Account.Entity = null;
                        previousValue.ClassSetups.Remove(this);
                    }
                    this._Account.Entity = value;
                    if ((value != null))
                    {
                        value.ClassSetups.Add(this);
                        this._ClassID = value.id;
                    }
                    else
                    {
                        this._ClassID = default(string);
                    }
                    this.SendPropertyChanged("Account");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Company")]
    public partial class Company : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _id;

        private string _name;

        private string _street;

        private string _city;

        private string _state;

        private string _zip;

        private string _bankaccountid;

        private string _purchasingclearingaccountid;

        private string _salesclearingaccountid;

        private string _paymentclearingaccountid;

        private string _settlementclearingaccountid;

        private string _taxcode;

        private string _vatcode;

        private string _Currency;

        private string _IBAN;

        private string _CIF;

        private string _BalanceSheet;

        private string _IncomesStatement;

        private string _CashAccountId;

        private System.DateTime _Posted;

        private System.DateTime _Updated;

        private string _ClassCash;

        private string _ClassBank;

        private int _ModelId;

        private string _PageHeaderText;

        private string _PageFooterText;

        private string _HeaderText;

        private string _FooterText;

        private string _LogoName;

        private string _ContentType;

        private string _Partner;

        private string _Tel;

        private string _Fax;

        private string _Email;

        private EntitySet<AffectationJournal> _AffectationJournals;

        private EntitySet<MasterCompta> _MasterComptas;

        private EntitySet<MasterLogistic> _MasterLogistics;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(string value);
        partial void OnidChanged();
        partial void OnnameChanging(string value);
        partial void OnnameChanged();
        partial void OnstreetChanging(string value);
        partial void OnstreetChanged();
        partial void OncityChanging(string value);
        partial void OncityChanged();
        partial void OnstateChanging(string value);
        partial void OnstateChanged();
        partial void OnzipChanging(string value);
        partial void OnzipChanged();
        partial void OnbankaccountidChanging(string value);
        partial void OnbankaccountidChanged();
        partial void OnpurchasingclearingaccountidChanging(string value);
        partial void OnpurchasingclearingaccountidChanged();
        partial void OnsalesclearingaccountidChanging(string value);
        partial void OnsalesclearingaccountidChanged();
        partial void OnpaymentclearingaccountidChanging(string value);
        partial void OnpaymentclearingaccountidChanged();
        partial void OnsettlementclearingaccountidChanging(string value);
        partial void OnsettlementclearingaccountidChanged();
        partial void OntaxcodeChanging(string value);
        partial void OntaxcodeChanged();
        partial void OnvatcodeChanging(string value);
        partial void OnvatcodeChanged();
        partial void OnCurrencyChanging(string value);
        partial void OnCurrencyChanged();
        partial void OnIBANChanging(string value);
        partial void OnIBANChanged();
        partial void OnCIFChanging(string value);
        partial void OnCIFChanged();
        partial void OnBalanceSheetChanging(string value);
        partial void OnBalanceSheetChanged();
        partial void OnIncomesStatementChanging(string value);
        partial void OnIncomesStatementChanged();
        partial void OnCashAccountIdChanging(string value);
        partial void OnCashAccountIdChanged();
        partial void OnPostedChanging(System.DateTime value);
        partial void OnPostedChanged();
        partial void OnUpdatedChanging(System.DateTime value);
        partial void OnUpdatedChanged();
        partial void OnClassCashChanging(string value);
        partial void OnClassCashChanged();
        partial void OnClassBankChanging(string value);
        partial void OnClassBankChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        partial void OnPageHeaderTextChanging(string value);
        partial void OnPageHeaderTextChanged();
        partial void OnPageFooterTextChanging(string value);
        partial void OnPageFooterTextChanged();
        partial void OnHeaderTextChanging(string value);
        partial void OnHeaderTextChanged();
        partial void OnFooterTextChanging(string value);
        partial void OnFooterTextChanged();
        partial void OnLogoNameChanging(string value);
        partial void OnLogoNameChanged();
        partial void OnContentTypeChanging(string value);
        partial void OnContentTypeChanged();
        partial void OnPartnerChanging(string value);
        partial void OnPartnerChanged();
        partial void OnTelChanging(string value);
        partial void OnTelChanged();
        partial void OnFaxChanging(string value);
        partial void OnFaxChanged();
        partial void OnEmailChanging(string value);
        partial void OnEmailChanged();
        #endregion

        public Company()
        {
            this._AffectationJournals = new EntitySet<AffectationJournal>(new Action<AffectationJournal>(this.attach_AffectationJournals), new Action<AffectationJournal>(this.detach_AffectationJournals));
            this._MasterComptas = new EntitySet<MasterCompta>(new Action<MasterCompta>(this.attach_MasterComptas), new Action<MasterCompta>(this.detach_MasterComptas));
            this._MasterLogistics = new EntitySet<MasterLogistic>(new Action<MasterLogistic>(this.attach_MasterLogistics), new Action<MasterLogistic>(this.detach_MasterLogistics));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this.OnnameChanging(value);
                    this.SendPropertyChanging();
                    this._name = value;
                    this.SendPropertyChanged("name");
                    this.OnnameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_street", DbType = "NVarChar(255)")]
        public string street
        {
            get
            {
                return this._street;
            }
            set
            {
                if ((this._street != value))
                {
                    this.OnstreetChanging(value);
                    this.SendPropertyChanging();
                    this._street = value;
                    this.SendPropertyChanged("street");
                    this.OnstreetChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_city", DbType = "NVarChar(255)")]
        public string city
        {
            get
            {
                return this._city;
            }
            set
            {
                if ((this._city != value))
                {
                    this.OncityChanging(value);
                    this.SendPropertyChanging();
                    this._city = value;
                    this.SendPropertyChanged("city");
                    this.OncityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_state", DbType = "NVarChar(255)")]
        public string state
        {
            get
            {
                return this._state;
            }
            set
            {
                if ((this._state != value))
                {
                    this.OnstateChanging(value);
                    this.SendPropertyChanging();
                    this._state = value;
                    this.SendPropertyChanged("state");
                    this.OnstateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_zip", DbType = "NVarChar(255)")]
        public string zip
        {
            get
            {
                return this._zip;
            }
            set
            {
                if ((this._zip != value))
                {
                    this.OnzipChanging(value);
                    this.SendPropertyChanging();
                    this._zip = value;
                    this.SendPropertyChanged("zip");
                    this.OnzipChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_bankaccountid", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string bankaccountid
        {
            get
            {
                return this._bankaccountid;
            }
            set
            {
                if ((this._bankaccountid != value))
                {
                    this.OnbankaccountidChanging(value);
                    this.SendPropertyChanging();
                    this._bankaccountid = value;
                    this.SendPropertyChanged("bankaccountid");
                    this.OnbankaccountidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_purchasingclearingaccountid", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string purchasingclearingaccountid
        {
            get
            {
                return this._purchasingclearingaccountid;
            }
            set
            {
                if ((this._purchasingclearingaccountid != value))
                {
                    this.OnpurchasingclearingaccountidChanging(value);
                    this.SendPropertyChanging();
                    this._purchasingclearingaccountid = value;
                    this.SendPropertyChanged("purchasingclearingaccountid");
                    this.OnpurchasingclearingaccountidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_salesclearingaccountid", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string salesclearingaccountid
        {
            get
            {
                return this._salesclearingaccountid;
            }
            set
            {
                if ((this._salesclearingaccountid != value))
                {
                    this.OnsalesclearingaccountidChanging(value);
                    this.SendPropertyChanging();
                    this._salesclearingaccountid = value;
                    this.SendPropertyChanged("salesclearingaccountid");
                    this.OnsalesclearingaccountidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_paymentclearingaccountid", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string paymentclearingaccountid
        {
            get
            {
                return this._paymentclearingaccountid;
            }
            set
            {
                if ((this._paymentclearingaccountid != value))
                {
                    this.OnpaymentclearingaccountidChanging(value);
                    this.SendPropertyChanging();
                    this._paymentclearingaccountid = value;
                    this.SendPropertyChanged("paymentclearingaccountid");
                    this.OnpaymentclearingaccountidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_settlementclearingaccountid", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string settlementclearingaccountid
        {
            get
            {
                return this._settlementclearingaccountid;
            }
            set
            {
                if ((this._settlementclearingaccountid != value))
                {
                    this.OnsettlementclearingaccountidChanging(value);
                    this.SendPropertyChanging();
                    this._settlementclearingaccountid = value;
                    this.SendPropertyChanged("settlementclearingaccountid");
                    this.OnsettlementclearingaccountidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_taxcode", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string taxcode
        {
            get
            {
                return this._taxcode;
            }
            set
            {
                if ((this._taxcode != value))
                {
                    this.OntaxcodeChanging(value);
                    this.SendPropertyChanging();
                    this._taxcode = value;
                    this.SendPropertyChanged("taxcode");
                    this.OntaxcodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_vatcode", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string vatcode
        {
            get
            {
                return this._vatcode;
            }
            set
            {
                if ((this._vatcode != value))
                {
                    this.OnvatcodeChanging(value);
                    this.SendPropertyChanging();
                    this._vatcode = value;
                    this.SendPropertyChanged("vatcode");
                    this.OnvatcodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this.OnCurrencyChanging(value);
                    this.SendPropertyChanging();
                    this._Currency = value;
                    this.SendPropertyChanged("Currency");
                    this.OnCurrencyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IBAN", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string IBAN
        {
            get
            {
                return this._IBAN;
            }
            set
            {
                if ((this._IBAN != value))
                {
                    this.OnIBANChanging(value);
                    this.SendPropertyChanging();
                    this._IBAN = value;
                    this.SendPropertyChanged("IBAN");
                    this.OnIBANChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CIF", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CIF
        {
            get
            {
                return this._CIF;
            }
            set
            {
                if ((this._CIF != value))
                {
                    this.OnCIFChanging(value);
                    this.SendPropertyChanging();
                    this._CIF = value;
                    this.SendPropertyChanged("CIF");
                    this.OnCIFChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_BalanceSheet", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string BalanceSheet
        {
            get
            {
                return this._BalanceSheet;
            }
            set
            {
                if ((this._BalanceSheet != value))
                {
                    this.OnBalanceSheetChanging(value);
                    this.SendPropertyChanging();
                    this._BalanceSheet = value;
                    this.SendPropertyChanged("BalanceSheet");
                    this.OnBalanceSheetChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IncomesStatement", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string IncomesStatement
        {
            get
            {
                return this._IncomesStatement;
            }
            set
            {
                if ((this._IncomesStatement != value))
                {
                    this.OnIncomesStatementChanging(value);
                    this.SendPropertyChanging();
                    this._IncomesStatement = value;
                    this.SendPropertyChanged("IncomesStatement");
                    this.OnIncomesStatementChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CashAccountId", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string CashAccountId
        {
            get
            {
                return this._CashAccountId;
            }
            set
            {
                if ((this._CashAccountId != value))
                {
                    this.OnCashAccountIdChanging(value);
                    this.SendPropertyChanging();
                    this._CashAccountId = value;
                    this.SendPropertyChanged("CashAccountId");
                    this.OnCashAccountIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Posted", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Posted
        {
            get
            {
                return this._Posted;
            }
            set
            {
                if ((this._Posted != value))
                {
                    this.OnPostedChanging(value);
                    this.SendPropertyChanging();
                    this._Posted = value;
                    this.SendPropertyChanged("Posted");
                    this.OnPostedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Updated", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Updated
        {
            get
            {
                return this._Updated;
            }
            set
            {
                if ((this._Updated != value))
                {
                    this.OnUpdatedChanging(value);
                    this.SendPropertyChanging();
                    this._Updated = value;
                    this.SendPropertyChanged("Updated");
                    this.OnUpdatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ClassCash", DbType = "VarChar(50) NOT NULL", CanBeNull = false)]
        public string ClassCash
        {
            get
            {
                return this._ClassCash;
            }
            set
            {
                if ((this._ClassCash != value))
                {
                    this.OnClassCashChanging(value);
                    this.SendPropertyChanging();
                    this._ClassCash = value;
                    this.SendPropertyChanged("ClassCash");
                    this.OnClassCashChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ClassBank", DbType = "VarChar(50) NOT NULL", CanBeNull = false)]
        public string ClassBank
        {
            get
            {
                return this._ClassBank;
            }
            set
            {
                if ((this._ClassBank != value))
                {
                    this.OnClassBankChanging(value);
                    this.SendPropertyChanging();
                    this._ClassBank = value;
                    this.SendPropertyChanged("ClassBank");
                    this.OnClassBankChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PageHeaderText", DbType = "NVarChar(350)")]
        public string PageHeaderText
        {
            get
            {
                return this._PageHeaderText;
            }
            set
            {
                if ((this._PageHeaderText != value))
                {
                    this.OnPageHeaderTextChanging(value);
                    this.SendPropertyChanging();
                    this._PageHeaderText = value;
                    this.SendPropertyChanged("PageHeaderText");
                    this.OnPageHeaderTextChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PageFooterText", DbType = "NVarChar(350)")]
        public string PageFooterText
        {
            get
            {
                return this._PageFooterText;
            }
            set
            {
                if ((this._PageFooterText != value))
                {
                    this.OnPageFooterTextChanging(value);
                    this.SendPropertyChanging();
                    this._PageFooterText = value;
                    this.SendPropertyChanged("PageFooterText");
                    this.OnPageFooterTextChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_HeaderText", DbType = "NVarChar(350)")]
        public string HeaderText
        {
            get
            {
                return this._HeaderText;
            }
            set
            {
                if ((this._HeaderText != value))
                {
                    this.OnHeaderTextChanging(value);
                    this.SendPropertyChanging();
                    this._HeaderText = value;
                    this.SendPropertyChanged("HeaderText");
                    this.OnHeaderTextChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FooterText", DbType = "NVarChar(350)")]
        public string FooterText
        {
            get
            {
                return this._FooterText;
            }
            set
            {
                if ((this._FooterText != value))
                {
                    this.OnFooterTextChanging(value);
                    this.SendPropertyChanging();
                    this._FooterText = value;
                    this.SendPropertyChanged("FooterText");
                    this.OnFooterTextChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LogoName", DbType = "NVarChar(50)")]
        public string LogoName
        {
            get
            {
                return this._LogoName;
            }
            set
            {
                if ((this._LogoName != value))
                {
                    this.OnLogoNameChanging(value);
                    this.SendPropertyChanging();
                    this._LogoName = value;
                    this.SendPropertyChanged("LogoName");
                    this.OnLogoNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ContentType", DbType = "NVarChar(50)")]
        public string ContentType
        {
            get
            {
                return this._ContentType;
            }
            set
            {
                if ((this._ContentType != value))
                {
                    this.OnContentTypeChanging(value);
                    this.SendPropertyChanging();
                    this._ContentType = value;
                    this.SendPropertyChanged("ContentType");
                    this.OnContentTypeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Partner", DbType = "NVarChar(250)")]
        public string Partner
        {
            get
            {
                return this._Partner;
            }
            set
            {
                if ((this._Partner != value))
                {
                    this.OnPartnerChanging(value);
                    this.SendPropertyChanging();
                    this._Partner = value;
                    this.SendPropertyChanged("Partner");
                    this.OnPartnerChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Tel", DbType = "NVarChar(50)")]
        public string Tel
        {
            get
            {
                return this._Tel;
            }
            set
            {
                if ((this._Tel != value))
                {
                    this.OnTelChanging(value);
                    this.SendPropertyChanging();
                    this._Tel = value;
                    this.SendPropertyChanged("Tel");
                    this.OnTelChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Fax", DbType = "NVarChar(50)")]
        public string Fax
        {
            get
            {
                return this._Fax;
            }
            set
            {
                if ((this._Fax != value))
                {
                    this.OnFaxChanging(value);
                    this.SendPropertyChanging();
                    this._Fax = value;
                    this.SendPropertyChanged("Fax");
                    this.OnFaxChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Email", DbType = "NVarChar(50)")]
        public string Email
        {
            get
            {
                return this._Email;
            }
            set
            {
                if ((this._Email != value))
                {
                    this.OnEmailChanging(value);
                    this.SendPropertyChanging();
                    this._Email = value;
                    this.SendPropertyChanged("Email");
                    this.OnEmailChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Company_AffectationJournal", Storage = "_AffectationJournals", ThisKey = "id", OtherKey = "CompanyID")]
        public EntitySet<AffectationJournal> AffectationJournals
        {
            get
            {
                return this._AffectationJournals;
            }
            set
            {
                this._AffectationJournals.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Company_MasterCompta", Storage = "_MasterComptas", ThisKey = "id", OtherKey = "CompanyId")]
        public EntitySet<MasterCompta> MasterComptas
        {
            get
            {
                return this._MasterComptas;
            }
            set
            {
                this._MasterComptas.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Company_MasterLogistic", Storage = "_MasterLogistics", ThisKey = "id", OtherKey = "CompanyId")]
        public EntitySet<MasterLogistic> MasterLogistics
        {
            get
            {
                return this._MasterLogistics;
            }
            set
            {
                this._MasterLogistics.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_AffectationJournals(AffectationJournal entity)
        {
            this.SendPropertyChanging();
            entity.Company = this;
        }

        private void detach_AffectationJournals(AffectationJournal entity)
        {
            this.SendPropertyChanging();
            entity.Company = null;
        }

        private void attach_MasterComptas(MasterCompta entity)
        {
            this.SendPropertyChanging();
            entity.Company = this;
        }

        private void detach_MasterComptas(MasterCompta entity)
        {
            this.SendPropertyChanging();
            entity.Company = null;
        }

        private void attach_MasterLogistics(MasterLogistic entity)
        {
            this.SendPropertyChanging();
            entity.Company = this;
        }

        private void detach_MasterLogistics(MasterLogistic entity)
        {
            this.SendPropertyChanging();
            entity.Company = null;
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.CostCenter")]
    public partial class CostCenter : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _id;

        private string _name;

        private string _description;

        private string _accountid;

        private string _CompanyID;

        private System.DateTime _Posted;

        private System.DateTime _Updated;

        private int _ModelId;

        private EntitySet<MasterCompta> _MasterComptas;

        private EntityRef<Account> _Account;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(string value);
        partial void OnidChanged();
        partial void OnnameChanging(string value);
        partial void OnnameChanged();
        partial void OndescriptionChanging(string value);
        partial void OndescriptionChanged();
        partial void OnaccountidChanging(string value);
        partial void OnaccountidChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnPostedChanging(System.DateTime value);
        partial void OnPostedChanged();
        partial void OnUpdatedChanging(System.DateTime value);
        partial void OnUpdatedChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public CostCenter()
        {
            this._MasterComptas = new EntitySet<MasterCompta>(new Action<MasterCompta>(this.attach_MasterComptas), new Action<MasterCompta>(this.detach_MasterComptas));
            this._Account = default(EntityRef<Account>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this.OnnameChanging(value);
                    this.SendPropertyChanging();
                    this._name = value;
                    this.SendPropertyChanged("name");
                    this.OnnameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_description", DbType = "NVarChar(255)")]
        public string description
        {
            get
            {
                return this._description;
            }
            set
            {
                if ((this._description != value))
                {
                    this.OndescriptionChanging(value);
                    this.SendPropertyChanging();
                    this._description = value;
                    this.SendPropertyChanged("description");
                    this.OndescriptionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_accountid", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string accountid
        {
            get
            {
                return this._accountid;
            }
            set
            {
                if ((this._accountid != value))
                {
                    if (this._Account.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnaccountidChanging(value);
                    this.SendPropertyChanging();
                    this._accountid = value;
                    this.SendPropertyChanged("accountid");
                    this.OnaccountidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Posted", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Posted
        {
            get
            {
                return this._Posted;
            }
            set
            {
                if ((this._Posted != value))
                {
                    this.OnPostedChanging(value);
                    this.SendPropertyChanging();
                    this._Posted = value;
                    this.SendPropertyChanged("Posted");
                    this.OnPostedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Updated", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Updated
        {
            get
            {
                return this._Updated;
            }
            set
            {
                if ((this._Updated != value))
                {
                    this.OnUpdatedChanging(value);
                    this.SendPropertyChanging();
                    this._Updated = value;
                    this.SendPropertyChanged("Updated");
                    this.OnUpdatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "CostCenter_MasterCompta", Storage = "_MasterComptas", ThisKey = "id", OtherKey = "CostCenter")]
        public EntitySet<MasterCompta> MasterComptas
        {
            get
            {
                return this._MasterComptas;
            }
            set
            {
                this._MasterComptas.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_CostCenter", Storage = "_Account", ThisKey = "accountid", OtherKey = "id", IsForeignKey = true)]
        public Account Account
        {
            get
            {
                return this._Account.Entity;
            }
            set
            {
                Account previousValue = this._Account.Entity;
                if (((previousValue != value)
                            || (this._Account.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Account.Entity = null;
                        previousValue.CostCenters.Remove(this);
                    }
                    this._Account.Entity = value;
                    if ((value != null))
                    {
                        value.CostCenters.Add(this);
                        this._accountid = value.id;
                    }
                    else
                    {
                        this._accountid = default(string);
                    }
                    this.SendPropertyChanged("Account");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_MasterComptas(MasterCompta entity)
        {
            this.SendPropertyChanging();
            entity.CostCenter1 = this;
        }

        private void detach_MasterComptas(MasterCompta entity)
        {
            this.SendPropertyChanging();
            entity.CostCenter1 = null;
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Currency")]
    public partial class Currency : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _Id;

        private string _Name;

        private string _CompanyID;

        private string _Description;

        private System.DateTime _Posted;

        private System.DateTime _Updated;

        private int _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(string value);
        partial void OnIdChanged();
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnDescriptionChanging(string value);
        partial void OnDescriptionChanged();
        partial void OnPostedChanging(System.DateTime value);
        partial void OnPostedChanged();
        partial void OnUpdatedChanging(System.DateTime value);
        partial void OnUpdatedChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public Currency()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", DbType = "NVarChar(10) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this.OnNameChanging(value);
                    this.SendPropertyChanging();
                    this._Name = value;
                    this.SendPropertyChanged("Name");
                    this.OnNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Description", DbType = "NVarChar(255)")]
        public string Description
        {
            get
            {
                return this._Description;
            }
            set
            {
                if ((this._Description != value))
                {
                    this.OnDescriptionChanging(value);
                    this.SendPropertyChanging();
                    this._Description = value;
                    this.SendPropertyChanged("Description");
                    this.OnDescriptionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Posted", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Posted
        {
            get
            {
                return this._Posted;
            }
            set
            {
                if ((this._Posted != value))
                {
                    this.OnPostedChanging(value);
                    this.SendPropertyChanging();
                    this._Posted = value;
                    this.SendPropertyChanged("Posted");
                    this.OnPostedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Updated", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Updated
        {
            get
            {
                return this._Updated;
            }
            set
            {
                if ((this._Updated != value))
                {
                    this.OnUpdatedChanging(value);
                    this.SendPropertyChanging();
                    this._Updated = value;
                    this.SendPropertyChanged("Updated");
                    this.OnUpdatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Customer")]
    public partial class Customer : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _id;

        private string _name;

        private string _street;

        private string _city;

        private string _state;

        private string _zip;

        private string _Phone;

        private string _Email;

        private string _accountid;

        private string _CompanyID;

        private string _IBAN;

        private string _Bank;

        private string _BIC;

        private string _VatCode;

        private string _Produit;

        private System.DateTime _Posted;

        private System.DateTime _Updated;

        private int _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(string value);
        partial void OnidChanged();
        partial void OnnameChanging(string value);
        partial void OnnameChanged();
        partial void OnstreetChanging(string value);
        partial void OnstreetChanged();
        partial void OncityChanging(string value);
        partial void OncityChanged();
        partial void OnstateChanging(string value);
        partial void OnstateChanged();
        partial void OnzipChanging(string value);
        partial void OnzipChanged();
        partial void OnPhoneChanging(string value);
        partial void OnPhoneChanged();
        partial void OnEmailChanging(string value);
        partial void OnEmailChanged();
        partial void OnaccountidChanging(string value);
        partial void OnaccountidChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnIBANChanging(string value);
        partial void OnIBANChanged();
        partial void OnBankChanging(string value);
        partial void OnBankChanged();
        partial void OnBICChanging(string value);
        partial void OnBICChanged();
        partial void OnVatCodeChanging(string value);
        partial void OnVatCodeChanged();
        partial void OnProduitChanging(string value);
        partial void OnProduitChanged();
        partial void OnPostedChanging(System.DateTime value);
        partial void OnPostedChanged();
        partial void OnUpdatedChanging(System.DateTime value);
        partial void OnUpdatedChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public Customer()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this.OnnameChanging(value);
                    this.SendPropertyChanging();
                    this._name = value;
                    this.SendPropertyChanged("name");
                    this.OnnameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_street", DbType = "NVarChar(255)")]
        public string street
        {
            get
            {
                return this._street;
            }
            set
            {
                if ((this._street != value))
                {
                    this.OnstreetChanging(value);
                    this.SendPropertyChanging();
                    this._street = value;
                    this.SendPropertyChanged("street");
                    this.OnstreetChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_city", DbType = "NVarChar(255)")]
        public string city
        {
            get
            {
                return this._city;
            }
            set
            {
                if ((this._city != value))
                {
                    this.OncityChanging(value);
                    this.SendPropertyChanging();
                    this._city = value;
                    this.SendPropertyChanged("city");
                    this.OncityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_state", DbType = "NVarChar(255)")]
        public string state
        {
            get
            {
                return this._state;
            }
            set
            {
                if ((this._state != value))
                {
                    this.OnstateChanging(value);
                    this.SendPropertyChanging();
                    this._state = value;
                    this.SendPropertyChanged("state");
                    this.OnstateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_zip", DbType = "NVarChar(255)")]
        public string zip
        {
            get
            {
                return this._zip;
            }
            set
            {
                if ((this._zip != value))
                {
                    this.OnzipChanging(value);
                    this.SendPropertyChanging();
                    this._zip = value;
                    this.SendPropertyChanged("zip");
                    this.OnzipChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Phone", DbType = "NVarChar(50)")]
        public string Phone
        {
            get
            {
                return this._Phone;
            }
            set
            {
                if ((this._Phone != value))
                {
                    this.OnPhoneChanging(value);
                    this.SendPropertyChanging();
                    this._Phone = value;
                    this.SendPropertyChanged("Phone");
                    this.OnPhoneChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Email", DbType = "NVarChar(50)")]
        public string Email
        {
            get
            {
                return this._Email;
            }
            set
            {
                if ((this._Email != value))
                {
                    this.OnEmailChanging(value);
                    this.SendPropertyChanging();
                    this._Email = value;
                    this.SendPropertyChanged("Email");
                    this.OnEmailChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_accountid", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string accountid
        {
            get
            {
                return this._accountid;
            }
            set
            {
                if ((this._accountid != value))
                {
                    this.OnaccountidChanging(value);
                    this.SendPropertyChanging();
                    this._accountid = value;
                    this.SendPropertyChanged("accountid");
                    this.OnaccountidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IBAN", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string IBAN
        {
            get
            {
                return this._IBAN;
            }
            set
            {
                if ((this._IBAN != value))
                {
                    this.OnIBANChanging(value);
                    this.SendPropertyChanging();
                    this._IBAN = value;
                    this.SendPropertyChanged("IBAN");
                    this.OnIBANChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Bank", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string Bank
        {
            get
            {
                return this._Bank;
            }
            set
            {
                if ((this._Bank != value))
                {
                    this.OnBankChanging(value);
                    this.SendPropertyChanging();
                    this._Bank = value;
                    this.SendPropertyChanged("Bank");
                    this.OnBankChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_BIC", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string BIC
        {
            get
            {
                return this._BIC;
            }
            set
            {
                if ((this._BIC != value))
                {
                    this.OnBICChanging(value);
                    this.SendPropertyChanging();
                    this._BIC = value;
                    this.SendPropertyChanged("BIC");
                    this.OnBICChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_VatCode", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string VatCode
        {
            get
            {
                return this._VatCode;
            }
            set
            {
                if ((this._VatCode != value))
                {
                    this.OnVatCodeChanging(value);
                    this.SendPropertyChanging();
                    this._VatCode = value;
                    this.SendPropertyChanged("VatCode");
                    this.OnVatCodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Produit", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string Produit
        {
            get
            {
                return this._Produit;
            }
            set
            {
                if ((this._Produit != value))
                {
                    this.OnProduitChanging(value);
                    this.SendPropertyChanging();
                    this._Produit = value;
                    this.SendPropertyChanged("Produit");
                    this.OnProduitChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Posted", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Posted
        {
            get
            {
                return this._Posted;
            }
            set
            {
                if ((this._Posted != value))
                {
                    this.OnPostedChanging(value);
                    this.SendPropertyChanging();
                    this._Posted = value;
                    this.SendPropertyChanged("Posted");
                    this.OnPostedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Updated", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Updated
        {
            get
            {
                return this._Updated;
            }
            set
            {
                if ((this._Updated != value))
                {
                    this.OnUpdatedChanging(value);
                    this.SendPropertyChanging();
                    this._Updated = value;
                    this.SendPropertyChanged("Updated");
                    this.OnUpdatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.DetailCompta")]
    public partial class DetailCompta : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _id;

        private int _transid;

        private string _account;

        private bool _side;

        private string _oaccount;

        private decimal _amount;

        private System.DateTime _duedate;

        private string _text;

        private string _Currency;

        private int _ModelId;

        private string _Terms;

        private bool _Balanced;

        private EntityRef<Account> _Account1;

        private EntityRef<Account> _Account2;

        private EntityRef<MasterCompta> _MasterCompta;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(int value);
        partial void OnidChanged();
        partial void OntransidChanging(int value);
        partial void OntransidChanged();
        partial void OnaccountChanging(string value);
        partial void OnaccountChanged();
        partial void OnsideChanging(bool value);
        partial void OnsideChanged();
        partial void OnoaccountChanging(string value);
        partial void OnoaccountChanged();
        partial void OnamountChanging(decimal value);
        partial void OnamountChanged();
        partial void OnduedateChanging(System.DateTime value);
        partial void OnduedateChanged();
        partial void OntextChanging(string value);
        partial void OntextChanged();
        partial void OnCurrencyChanging(string value);
        partial void OnCurrencyChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        partial void OnTermsChanging(string value);
        partial void OnTermsChanged();
        partial void OnBalancedChanging(bool value);
        partial void OnBalancedChanged();
        #endregion

        public DetailCompta()
        {
            this._Account1 = default(EntityRef<Account>);
            this._Account2 = default(EntityRef<Account>);
            this._MasterCompta = default(EntityRef<MasterCompta>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_transid", DbType = "Int NOT NULL")]
        public int transid
        {
            get
            {
                return this._transid;
            }
            set
            {
                if ((this._transid != value))
                {
                    if (this._MasterCompta.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OntransidChanging(value);
                    this.SendPropertyChanging();
                    this._transid = value;
                    this.SendPropertyChanged("transid");
                    this.OntransidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_account", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string account
        {
            get
            {
                return this._account;
            }
            set
            {
                if ((this._account != value))
                {
                    if (this._Account1.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnaccountChanging(value);
                    this.SendPropertyChanging();
                    this._account = value;
                    this.SendPropertyChanged("account");
                    this.OnaccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_side", DbType = "Bit NOT NULL")]
        public bool side
        {
            get
            {
                return this._side;
            }
            set
            {
                if ((this._side != value))
                {
                    this.OnsideChanging(value);
                    this.SendPropertyChanging();
                    this._side = value;
                    this.SendPropertyChanged("side");
                    this.OnsideChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oaccount", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string oaccount
        {
            get
            {
                return this._oaccount;
            }
            set
            {
                if ((this._oaccount != value))
                {
                    if (this._Account2.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnoaccountChanging(value);
                    this.SendPropertyChanging();
                    this._oaccount = value;
                    this.SendPropertyChanged("oaccount");
                    this.OnoaccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_amount", DbType = "Money NOT NULL")]
        public decimal amount
        {
            get
            {
                return this._amount;
            }
            set
            {
                if ((this._amount != value))
                {
                    this.OnamountChanging(value);
                    this.SendPropertyChanging();
                    this._amount = value;
                    this.SendPropertyChanged("amount");
                    this.OnamountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_duedate", DbType = "DateTime2 NOT NULL")]
        public System.DateTime duedate
        {
            get
            {
                return this._duedate;
            }
            set
            {
                if ((this._duedate != value))
                {
                    this.OnduedateChanging(value);
                    this.SendPropertyChanging();
                    this._duedate = value;
                    this.SendPropertyChanged("duedate");
                    this.OnduedateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_text", DbType = "NVarChar(250)")]
        public string text
        {
            get
            {
                return this._text;
            }
            set
            {
                if ((this._text != value))
                {
                    this.OntextChanging(value);
                    this.SendPropertyChanging();
                    this._text = value;
                    this.SendPropertyChanged("text");
                    this.OntextChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this.OnCurrencyChanging(value);
                    this.SendPropertyChanging();
                    this._Currency = value;
                    this.SendPropertyChanged("Currency");
                    this.OnCurrencyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Terms", DbType = "VarChar(250)")]
        public string Terms
        {
            get
            {
                return this._Terms;
            }
            set
            {
                if ((this._Terms != value))
                {
                    this.OnTermsChanging(value);
                    this.SendPropertyChanging();
                    this._Terms = value;
                    this.SendPropertyChanged("Terms");
                    this.OnTermsChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Balanced", DbType = "Bit NOT NULL")]
        public bool Balanced
        {
            get
            {
                return this._Balanced;
            }
            set
            {
                if ((this._Balanced != value))
                {
                    this.OnBalancedChanging(value);
                    this.SendPropertyChanging();
                    this._Balanced = value;
                    this.SendPropertyChanged("Balanced");
                    this.OnBalancedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_DetailCompta", Storage = "_Account1", ThisKey = "account", OtherKey = "id", IsForeignKey = true)]
        public Account Account1
        {
            get
            {
                return this._Account1.Entity;
            }
            set
            {
                Account previousValue = this._Account1.Entity;
                if (((previousValue != value)
                            || (this._Account1.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Account1.Entity = null;
                        previousValue.DetailComptas.Remove(this);
                    }
                    this._Account1.Entity = value;
                    if ((value != null))
                    {
                        value.DetailComptas.Add(this);
                        this._account = value.id;
                    }
                    else
                    {
                        this._account = default(string);
                    }
                    this.SendPropertyChanged("Account1");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_DetailCompta1", Storage = "_Account2", ThisKey = "oaccount", OtherKey = "id", IsForeignKey = true)]
        public Account Account2
        {
            get
            {
                return this._Account2.Entity;
            }
            set
            {
                Account previousValue = this._Account2.Entity;
                if (((previousValue != value)
                            || (this._Account2.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Account2.Entity = null;
                        previousValue.DetailComptas1.Remove(this);
                    }
                    this._Account2.Entity = value;
                    if ((value != null))
                    {
                        value.DetailComptas1.Add(this);
                        this._oaccount = value.id;
                    }
                    else
                    {
                        this._oaccount = default(string);
                    }
                    this.SendPropertyChanged("Account2");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "MasterCompta_DetailCompta", Storage = "_MasterCompta", ThisKey = "transid", OtherKey = "id", IsForeignKey = true)]
        public MasterCompta MasterCompta
        {
            get
            {
                return this._MasterCompta.Entity;
            }
            set
            {
                MasterCompta previousValue = this._MasterCompta.Entity;
                if (((previousValue != value)
                            || (this._MasterCompta.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._MasterCompta.Entity = null;
                        previousValue.DetailComptas.Remove(this);
                    }
                    this._MasterCompta.Entity = value;
                    if ((value != null))
                    {
                        value.DetailComptas.Add(this);
                        this._transid = value.id;
                    }
                    else
                    {
                        this._transid = default(int);
                    }
                    this.SendPropertyChanged("MasterCompta");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.DetailDetailCompta")]
    public partial class DetailDetailCompta : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private int _TransId;

        private int _OID;

        private decimal _Amount;

        private int _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnTransIdChanging(int value);
        partial void OnTransIdChanged();
        partial void OnOIDChanging(int value);
        partial void OnOIDChanged();
        partial void OnAmountChanging(decimal value);
        partial void OnAmountChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public DetailDetailCompta()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TransId", DbType = "Int NOT NULL")]
        public int TransId
        {
            get
            {
                return this._TransId;
            }
            set
            {
                if ((this._TransId != value))
                {
                    this.OnTransIdChanging(value);
                    this.SendPropertyChanging();
                    this._TransId = value;
                    this.SendPropertyChanged("TransId");
                    this.OnTransIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OID", DbType = "Int NOT NULL")]
        public int OID
        {
            get
            {
                return this._OID;
            }
            set
            {
                if ((this._OID != value))
                {
                    this.OnOIDChanging(value);
                    this.SendPropertyChanging();
                    this._OID = value;
                    this.SendPropertyChanged("OID");
                    this.OnOIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Amount", DbType = "Money NOT NULL")]
        public decimal Amount
        {
            get
            {
                return this._Amount;
            }
            set
            {
                if ((this._Amount != value))
                {
                    this.OnAmountChanging(value);
                    this.SendPropertyChanging();
                    this._Amount = value;
                    this.SendPropertyChanged("Amount");
                    this.OnAmountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public static explicit operator DetailDetailCompta(List<DetailDetailViewModel> v)
        {
            throw new NotImplementedException();
        }

        public static explicit operator DetailDetailCompta(DetailDetailViewModel v)
        {
            throw new NotImplementedException();
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.DetailLogistic")]
    public partial class DetailLogistic : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _id;

        private int _transid;

        private string _item;

        private string _unit;

        private decimal _price;

        private decimal _quantity;

        private decimal _Vat;

        private System.DateTime _duedate;

        private string _text;

        private System.Nullable<decimal> _lineNet;

        private System.Nullable<decimal> _lineVAT;

        private string _Currency;

        private int _ModelId;

        private string _Terms;

        private EntityRef<Article> _Article;

        private EntityRef<MasterLogistic> _MasterLogistic;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(int value);
        partial void OnidChanged();
        partial void OntransidChanging(int value);
        partial void OntransidChanged();
        partial void OnitemChanging(string value);
        partial void OnitemChanged();
        partial void OnunitChanging(string value);
        partial void OnunitChanged();
        partial void OnpriceChanging(decimal value);
        partial void OnpriceChanged();
        partial void OnquantityChanging(decimal value);
        partial void OnquantityChanged();
        partial void OnVatChanging(decimal value);
        partial void OnVatChanged();
        partial void OnduedateChanging(System.DateTime value);
        partial void OnduedateChanged();
        partial void OntextChanging(string value);
        partial void OntextChanged();
        partial void OnlineNetChanging(System.Nullable<decimal> value);
        partial void OnlineNetChanged();
        partial void OnlineVATChanging(System.Nullable<decimal> value);
        partial void OnlineVATChanged();
        partial void OnCurrencyChanging(string value);
        partial void OnCurrencyChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        partial void OnTermsChanging(string value);
        partial void OnTermsChanged();
        #endregion

        public DetailLogistic()
        {
            this._Article = default(EntityRef<Article>);
            this._MasterLogistic = default(EntityRef<MasterLogistic>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_transid", DbType = "Int NOT NULL")]
        public int transid
        {
            get
            {
                return this._transid;
            }
            set
            {
                if ((this._transid != value))
                {
                    if (this._MasterLogistic.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OntransidChanging(value);
                    this.SendPropertyChanging();
                    this._transid = value;
                    this.SendPropertyChanged("transid");
                    this.OntransidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_item", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string item
        {
            get
            {
                return this._item;
            }
            set
            {
                if ((this._item != value))
                {
                    if (this._Article.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnitemChanging(value);
                    this.SendPropertyChanging();
                    this._item = value;
                    this.SendPropertyChanged("item");
                    this.OnitemChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_unit", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string unit
        {
            get
            {
                return this._unit;
            }
            set
            {
                if ((this._unit != value))
                {
                    this.OnunitChanging(value);
                    this.SendPropertyChanging();
                    this._unit = value;
                    this.SendPropertyChanged("unit");
                    this.OnunitChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_price", DbType = "Money NOT NULL")]
        public decimal price
        {
            get
            {
                return this._price;
            }
            set
            {
                if ((this._price != value))
                {
                    this.OnpriceChanging(value);
                    this.SendPropertyChanging();
                    this._price = value;
                    this.SendPropertyChanged("price");
                    this.OnpriceChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_quantity", DbType = "Decimal(10,2) NOT NULL")]
        public decimal quantity
        {
            get
            {
                return this._quantity;
            }
            set
            {
                if ((this._quantity != value))
                {
                    this.OnquantityChanging(value);
                    this.SendPropertyChanging();
                    this._quantity = value;
                    this.SendPropertyChanged("quantity");
                    this.OnquantityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Vat", DbType = "Decimal(16,2) NOT NULL")]
        public decimal Vat
        {
            get
            {
                return this._Vat;
            }
            set
            {
                if ((this._Vat != value))
                {
                    this.OnVatChanging(value);
                    this.SendPropertyChanging();
                    this._Vat = value;
                    this.SendPropertyChanged("Vat");
                    this.OnVatChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_duedate", DbType = "DateTime2 NOT NULL")]
        public System.DateTime duedate
        {
            get
            {
                return this._duedate;
            }
            set
            {
                if ((this._duedate != value))
                {
                    this.OnduedateChanging(value);
                    this.SendPropertyChanging();
                    this._duedate = value;
                    this.SendPropertyChanged("duedate");
                    this.OnduedateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_text", DbType = "NVarChar(250)")]
        public string text
        {
            get
            {
                return this._text;
            }
            set
            {
                if ((this._text != value))
                {
                    this.OntextChanging(value);
                    this.SendPropertyChanging();
                    this._text = value;
                    this.SendPropertyChanged("text");
                    this.OntextChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_lineNet", AutoSync = AutoSync.Always, DbType = "Money", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public System.Nullable<decimal> lineNet
        {
            get
            {
                return this._lineNet;
            }
            set
            {
                if ((this._lineNet != value))
                {
                    this.OnlineNetChanging(value);
                    this.SendPropertyChanging();
                    this._lineNet = value;
                    this.SendPropertyChanged("lineNet");
                    this.OnlineNetChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_lineVAT", AutoSync = AutoSync.Always, DbType = "Money", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public System.Nullable<decimal> lineVAT
        {
            get
            {
                return this._lineVAT;
            }
            set
            {
                if ((this._lineVAT != value))
                {
                    this.OnlineVATChanging(value);
                    this.SendPropertyChanging();
                    this._lineVAT = value;
                    this.SendPropertyChanged("lineVAT");
                    this.OnlineVATChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this.OnCurrencyChanging(value);
                    this.SendPropertyChanging();
                    this._Currency = value;
                    this.SendPropertyChanged("Currency");
                    this.OnCurrencyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Terms", DbType = "VarChar(250)")]
        public string Terms
        {
            get
            {
                return this._Terms;
            }
            set
            {
                if ((this._Terms != value))
                {
                    this.OnTermsChanging(value);
                    this.SendPropertyChanging();
                    this._Terms = value;
                    this.SendPropertyChanged("Terms");
                    this.OnTermsChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Article_DetailLogistic", Storage = "_Article", ThisKey = "item", OtherKey = "id", IsForeignKey = true)]
        public Article Article
        {
            get
            {
                return this._Article.Entity;
            }
            set
            {
                Article previousValue = this._Article.Entity;
                if (((previousValue != value)
                            || (this._Article.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Article.Entity = null;
                        previousValue.DetailLogistics.Remove(this);
                    }
                    this._Article.Entity = value;
                    if ((value != null))
                    {
                        value.DetailLogistics.Add(this);
                        this._item = value.id;
                    }
                    else
                    {
                        this._item = default(string);
                    }
                    this.SendPropertyChanged("Article");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "MasterLogistic_DetailLogistic", Storage = "_MasterLogistic", ThisKey = "transid", OtherKey = "id", IsForeignKey = true)]
        public MasterLogistic MasterLogistic
        {
            get
            {
                return this._MasterLogistic.Entity;
            }
            set
            {
                MasterLogistic previousValue = this._MasterLogistic.Entity;
                if (((previousValue != value)
                            || (this._MasterLogistic.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._MasterLogistic.Entity = null;
                        previousValue.DetailLogistics.Remove(this);
                    }
                    this._MasterLogistic.Entity = value;
                    if ((value != null))
                    {
                        value.DetailLogistics.Add(this);
                        this._transid = value.id;
                    }
                    else
                    {
                        this._transid = default(int);
                    }
                    this.SendPropertyChanged("MasterLogistic");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.FiscalYear")]
    public partial class FiscalYear : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private string _Period;

        private string _CompanyId;

        private System.Nullable<bool> _Current;

        private System.Nullable<bool> _Open;

        private System.Nullable<int> _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnPeriodChanging(string value);
        partial void OnPeriodChanged();
        partial void OnCompanyIdChanging(string value);
        partial void OnCompanyIdChanged();
        partial void OnCurrentChanging(System.Nullable<bool> value);
        partial void OnCurrentChanged();
        partial void OnOpenChanging(System.Nullable<bool> value);
        partial void OnOpenChanged();
        partial void OnModelIdChanging(System.Nullable<int> value);
        partial void OnModelIdChanged();
        #endregion

        public FiscalYear()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", AutoSync = AutoSync.Always, DbType = "Int NOT NULL IDENTITY", IsDbGenerated = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Period", DbType = "NChar(6) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string Period
        {
            get
            {
                return this._Period;
            }
            set
            {
                if ((this._Period != value))
                {
                    this.OnPeriodChanging(value);
                    this.SendPropertyChanging();
                    this._Period = value;
                    this.SendPropertyChanged("Period");
                    this.OnPeriodChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string CompanyId
        {
            get
            {
                return this._CompanyId;
            }
            set
            {
                if ((this._CompanyId != value))
                {
                    this.OnCompanyIdChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyId = value;
                    this.SendPropertyChanged("CompanyId");
                    this.OnCompanyIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Name = "[Current]", Storage = "_Current", DbType = "Bit")]
        public System.Nullable<bool> Current
        {
            get
            {
                return this._Current;
            }
            set
            {
                if ((this._Current != value))
                {
                    this.OnCurrentChanging(value);
                    this.SendPropertyChanging();
                    this._Current = value;
                    this.SendPropertyChanged("Current");
                    this.OnCurrentChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Name = "[Open]", Storage = "_Open", DbType = "Bit")]
        public System.Nullable<bool> Open
        {
            get
            {
                return this._Open;
            }
            set
            {
                if ((this._Open != value))
                {
                    this.OnOpenChanging(value);
                    this.SendPropertyChanging();
                    this._Open = value;
                    this.SendPropertyChanged("Open");
                    this.OnOpenChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int")]
        public System.Nullable<int> ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Journal")]
    public partial class Journal : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _ID;

        private int _ItemID;

        private int _OID;

        private string _ItemType;

        private string _CustSupplierID;

        private string _StoreID;

        private System.DateTime _TransDate;

        private System.DateTime _ItemDate;

        private System.DateTime _EntryDate;

        private string _Periode;

        private string _Account;

        private string _OAccount;

        private decimal _Amount;

        private string _Side;

        private string _CompanyID;

        private string _CompanyIBAN;

        private string _IBAN;

        private string _Currency;

        private string _Info;

        private string _oYear;

        private string _oMonth;

        private string _StoreName;

        private string _AccountName;

        private string _OAccountName;

        private string _CustSupplierName;

        private string _CompanyName;

        private string _TypeJournal;

        private string _CostCenterId;

        private string _CostCenterName;

        private string _TypeJournalName;

        private System.Nullable<int> _ModelId;

        private EntityRef<Account> _Account1;

        private EntityRef<Account> _Account2;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIDChanging(int value);
        partial void OnIDChanged();
        partial void OnItemIDChanging(int value);
        partial void OnItemIDChanged();
        partial void OnOIDChanging(int value);
        partial void OnOIDChanged();
        partial void OnItemTypeChanging(string value);
        partial void OnItemTypeChanged();
        partial void OnCustSupplierIDChanging(string value);
        partial void OnCustSupplierIDChanged();
        partial void OnStoreIDChanging(string value);
        partial void OnStoreIDChanged();
        partial void OnTransDateChanging(System.DateTime value);
        partial void OnTransDateChanged();
        partial void OnItemDateChanging(System.DateTime value);
        partial void OnItemDateChanged();
        partial void OnEntryDateChanging(System.DateTime value);
        partial void OnEntryDateChanged();
        partial void OnPeriodeChanging(string value);
        partial void OnPeriodeChanged();
        partial void OnAccountChanging(string value);
        partial void OnAccountChanged();
        partial void OnOAccountChanging(string value);
        partial void OnOAccountChanged();
        partial void OnAmountChanging(decimal value);
        partial void OnAmountChanged();
        partial void OnSideChanging(string value);
        partial void OnSideChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnCompanyIBANChanging(string value);
        partial void OnCompanyIBANChanged();
        partial void OnIBANChanging(string value);
        partial void OnIBANChanged();
        partial void OnCurrencyChanging(string value);
        partial void OnCurrencyChanged();
        partial void OnInfoChanging(string value);
        partial void OnInfoChanged();
        partial void OnoYearChanging(string value);
        partial void OnoYearChanged();
        partial void OnoMonthChanging(string value);
        partial void OnoMonthChanged();
        partial void OnStoreNameChanging(string value);
        partial void OnStoreNameChanged();
        partial void OnAccountNameChanging(string value);
        partial void OnAccountNameChanged();
        partial void OnOAccountNameChanging(string value);
        partial void OnOAccountNameChanged();
        partial void OnCustSupplierNameChanging(string value);
        partial void OnCustSupplierNameChanged();
        partial void OnCompanyNameChanging(string value);
        partial void OnCompanyNameChanged();
        partial void OnTypeJournalChanging(string value);
        partial void OnTypeJournalChanged();
        partial void OnCostCenterIdChanging(string value);
        partial void OnCostCenterIdChanged();
        partial void OnCostCenterNameChanging(string value);
        partial void OnCostCenterNameChanged();
        partial void OnTypeJournalNameChanging(string value);
        partial void OnTypeJournalNameChanged();
        partial void OnModelIdChanging(System.Nullable<int> value);
        partial void OnModelIdChanged();
        #endregion

        public Journal()
        {
            this._Account1 = default(EntityRef<Account>);
            this._Account2 = default(EntityRef<Account>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ID", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int ID
        {
            get
            {
                return this._ID;
            }
            set
            {
                if ((this._ID != value))
                {
                    this.OnIDChanging(value);
                    this.SendPropertyChanging();
                    this._ID = value;
                    this.SendPropertyChanged("ID");
                    this.OnIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ItemID", DbType = "Int NOT NULL")]
        public int ItemID
        {
            get
            {
                return this._ItemID;
            }
            set
            {
                if ((this._ItemID != value))
                {
                    this.OnItemIDChanging(value);
                    this.SendPropertyChanging();
                    this._ItemID = value;
                    this.SendPropertyChanged("ItemID");
                    this.OnItemIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OID", DbType = "Int NOT NULL")]
        public int OID
        {
            get
            {
                return this._OID;
            }
            set
            {
                if ((this._OID != value))
                {
                    this.OnOIDChanging(value);
                    this.SendPropertyChanging();
                    this._OID = value;
                    this.SendPropertyChanged("OID");
                    this.OnOIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ItemType", DbType = "NVarChar(50)")]
        public string ItemType
        {
            get
            {
                return this._ItemType;
            }
            set
            {
                if ((this._ItemType != value))
                {
                    this.OnItemTypeChanging(value);
                    this.SendPropertyChanging();
                    this._ItemType = value;
                    this.SendPropertyChanged("ItemType");
                    this.OnItemTypeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CustSupplierID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CustSupplierID
        {
            get
            {
                return this._CustSupplierID;
            }
            set
            {
                if ((this._CustSupplierID != value))
                {
                    this.OnCustSupplierIDChanging(value);
                    this.SendPropertyChanging();
                    this._CustSupplierID = value;
                    this.SendPropertyChanged("CustSupplierID");
                    this.OnCustSupplierIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_StoreID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string StoreID
        {
            get
            {
                return this._StoreID;
            }
            set
            {
                if ((this._StoreID != value))
                {
                    this.OnStoreIDChanging(value);
                    this.SendPropertyChanging();
                    this._StoreID = value;
                    this.SendPropertyChanged("StoreID");
                    this.OnStoreIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TransDate", DbType = "DateTime NOT NULL")]
        public System.DateTime TransDate
        {
            get
            {
                return this._TransDate;
            }
            set
            {
                if ((this._TransDate != value))
                {
                    this.OnTransDateChanging(value);
                    this.SendPropertyChanging();
                    this._TransDate = value;
                    this.SendPropertyChanged("TransDate");
                    this.OnTransDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ItemDate", DbType = "DateTime NOT NULL")]
        public System.DateTime ItemDate
        {
            get
            {
                return this._ItemDate;
            }
            set
            {
                if ((this._ItemDate != value))
                {
                    this.OnItemDateChanging(value);
                    this.SendPropertyChanging();
                    this._ItemDate = value;
                    this.SendPropertyChanged("ItemDate");
                    this.OnItemDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_EntryDate", DbType = "DateTime NOT NULL")]
        public System.DateTime EntryDate
        {
            get
            {
                return this._EntryDate;
            }
            set
            {
                if ((this._EntryDate != value))
                {
                    this.OnEntryDateChanging(value);
                    this.SendPropertyChanging();
                    this._EntryDate = value;
                    this.SendPropertyChanged("EntryDate");
                    this.OnEntryDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Periode", DbType = "NChar(6) NOT NULL", CanBeNull = false)]
        public string Periode
        {
            get
            {
                return this._Periode;
            }
            set
            {
                if ((this._Periode != value))
                {
                    this.OnPeriodeChanging(value);
                    this.SendPropertyChanging();
                    this._Periode = value;
                    this.SendPropertyChanged("Periode");
                    this.OnPeriodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Account", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string Account
        {
            get
            {
                return this._Account;
            }
            set
            {
                if ((this._Account != value))
                {
                    if (this._Account1.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnAccountChanging(value);
                    this.SendPropertyChanging();
                    this._Account = value;
                    this.SendPropertyChanged("Account");
                    this.OnAccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OAccount", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string OAccount
        {
            get
            {
                return this._OAccount;
            }
            set
            {
                if ((this._OAccount != value))
                {
                    if (this._Account2.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnOAccountChanging(value);
                    this.SendPropertyChanging();
                    this._OAccount = value;
                    this.SendPropertyChanged("OAccount");
                    this.OnOAccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Amount", DbType = "Money NOT NULL")]
        public decimal Amount
        {
            get
            {
                return this._Amount;
            }
            set
            {
                if ((this._Amount != value))
                {
                    this.OnAmountChanging(value);
                    this.SendPropertyChanging();
                    this._Amount = value;
                    this.SendPropertyChanged("Amount");
                    this.OnAmountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Side", DbType = "NVarChar(6) NOT NULL", CanBeNull = false)]
        public string Side
        {
            get
            {
                return this._Side;
            }
            set
            {
                if ((this._Side != value))
                {
                    this.OnSideChanging(value);
                    this.SendPropertyChanging();
                    this._Side = value;
                    this.SendPropertyChanged("Side");
                    this.OnSideChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyIBAN", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyIBAN
        {
            get
            {
                return this._CompanyIBAN;
            }
            set
            {
                if ((this._CompanyIBAN != value))
                {
                    this.OnCompanyIBANChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyIBAN = value;
                    this.SendPropertyChanged("CompanyIBAN");
                    this.OnCompanyIBANChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IBAN", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string IBAN
        {
            get
            {
                return this._IBAN;
            }
            set
            {
                if ((this._IBAN != value))
                {
                    this.OnIBANChanging(value);
                    this.SendPropertyChanging();
                    this._IBAN = value;
                    this.SendPropertyChanged("IBAN");
                    this.OnIBANChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this.OnCurrencyChanging(value);
                    this.SendPropertyChanging();
                    this._Currency = value;
                    this.SendPropertyChanged("Currency");
                    this.OnCurrencyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Info", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string Info
        {
            get
            {
                return this._Info;
            }
            set
            {
                if ((this._Info != value))
                {
                    this.OnInfoChanging(value);
                    this.SendPropertyChanging();
                    this._Info = value;
                    this.SendPropertyChanged("Info");
                    this.OnInfoChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oYear", AutoSync = AutoSync.Always, DbType = "Char(4)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string oYear
        {
            get
            {
                return this._oYear;
            }
            set
            {
                if ((this._oYear != value))
                {
                    this.OnoYearChanging(value);
                    this.SendPropertyChanging();
                    this._oYear = value;
                    this.SendPropertyChanged("oYear");
                    this.OnoYearChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oMonth", AutoSync = AutoSync.Always, DbType = "Char(2)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string oMonth
        {
            get
            {
                return this._oMonth;
            }
            set
            {
                if ((this._oMonth != value))
                {
                    this.OnoMonthChanging(value);
                    this.SendPropertyChanging();
                    this._oMonth = value;
                    this.SendPropertyChanged("oMonth");
                    this.OnoMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_StoreName", DbType = "NVarChar(150)")]
        public string StoreName
        {
            get
            {
                return this._StoreName;
            }
            set
            {
                if ((this._StoreName != value))
                {
                    this.OnStoreNameChanging(value);
                    this.SendPropertyChanging();
                    this._StoreName = value;
                    this.SendPropertyChanged("StoreName");
                    this.OnStoreNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountName", DbType = "NVarChar(150)")]
        public string AccountName
        {
            get
            {
                return this._AccountName;
            }
            set
            {
                if ((this._AccountName != value))
                {
                    this.OnAccountNameChanging(value);
                    this.SendPropertyChanging();
                    this._AccountName = value;
                    this.SendPropertyChanged("AccountName");
                    this.OnAccountNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OAccountName", DbType = "NVarChar(150)")]
        public string OAccountName
        {
            get
            {
                return this._OAccountName;
            }
            set
            {
                if ((this._OAccountName != value))
                {
                    this.OnOAccountNameChanging(value);
                    this.SendPropertyChanging();
                    this._OAccountName = value;
                    this.SendPropertyChanged("OAccountName");
                    this.OnOAccountNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CustSupplierName", DbType = "NVarChar(150)")]
        public string CustSupplierName
        {
            get
            {
                return this._CustSupplierName;
            }
            set
            {
                if ((this._CustSupplierName != value))
                {
                    this.OnCustSupplierNameChanging(value);
                    this.SendPropertyChanging();
                    this._CustSupplierName = value;
                    this.SendPropertyChanged("CustSupplierName");
                    this.OnCustSupplierNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyName", DbType = "NVarChar(150)")]
        public string CompanyName
        {
            get
            {
                return this._CompanyName;
            }
            set
            {
                if ((this._CompanyName != value))
                {
                    this.OnCompanyNameChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyName = value;
                    this.SendPropertyChanged("CompanyName");
                    this.OnCompanyNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TypeJournal", DbType = "VarChar(50)")]
        public string TypeJournal
        {
            get
            {
                return this._TypeJournal;
            }
            set
            {
                if ((this._TypeJournal != value))
                {
                    this.OnTypeJournalChanging(value);
                    this.SendPropertyChanging();
                    this._TypeJournal = value;
                    this.SendPropertyChanged("TypeJournal");
                    this.OnTypeJournalChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CostCenterId", DbType = "NVarChar(50)")]
        public string CostCenterId
        {
            get
            {
                return this._CostCenterId;
            }
            set
            {
                if ((this._CostCenterId != value))
                {
                    this.OnCostCenterIdChanging(value);
                    this.SendPropertyChanging();
                    this._CostCenterId = value;
                    this.SendPropertyChanged("CostCenterId");
                    this.OnCostCenterIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CostCenterName", DbType = "NVarChar(150)")]
        public string CostCenterName
        {
            get
            {
                return this._CostCenterName;
            }
            set
            {
                if ((this._CostCenterName != value))
                {
                    this.OnCostCenterNameChanging(value);
                    this.SendPropertyChanging();
                    this._CostCenterName = value;
                    this.SendPropertyChanged("CostCenterName");
                    this.OnCostCenterNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TypeJournalName", DbType = "NVarChar(150)")]
        public string TypeJournalName
        {
            get
            {
                return this._TypeJournalName;
            }
            set
            {
                if ((this._TypeJournalName != value))
                {
                    this.OnTypeJournalNameChanging(value);
                    this.SendPropertyChanging();
                    this._TypeJournalName = value;
                    this.SendPropertyChanged("TypeJournalName");
                    this.OnTypeJournalNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int")]
        public System.Nullable<int> ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_Journal", Storage = "_Account1", ThisKey = "Account", OtherKey = "id", IsForeignKey = true)]
        public Account Account1
        {
            get
            {
                return this._Account1.Entity;
            }
            set
            {
                Account previousValue = this._Account1.Entity;
                if (((previousValue != value)
                            || (this._Account1.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Account1.Entity = null;
                        previousValue.Journals.Remove(this);
                    }
                    this._Account1.Entity = value;
                    if ((value != null))
                    {
                        value.Journals.Add(this);
                        this._Account = value.id;
                    }
                    else
                    {
                        this._Account = default(string);
                    }
                    this.SendPropertyChanged("Account1");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_Journal1", Storage = "_Account2", ThisKey = "OAccount", OtherKey = "id", IsForeignKey = true)]
        public Account Account2
        {
            get
            {
                return this._Account2.Entity;
            }
            set
            {
                Account previousValue = this._Account2.Entity;
                if (((previousValue != value)
                            || (this._Account2.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Account2.Entity = null;
                        previousValue.Journals1.Remove(this);
                    }
                    this._Account2.Entity = value;
                    if ((value != null))
                    {
                        value.Journals1.Add(this);
                        this._OAccount = value.id;
                    }
                    else
                    {
                        this._OAccount = default(string);
                    }
                    this.SendPropertyChanged("Account2");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.JournalStock")]
    public partial class JournalStock : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _ID;

        private int _ItemID;

        private int _OID;

        private string _ItemType;

        private string _CustSupplierID;

        private string _StoreID;

        private string _ArticleID;

        private string _ArticleName;

        private decimal _Quantity;

        private decimal _Price;

        private decimal _AvgPrice;

        private System.DateTime _TransDate;

        private string _Periode;

        private string _Account;

        private string _OAccount;

        private decimal _Amount;

        private string _Side;

        private string _CompanyID;

        private System.Nullable<int> _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIDChanging(int value);
        partial void OnIDChanged();
        partial void OnItemIDChanging(int value);
        partial void OnItemIDChanged();
        partial void OnOIDChanging(int value);
        partial void OnOIDChanged();
        partial void OnItemTypeChanging(string value);
        partial void OnItemTypeChanged();
        partial void OnCustSupplierIDChanging(string value);
        partial void OnCustSupplierIDChanged();
        partial void OnStoreIDChanging(string value);
        partial void OnStoreIDChanged();
        partial void OnArticleIDChanging(string value);
        partial void OnArticleIDChanged();
        partial void OnArticleNameChanging(string value);
        partial void OnArticleNameChanged();
        partial void OnQuantityChanging(decimal value);
        partial void OnQuantityChanged();
        partial void OnPriceChanging(decimal value);
        partial void OnPriceChanged();
        partial void OnAvgPriceChanging(decimal value);
        partial void OnAvgPriceChanged();
        partial void OnTransDateChanging(System.DateTime value);
        partial void OnTransDateChanged();
        partial void OnPeriodeChanging(string value);
        partial void OnPeriodeChanged();
        partial void OnAccountChanging(string value);
        partial void OnAccountChanged();
        partial void OnOAccountChanging(string value);
        partial void OnOAccountChanged();
        partial void OnAmountChanging(decimal value);
        partial void OnAmountChanged();
        partial void OnSideChanging(string value);
        partial void OnSideChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnModelIdChanging(System.Nullable<int> value);
        partial void OnModelIdChanged();
        #endregion

        public JournalStock()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ID", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int ID
        {
            get
            {
                return this._ID;
            }
            set
            {
                if ((this._ID != value))
                {
                    this.OnIDChanging(value);
                    this.SendPropertyChanging();
                    this._ID = value;
                    this.SendPropertyChanged("ID");
                    this.OnIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ItemID", DbType = "Int NOT NULL")]
        public int ItemID
        {
            get
            {
                return this._ItemID;
            }
            set
            {
                if ((this._ItemID != value))
                {
                    this.OnItemIDChanging(value);
                    this.SendPropertyChanging();
                    this._ItemID = value;
                    this.SendPropertyChanged("ItemID");
                    this.OnItemIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OID", DbType = "Int NOT NULL")]
        public int OID
        {
            get
            {
                return this._OID;
            }
            set
            {
                if ((this._OID != value))
                {
                    this.OnOIDChanging(value);
                    this.SendPropertyChanging();
                    this._OID = value;
                    this.SendPropertyChanged("OID");
                    this.OnOIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ItemType", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string ItemType
        {
            get
            {
                return this._ItemType;
            }
            set
            {
                if ((this._ItemType != value))
                {
                    this.OnItemTypeChanging(value);
                    this.SendPropertyChanging();
                    this._ItemType = value;
                    this.SendPropertyChanged("ItemType");
                    this.OnItemTypeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CustSupplierID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CustSupplierID
        {
            get
            {
                return this._CustSupplierID;
            }
            set
            {
                if ((this._CustSupplierID != value))
                {
                    this.OnCustSupplierIDChanging(value);
                    this.SendPropertyChanging();
                    this._CustSupplierID = value;
                    this.SendPropertyChanged("CustSupplierID");
                    this.OnCustSupplierIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_StoreID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string StoreID
        {
            get
            {
                return this._StoreID;
            }
            set
            {
                if ((this._StoreID != value))
                {
                    this.OnStoreIDChanging(value);
                    this.SendPropertyChanging();
                    this._StoreID = value;
                    this.SendPropertyChanged("StoreID");
                    this.OnStoreIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ArticleID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string ArticleID
        {
            get
            {
                return this._ArticleID;
            }
            set
            {
                if ((this._ArticleID != value))
                {
                    this.OnArticleIDChanging(value);
                    this.SendPropertyChanging();
                    this._ArticleID = value;
                    this.SendPropertyChanged("ArticleID");
                    this.OnArticleIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ArticleName", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string ArticleName
        {
            get
            {
                return this._ArticleName;
            }
            set
            {
                if ((this._ArticleName != value))
                {
                    this.OnArticleNameChanging(value);
                    this.SendPropertyChanging();
                    this._ArticleName = value;
                    this.SendPropertyChanged("ArticleName");
                    this.OnArticleNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Quantity", DbType = "Decimal(16,2) NOT NULL")]
        public decimal Quantity
        {
            get
            {
                return this._Quantity;
            }
            set
            {
                if ((this._Quantity != value))
                {
                    this.OnQuantityChanging(value);
                    this.SendPropertyChanging();
                    this._Quantity = value;
                    this.SendPropertyChanged("Quantity");
                    this.OnQuantityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Price", DbType = "Decimal(16,2) NOT NULL")]
        public decimal Price
        {
            get
            {
                return this._Price;
            }
            set
            {
                if ((this._Price != value))
                {
                    this.OnPriceChanging(value);
                    this.SendPropertyChanging();
                    this._Price = value;
                    this.SendPropertyChanged("Price");
                    this.OnPriceChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AvgPrice", DbType = "Decimal(16,2) NOT NULL")]
        public decimal AvgPrice
        {
            get
            {
                return this._AvgPrice;
            }
            set
            {
                if ((this._AvgPrice != value))
                {
                    this.OnAvgPriceChanging(value);
                    this.SendPropertyChanging();
                    this._AvgPrice = value;
                    this.SendPropertyChanged("AvgPrice");
                    this.OnAvgPriceChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TransDate", DbType = "DateTime NOT NULL")]
        public System.DateTime TransDate
        {
            get
            {
                return this._TransDate;
            }
            set
            {
                if ((this._TransDate != value))
                {
                    this.OnTransDateChanging(value);
                    this.SendPropertyChanging();
                    this._TransDate = value;
                    this.SendPropertyChanged("TransDate");
                    this.OnTransDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Periode", DbType = "NChar(6) NOT NULL", CanBeNull = false)]
        public string Periode
        {
            get
            {
                return this._Periode;
            }
            set
            {
                if ((this._Periode != value))
                {
                    this.OnPeriodeChanging(value);
                    this.SendPropertyChanging();
                    this._Periode = value;
                    this.SendPropertyChanged("Periode");
                    this.OnPeriodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Account", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string Account
        {
            get
            {
                return this._Account;
            }
            set
            {
                if ((this._Account != value))
                {
                    this.OnAccountChanging(value);
                    this.SendPropertyChanging();
                    this._Account = value;
                    this.SendPropertyChanged("Account");
                    this.OnAccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OAccount", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string OAccount
        {
            get
            {
                return this._OAccount;
            }
            set
            {
                if ((this._OAccount != value))
                {
                    this.OnOAccountChanging(value);
                    this.SendPropertyChanging();
                    this._OAccount = value;
                    this.SendPropertyChanged("OAccount");
                    this.OnOAccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Amount", DbType = "Decimal(16,2) NOT NULL")]
        public decimal Amount
        {
            get
            {
                return this._Amount;
            }
            set
            {
                if ((this._Amount != value))
                {
                    this.OnAmountChanging(value);
                    this.SendPropertyChanging();
                    this._Amount = value;
                    this.SendPropertyChanged("Amount");
                    this.OnAmountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Side", DbType = "NVarChar(6) NOT NULL", CanBeNull = false)]
        public string Side
        {
            get
            {
                return this._Side;
            }
            set
            {
                if ((this._Side != value))
                {
                    this.OnSideChanging(value);
                    this.SendPropertyChanging();
                    this._Side = value;
                    this.SendPropertyChanged("Side");
                    this.OnSideChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int")]
        public System.Nullable<int> ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Localization")]
    public partial class Localization : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _ItemName;

        private string _UICulture;

        private string _LocalName;

        private System.Nullable<int> _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnItemNameChanging(string value);
        partial void OnItemNameChanged();
        partial void OnUICultureChanging(string value);
        partial void OnUICultureChanged();
        partial void OnLocalNameChanging(string value);
        partial void OnLocalNameChanged();
        partial void OnModelIdChanging(System.Nullable<int> value);
        partial void OnModelIdChanged();
        #endregion

        public Localization()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ItemName", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string ItemName
        {
            get
            {
                return this._ItemName;
            }
            set
            {
                if ((this._ItemName != value))
                {
                    this.OnItemNameChanging(value);
                    this.SendPropertyChanging();
                    this._ItemName = value;
                    this.SendPropertyChanged("ItemName");
                    this.OnItemNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UICulture", DbType = "Char(5) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string UICulture
        {
            get
            {
                return this._UICulture;
            }
            set
            {
                if ((this._UICulture != value))
                {
                    this.OnUICultureChanging(value);
                    this.SendPropertyChanging();
                    this._UICulture = value;
                    this.SendPropertyChanged("UICulture");
                    this.OnUICultureChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LocalName", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string LocalName
        {
            get
            {
                return this._LocalName;
            }
            set
            {
                if ((this._LocalName != value))
                {
                    this.OnLocalNameChanging(value);
                    this.SendPropertyChanging();
                    this._LocalName = value;
                    this.SendPropertyChanged("LocalName");
                    this.OnLocalNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int")]
        public System.Nullable<int> ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.LogExceptions")]
    public partial class LogException : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private long _LogId;

        private string _EMessage;

        private string _EType;

        private string _ESource;

        private string _ETarget;

        private string _EURL;

        private System.DateTime _LogDate;

        private string _CompanyId;

        private string _UserName;

        private System.Nullable<int> _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnLogIdChanging(long value);
        partial void OnLogIdChanged();
        partial void OnEMessageChanging(string value);
        partial void OnEMessageChanged();
        partial void OnETypeChanging(string value);
        partial void OnETypeChanged();
        partial void OnESourceChanging(string value);
        partial void OnESourceChanged();
        partial void OnETargetChanging(string value);
        partial void OnETargetChanged();
        partial void OnEURLChanging(string value);
        partial void OnEURLChanged();
        partial void OnLogDateChanging(System.DateTime value);
        partial void OnLogDateChanged();
        partial void OnCompanyIdChanging(string value);
        partial void OnCompanyIdChanged();
        partial void OnUserNameChanging(string value);
        partial void OnUserNameChanged();
        partial void OnModelIdChanging(System.Nullable<int> value);
        partial void OnModelIdChanged();
        #endregion

        public LogException()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LogId", AutoSync = AutoSync.OnInsert, DbType = "BigInt NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public long LogId
        {
            get
            {
                return this._LogId;
            }
            set
            {
                if ((this._LogId != value))
                {
                    this.OnLogIdChanging(value);
                    this.SendPropertyChanging();
                    this._LogId = value;
                    this.SendPropertyChanged("LogId");
                    this.OnLogIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_EMessage", DbType = "VarChar(MAX) NOT NULL", CanBeNull = false)]
        public string EMessage
        {
            get
            {
                return this._EMessage;
            }
            set
            {
                if ((this._EMessage != value))
                {
                    this.OnEMessageChanging(value);
                    this.SendPropertyChanging();
                    this._EMessage = value;
                    this.SendPropertyChanged("EMessage");
                    this.OnEMessageChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_EType", DbType = "VarChar(256)")]
        public string EType
        {
            get
            {
                return this._EType;
            }
            set
            {
                if ((this._EType != value))
                {
                    this.OnETypeChanging(value);
                    this.SendPropertyChanging();
                    this._EType = value;
                    this.SendPropertyChanged("EType");
                    this.OnETypeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ESource", DbType = "NVarChar(256)")]
        public string ESource
        {
            get
            {
                return this._ESource;
            }
            set
            {
                if ((this._ESource != value))
                {
                    this.OnESourceChanging(value);
                    this.SendPropertyChanging();
                    this._ESource = value;
                    this.SendPropertyChanged("ESource");
                    this.OnESourceChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ETarget", DbType = "NVarChar(256)")]
        public string ETarget
        {
            get
            {
                return this._ETarget;
            }
            set
            {
                if ((this._ETarget != value))
                {
                    this.OnETargetChanging(value);
                    this.SendPropertyChanging();
                    this._ETarget = value;
                    this.SendPropertyChanged("ETarget");
                    this.OnETargetChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_EURL", DbType = "VarChar(256)")]
        public string EURL
        {
            get
            {
                return this._EURL;
            }
            set
            {
                if ((this._EURL != value))
                {
                    this.OnEURLChanging(value);
                    this.SendPropertyChanging();
                    this._EURL = value;
                    this.SendPropertyChanged("EURL");
                    this.OnEURLChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LogDate", DbType = "DateTime NOT NULL")]
        public System.DateTime LogDate
        {
            get
            {
                return this._LogDate;
            }
            set
            {
                if ((this._LogDate != value))
                {
                    this.OnLogDateChanging(value);
                    this.SendPropertyChanging();
                    this._LogDate = value;
                    this.SendPropertyChanged("LogDate");
                    this.OnLogDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyId", DbType = "NVarChar(6) NOT NULL", CanBeNull = false)]
        public string CompanyId
        {
            get
            {
                return this._CompanyId;
            }
            set
            {
                if ((this._CompanyId != value))
                {
                    this.OnCompanyIdChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyId = value;
                    this.SendPropertyChanged("CompanyId");
                    this.OnCompanyIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UserName", DbType = "VarChar(100) NOT NULL", CanBeNull = false)]
        public string UserName
        {
            get
            {
                return this._UserName;
            }
            set
            {
                if ((this._UserName != value))
                {
                    this.OnUserNameChanging(value);
                    this.SendPropertyChanging();
                    this._UserName = value;
                    this.SendPropertyChanged("UserName");
                    this.OnUserNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int")]
        public System.Nullable<int> ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.LookupAccountAmount")]
    public partial class LookupAccountAmount : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _AccountName;

        private string _AccountCode;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnAccountNameChanging(string value);
        partial void OnAccountNameChanged();
        partial void OnAccountCodeChanging(string value);
        partial void OnAccountCodeChanged();
        #endregion

        public LookupAccountAmount()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountName", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string AccountName
        {
            get
            {
                return this._AccountName;
            }
            set
            {
                if ((this._AccountName != value))
                {
                    this.OnAccountNameChanging(value);
                    this.SendPropertyChanging();
                    this._AccountName = value;
                    this.SendPropertyChanged("AccountName");
                    this.OnAccountNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountCode", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string AccountCode
        {
            get
            {
                return this._AccountCode;
            }
            set
            {
                if ((this._AccountCode != value))
                {
                    this.OnAccountCodeChanging(value);
                    this.SendPropertyChanging();
                    this._AccountCode = value;
                    this.SendPropertyChanged("AccountCode");
                    this.OnAccountCodeChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.MasterCompta")]
    public partial class MasterCompta : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _id;

        private int _oid;

        private string _CostCenter;

        private string _account;

        private string _HeaderText;

        private System.DateTime _TransDate;

        private System.DateTime _ItemDate;

        private System.DateTime _EntryDate;

        private string _CompanyId;

        private string _FileName;

        private string _ContentType;

        private System.Nullable<bool> _IsValidated;

        private System.Nullable<decimal> _oTotal;

        private string _oCurrency;

        private string _oPeriode;

        private string _oYear;

        private string _oMonth;

        private string _TypeJournal;

        private int _ModelId;

        private EntitySet<DetailCompta> _DetailComptas;

        private EntityRef<Account> _Account1;

        private EntityRef<Company> _Company;

        private EntityRef<CostCenter> _CostCenter1;

        private EntityRef<TypeJournal> _TypeJournal1;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(int value);
        partial void OnidChanged();
        partial void OnoidChanging(int value);
        partial void OnoidChanged();
        partial void OnCostCenterChanging(string value);
        partial void OnCostCenterChanged();
        partial void OnaccountChanging(string value);
        partial void OnaccountChanged();
        partial void OnHeaderTextChanging(string value);
        partial void OnHeaderTextChanged();
        partial void OnTransDateChanging(System.DateTime value);
        partial void OnTransDateChanged();
        partial void OnItemDateChanging(System.DateTime value);
        partial void OnItemDateChanged();
        partial void OnEntryDateChanging(System.DateTime value);
        partial void OnEntryDateChanged();
        partial void OnCompanyIdChanging(string value);
        partial void OnCompanyIdChanged();
        partial void OnFileNameChanging(string value);
        partial void OnFileNameChanged();
        partial void OnContentTypeChanging(string value);
        partial void OnContentTypeChanged();
        partial void OnIsValidatedChanging(System.Nullable<bool> value);
        partial void OnIsValidatedChanged();
        partial void OnoTotalChanging(System.Nullable<decimal> value);
        partial void OnoTotalChanged();
        partial void OnoCurrencyChanging(string value);
        partial void OnoCurrencyChanged();
        partial void OnoPeriodeChanging(string value);
        partial void OnoPeriodeChanged();
        partial void OnoYearChanging(string value);
        partial void OnoYearChanged();
        partial void OnoMonthChanging(string value);
        partial void OnoMonthChanged();
        partial void OnTypeJournalChanging(string value);
        partial void OnTypeJournalChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public MasterCompta()
        {
            this._DetailComptas = new EntitySet<DetailCompta>(new Action<DetailCompta>(this.attach_DetailComptas), new Action<DetailCompta>(this.detach_DetailComptas));
            this._Account1 = default(EntityRef<Account>);
            this._Company = default(EntityRef<Company>);
            this._CostCenter1 = default(EntityRef<CostCenter>);
            this._TypeJournal1 = default(EntityRef<TypeJournal>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oid", DbType = "Int NOT NULL")]
        public int oid
        {
            get
            {
                return this._oid;
            }
            set
            {
                if ((this._oid != value))
                {
                    this.OnoidChanging(value);
                    this.SendPropertyChanging();
                    this._oid = value;
                    this.SendPropertyChanged("oid");
                    this.OnoidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CostCenter", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CostCenter
        {
            get
            {
                return this._CostCenter;
            }
            set
            {
                if ((this._CostCenter != value))
                {
                    if (this._CostCenter1.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnCostCenterChanging(value);
                    this.SendPropertyChanging();
                    this._CostCenter = value;
                    this.SendPropertyChanged("CostCenter");
                    this.OnCostCenterChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_account", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string account
        {
            get
            {
                return this._account;
            }
            set
            {
                if ((this._account != value))
                {
                    if (this._Account1.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnaccountChanging(value);
                    this.SendPropertyChanging();
                    this._account = value;
                    this.SendPropertyChanged("account");
                    this.OnaccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_HeaderText", DbType = "NVarChar(250)")]
        public string HeaderText
        {
            get
            {
                return this._HeaderText;
            }
            set
            {
                if ((this._HeaderText != value))
                {
                    this.OnHeaderTextChanging(value);
                    this.SendPropertyChanging();
                    this._HeaderText = value;
                    this.SendPropertyChanged("HeaderText");
                    this.OnHeaderTextChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TransDate", DbType = "Date NOT NULL")]
        public System.DateTime TransDate
        {
            get
            {
                return this._TransDate;
            }
            set
            {
                if ((this._TransDate != value))
                {
                    this.OnTransDateChanging(value);
                    this.SendPropertyChanging();
                    this._TransDate = value;
                    this.SendPropertyChanged("TransDate");
                    this.OnTransDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ItemDate", DbType = "Date NOT NULL")]
        public System.DateTime ItemDate
        {
            get
            {
                return this._ItemDate;
            }
            set
            {
                if ((this._ItemDate != value))
                {
                    this.OnItemDateChanging(value);
                    this.SendPropertyChanging();
                    this._ItemDate = value;
                    this.SendPropertyChanged("ItemDate");
                    this.OnItemDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_EntryDate", DbType = "Date NOT NULL")]
        public System.DateTime EntryDate
        {
            get
            {
                return this._EntryDate;
            }
            set
            {
                if ((this._EntryDate != value))
                {
                    this.OnEntryDateChanging(value);
                    this.SendPropertyChanging();
                    this._EntryDate = value;
                    this.SendPropertyChanged("EntryDate");
                    this.OnEntryDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyId
        {
            get
            {
                return this._CompanyId;
            }
            set
            {
                if ((this._CompanyId != value))
                {
                    if (this._Company.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnCompanyIdChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyId = value;
                    this.SendPropertyChanged("CompanyId");
                    this.OnCompanyIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FileName", DbType = "NVarChar(255)")]
        public string FileName
        {
            get
            {
                return this._FileName;
            }
            set
            {
                if ((this._FileName != value))
                {
                    this.OnFileNameChanging(value);
                    this.SendPropertyChanging();
                    this._FileName = value;
                    this.SendPropertyChanged("FileName");
                    this.OnFileNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ContentType", DbType = "NVarChar(50)")]
        public string ContentType
        {
            get
            {
                return this._ContentType;
            }
            set
            {
                if ((this._ContentType != value))
                {
                    this.OnContentTypeChanging(value);
                    this.SendPropertyChanging();
                    this._ContentType = value;
                    this.SendPropertyChanged("ContentType");
                    this.OnContentTypeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsValidated", DbType = "Bit")]
        public System.Nullable<bool> IsValidated
        {
            get
            {
                return this._IsValidated;
            }
            set
            {
                if ((this._IsValidated != value))
                {
                    this.OnIsValidatedChanging(value);
                    this.SendPropertyChanging();
                    this._IsValidated = value;
                    this.SendPropertyChanged("IsValidated");
                    this.OnIsValidatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oTotal", AutoSync = AutoSync.Always, DbType = "Money", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public System.Nullable<decimal> oTotal
        {
            get
            {
                return this._oTotal;
            }
            set
            {
                if ((this._oTotal != value))
                {
                    this.OnoTotalChanging(value);
                    this.SendPropertyChanging();
                    this._oTotal = value;
                    this.SendPropertyChanged("oTotal");
                    this.OnoTotalChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oCurrency", AutoSync = AutoSync.Always, DbType = "NVarChar(10)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string oCurrency
        {
            get
            {
                return this._oCurrency;
            }
            set
            {
                if ((this._oCurrency != value))
                {
                    this.OnoCurrencyChanging(value);
                    this.SendPropertyChanging();
                    this._oCurrency = value;
                    this.SendPropertyChanged("oCurrency");
                    this.OnoCurrencyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oPeriode", AutoSync = AutoSync.Always, DbType = "NVarChar(6)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string oPeriode
        {
            get
            {
                return this._oPeriode;
            }
            set
            {
                if ((this._oPeriode != value))
                {
                    this.OnoPeriodeChanging(value);
                    this.SendPropertyChanging();
                    this._oPeriode = value;
                    this.SendPropertyChanged("oPeriode");
                    this.OnoPeriodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oYear", AutoSync = AutoSync.Always, DbType = "Char(4)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string oYear
        {
            get
            {
                return this._oYear;
            }
            set
            {
                if ((this._oYear != value))
                {
                    this.OnoYearChanging(value);
                    this.SendPropertyChanging();
                    this._oYear = value;
                    this.SendPropertyChanged("oYear");
                    this.OnoYearChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oMonth", AutoSync = AutoSync.Always, DbType = "Char(2)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string oMonth
        {
            get
            {
                return this._oMonth;
            }
            set
            {
                if ((this._oMonth != value))
                {
                    this.OnoMonthChanging(value);
                    this.SendPropertyChanging();
                    this._oMonth = value;
                    this.SendPropertyChanged("oMonth");
                    this.OnoMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TypeJournal", DbType = "VarChar(50)")]
        public string TypeJournal
        {
            get
            {
                return this._TypeJournal;
            }
            set
            {
                if ((this._TypeJournal != value))
                {
                    if (this._TypeJournal1.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnTypeJournalChanging(value);
                    this.SendPropertyChanging();
                    this._TypeJournal = value;
                    this.SendPropertyChanged("TypeJournal");
                    this.OnTypeJournalChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "MasterCompta_DetailCompta", Storage = "_DetailComptas", ThisKey = "id", OtherKey = "transid")]
        public EntitySet<DetailCompta> DetailComptas
        {
            get
            {
                return this._DetailComptas;
            }
            set
            {
                this._DetailComptas.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_MasterCompta", Storage = "_Account1", ThisKey = "account", OtherKey = "id", IsForeignKey = true)]
        public Account Account1
        {
            get
            {
                return this._Account1.Entity;
            }
            set
            {
                Account previousValue = this._Account1.Entity;
                if (((previousValue != value)
                            || (this._Account1.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Account1.Entity = null;
                        previousValue.MasterComptas.Remove(this);
                    }
                    this._Account1.Entity = value;
                    if ((value != null))
                    {
                        value.MasterComptas.Add(this);
                        this._account = value.id;
                    }
                    else
                    {
                        this._account = default(string);
                    }
                    this.SendPropertyChanged("Account1");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Company_MasterCompta", Storage = "_Company", ThisKey = "CompanyId", OtherKey = "id", IsForeignKey = true)]
        public Company Company
        {
            get
            {
                return this._Company.Entity;
            }
            set
            {
                Company previousValue = this._Company.Entity;
                if (((previousValue != value)
                            || (this._Company.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Company.Entity = null;
                        previousValue.MasterComptas.Remove(this);
                    }
                    this._Company.Entity = value;
                    if ((value != null))
                    {
                        value.MasterComptas.Add(this);
                        this._CompanyId = value.id;
                    }
                    else
                    {
                        this._CompanyId = default(string);
                    }
                    this.SendPropertyChanged("Company");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "CostCenter_MasterCompta", Storage = "_CostCenter1", ThisKey = "CostCenter", OtherKey = "id", IsForeignKey = true)]
        public CostCenter CostCenter1
        {
            get
            {
                return this._CostCenter1.Entity;
            }
            set
            {
                CostCenter previousValue = this._CostCenter1.Entity;
                if (((previousValue != value)
                            || (this._CostCenter1.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._CostCenter1.Entity = null;
                        previousValue.MasterComptas.Remove(this);
                    }
                    this._CostCenter1.Entity = value;
                    if ((value != null))
                    {
                        value.MasterComptas.Add(this);
                        this._CostCenter = value.id;
                    }
                    else
                    {
                        this._CostCenter = default(string);
                    }
                    this.SendPropertyChanged("CostCenter1");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "TypeJournal_MasterCompta", Storage = "_TypeJournal1", ThisKey = "TypeJournal", OtherKey = "Id", IsForeignKey = true)]
        public TypeJournal TypeJournal1
        {
            get
            {
                return this._TypeJournal1.Entity;
            }
            set
            {
                TypeJournal previousValue = this._TypeJournal1.Entity;
                if (((previousValue != value)
                            || (this._TypeJournal1.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._TypeJournal1.Entity = null;
                        previousValue.MasterComptas.Remove(this);
                    }
                    this._TypeJournal1.Entity = value;
                    if ((value != null))
                    {
                        value.MasterComptas.Add(this);
                        this._TypeJournal = value.Id;
                    }
                    else
                    {
                        this._TypeJournal = default(string);
                    }
                    this.SendPropertyChanged("TypeJournal1");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_DetailComptas(DetailCompta entity)
        {
            this.SendPropertyChanging();
            entity.MasterCompta = this;
        }

        private void detach_DetailComptas(DetailCompta entity)
        {
            this.SendPropertyChanging();
            entity.MasterCompta = null;
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.MasterLogistic")]
    public partial class MasterLogistic : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _id;

        private int _oid;

        private string _store;

        private string _account;

        private string _HeaderText;

        private System.DateTime _TransDate;

        private System.DateTime _ItemDate;

        private System.DateTime _EntryDate;

        private string _CompanyId;

        private System.Nullable<bool> _IsValidated;

        private System.Nullable<decimal> _oTotal;

        private System.Nullable<decimal> _oVat;

        private string _oCurrency;

        private string _oPeriode;

        private System.Nullable<decimal> _oNet;

        private string _oYear;

        private string _oMonth;

        private int _ModelId;

        private EntitySet<DetailLogistic> _DetailLogistics;

        private EntityRef<Company> _Company;

        private EntityRef<Store> _Store1;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(int value);
        partial void OnidChanged();
        partial void OnoidChanging(int value);
        partial void OnoidChanged();
        partial void OnstoreChanging(string value);
        partial void OnstoreChanged();
        partial void OnaccountChanging(string value);
        partial void OnaccountChanged();
        partial void OnHeaderTextChanging(string value);
        partial void OnHeaderTextChanged();
        partial void OnTransDateChanging(System.DateTime value);
        partial void OnTransDateChanged();
        partial void OnItemDateChanging(System.DateTime value);
        partial void OnItemDateChanged();
        partial void OnEntryDateChanging(System.DateTime value);
        partial void OnEntryDateChanged();
        partial void OnCompanyIdChanging(string value);
        partial void OnCompanyIdChanged();
        partial void OnIsValidatedChanging(System.Nullable<bool> value);
        partial void OnIsValidatedChanged();
        partial void OnoTotalChanging(System.Nullable<decimal> value);
        partial void OnoTotalChanged();
        partial void OnoVatChanging(System.Nullable<decimal> value);
        partial void OnoVatChanged();
        partial void OnoCurrencyChanging(string value);
        partial void OnoCurrencyChanged();
        partial void OnoPeriodeChanging(string value);
        partial void OnoPeriodeChanged();
        partial void OnoNetChanging(System.Nullable<decimal> value);
        partial void OnoNetChanged();
        partial void OnoYearChanging(string value);
        partial void OnoYearChanged();
        partial void OnoMonthChanging(string value);
        partial void OnoMonthChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public MasterLogistic()
        {
            this._DetailLogistics = new EntitySet<DetailLogistic>(new Action<DetailLogistic>(this.attach_DetailLogistics), new Action<DetailLogistic>(this.detach_DetailLogistics));
            this._Company = default(EntityRef<Company>);
            this._Store1 = default(EntityRef<Store>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oid", DbType = "Int NOT NULL")]
        public int oid
        {
            get
            {
                return this._oid;
            }
            set
            {
                if ((this._oid != value))
                {
                    this.OnoidChanging(value);
                    this.SendPropertyChanging();
                    this._oid = value;
                    this.SendPropertyChanged("oid");
                    this.OnoidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_store", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string store
        {
            get
            {
                return this._store;
            }
            set
            {
                if ((this._store != value))
                {
                    if (this._Store1.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnstoreChanging(value);
                    this.SendPropertyChanging();
                    this._store = value;
                    this.SendPropertyChanged("store");
                    this.OnstoreChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_account", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string account
        {
            get
            {
                return this._account;
            }
            set
            {
                if ((this._account != value))
                {
                    this.OnaccountChanging(value);
                    this.SendPropertyChanging();
                    this._account = value;
                    this.SendPropertyChanged("account");
                    this.OnaccountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_HeaderText", DbType = "NVarChar(250)")]
        public string HeaderText
        {
            get
            {
                return this._HeaderText;
            }
            set
            {
                if ((this._HeaderText != value))
                {
                    this.OnHeaderTextChanging(value);
                    this.SendPropertyChanging();
                    this._HeaderText = value;
                    this.SendPropertyChanged("HeaderText");
                    this.OnHeaderTextChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TransDate", DbType = "Date NOT NULL")]
        public System.DateTime TransDate
        {
            get
            {
                return this._TransDate;
            }
            set
            {
                if ((this._TransDate != value))
                {
                    this.OnTransDateChanging(value);
                    this.SendPropertyChanging();
                    this._TransDate = value;
                    this.SendPropertyChanged("TransDate");
                    this.OnTransDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ItemDate", DbType = "Date NOT NULL")]
        public System.DateTime ItemDate
        {
            get
            {
                return this._ItemDate;
            }
            set
            {
                if ((this._ItemDate != value))
                {
                    this.OnItemDateChanging(value);
                    this.SendPropertyChanging();
                    this._ItemDate = value;
                    this.SendPropertyChanged("ItemDate");
                    this.OnItemDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_EntryDate", DbType = "Date NOT NULL")]
        public System.DateTime EntryDate
        {
            get
            {
                return this._EntryDate;
            }
            set
            {
                if ((this._EntryDate != value))
                {
                    this.OnEntryDateChanging(value);
                    this.SendPropertyChanging();
                    this._EntryDate = value;
                    this.SendPropertyChanged("EntryDate");
                    this.OnEntryDateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyId
        {
            get
            {
                return this._CompanyId;
            }
            set
            {
                if ((this._CompanyId != value))
                {
                    if (this._Company.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnCompanyIdChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyId = value;
                    this.SendPropertyChanged("CompanyId");
                    this.OnCompanyIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsValidated", DbType = "Bit")]
        public System.Nullable<bool> IsValidated
        {
            get
            {
                return this._IsValidated;
            }
            set
            {
                if ((this._IsValidated != value))
                {
                    this.OnIsValidatedChanging(value);
                    this.SendPropertyChanging();
                    this._IsValidated = value;
                    this.SendPropertyChanged("IsValidated");
                    this.OnIsValidatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oTotal", AutoSync = AutoSync.Always, DbType = "Money", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public System.Nullable<decimal> oTotal
        {
            get
            {
                return this._oTotal;
            }
            set
            {
                if ((this._oTotal != value))
                {
                    this.OnoTotalChanging(value);
                    this.SendPropertyChanging();
                    this._oTotal = value;
                    this.SendPropertyChanged("oTotal");
                    this.OnoTotalChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oVat", AutoSync = AutoSync.Always, DbType = "Money", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public System.Nullable<decimal> oVat
        {
            get
            {
                return this._oVat;
            }
            set
            {
                if ((this._oVat != value))
                {
                    this.OnoVatChanging(value);
                    this.SendPropertyChanging();
                    this._oVat = value;
                    this.SendPropertyChanged("oVat");
                    this.OnoVatChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oCurrency", AutoSync = AutoSync.Always, DbType = "NVarChar(10)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string oCurrency
        {
            get
            {
                return this._oCurrency;
            }
            set
            {
                if ((this._oCurrency != value))
                {
                    this.OnoCurrencyChanging(value);
                    this.SendPropertyChanging();
                    this._oCurrency = value;
                    this.SendPropertyChanged("oCurrency");
                    this.OnoCurrencyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oPeriode", AutoSync = AutoSync.Always, DbType = "NVarChar(6)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string oPeriode
        {
            get
            {
                return this._oPeriode;
            }
            set
            {
                if ((this._oPeriode != value))
                {
                    this.OnoPeriodeChanging(value);
                    this.SendPropertyChanging();
                    this._oPeriode = value;
                    this.SendPropertyChanged("oPeriode");
                    this.OnoPeriodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oNet", AutoSync = AutoSync.Always, DbType = "Money", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public System.Nullable<decimal> oNet
        {
            get
            {
                return this._oNet;
            }
            set
            {
                if ((this._oNet != value))
                {
                    this.OnoNetChanging(value);
                    this.SendPropertyChanging();
                    this._oNet = value;
                    this.SendPropertyChanged("oNet");
                    this.OnoNetChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oYear", AutoSync = AutoSync.Always, DbType = "Char(4)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string oYear
        {
            get
            {
                return this._oYear;
            }
            set
            {
                if ((this._oYear != value))
                {
                    this.OnoYearChanging(value);
                    this.SendPropertyChanging();
                    this._oYear = value;
                    this.SendPropertyChanged("oYear");
                    this.OnoYearChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oMonth", AutoSync = AutoSync.Always, DbType = "Char(2)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string oMonth
        {
            get
            {
                return this._oMonth;
            }
            set
            {
                if ((this._oMonth != value))
                {
                    this.OnoMonthChanging(value);
                    this.SendPropertyChanging();
                    this._oMonth = value;
                    this.SendPropertyChanged("oMonth");
                    this.OnoMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "MasterLogistic_DetailLogistic", Storage = "_DetailLogistics", ThisKey = "id", OtherKey = "transid")]
        public EntitySet<DetailLogistic> DetailLogistics
        {
            get
            {
                return this._DetailLogistics;
            }
            set
            {
                this._DetailLogistics.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Company_MasterLogistic", Storage = "_Company", ThisKey = "CompanyId", OtherKey = "id", IsForeignKey = true)]
        public Company Company
        {
            get
            {
                return this._Company.Entity;
            }
            set
            {
                Company previousValue = this._Company.Entity;
                if (((previousValue != value)
                            || (this._Company.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Company.Entity = null;
                        previousValue.MasterLogistics.Remove(this);
                    }
                    this._Company.Entity = value;
                    if ((value != null))
                    {
                        value.MasterLogistics.Add(this);
                        this._CompanyId = value.id;
                    }
                    else
                    {
                        this._CompanyId = default(string);
                    }
                    this.SendPropertyChanged("Company");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Store_MasterLogistic", Storage = "_Store1", ThisKey = "store", OtherKey = "id", IsForeignKey = true)]
        public Store Store1
        {
            get
            {
                return this._Store1.Entity;
            }
            set
            {
                Store previousValue = this._Store1.Entity;
                if (((previousValue != value)
                            || (this._Store1.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Store1.Entity = null;
                        previousValue.MasterLogistics.Remove(this);
                    }
                    this._Store1.Entity = value;
                    if ((value != null))
                    {
                        value.MasterLogistics.Add(this);
                        this._store = value.id;
                    }
                    else
                    {
                        this._store = default(string);
                    }
                    this.SendPropertyChanged("Store1");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_DetailLogistics(DetailLogistic entity)
        {
            this.SendPropertyChanging();
            entity.MasterLogistic = this;
        }

        private void detach_DetailLogistics(DetailLogistic entity)
        {
            this.SendPropertyChanging();
            entity.MasterLogistic = null;
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Menu")]
    public partial class Menu : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _ID;

        private string _CompanyID;

        private string _Name;

        private string _Action;

        private string _Controller;

        private string _Roles;

        private System.Nullable<bool> _Disable;

        private System.Nullable<bool> _HasAccess;

        private System.Nullable<int> _Parent;

        private System.Nullable<int> _MenuOrder;

        private System.Nullable<int> _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIDChanging(int value);
        partial void OnIDChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        partial void OnActionChanging(string value);
        partial void OnActionChanged();
        partial void OnControllerChanging(string value);
        partial void OnControllerChanged();
        partial void OnRolesChanging(string value);
        partial void OnRolesChanged();
        partial void OnDisableChanging(System.Nullable<bool> value);
        partial void OnDisableChanged();
        partial void OnHasAccessChanging(System.Nullable<bool> value);
        partial void OnHasAccessChanged();
        partial void OnParentChanging(System.Nullable<int> value);
        partial void OnParentChanged();
        partial void OnMenuOrderChanging(System.Nullable<int> value);
        partial void OnMenuOrderChanged();
        partial void OnModelIdChanging(System.Nullable<int> value);
        partial void OnModelIdChanged();
        #endregion

        public Menu()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ID", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int ID
        {
            get
            {
                return this._ID;
            }
            set
            {
                if ((this._ID != value))
                {
                    this.OnIDChanging(value);
                    this.SendPropertyChanging();
                    this._ID = value;
                    this.SendPropertyChanged("ID");
                    this.OnIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(50)")]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this.OnNameChanging(value);
                    this.SendPropertyChanging();
                    this._Name = value;
                    this.SendPropertyChanged("Name");
                    this.OnNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Action", DbType = "NVarChar(50)")]
        public string Action
        {
            get
            {
                return this._Action;
            }
            set
            {
                if ((this._Action != value))
                {
                    this.OnActionChanging(value);
                    this.SendPropertyChanging();
                    this._Action = value;
                    this.SendPropertyChanged("Action");
                    this.OnActionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Controller", DbType = "NVarChar(50)")]
        public string Controller
        {
            get
            {
                return this._Controller;
            }
            set
            {
                if ((this._Controller != value))
                {
                    this.OnControllerChanging(value);
                    this.SendPropertyChanging();
                    this._Controller = value;
                    this.SendPropertyChanged("Controller");
                    this.OnControllerChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Roles", DbType = "NVarChar(150)")]
        public string Roles
        {
            get
            {
                return this._Roles;
            }
            set
            {
                if ((this._Roles != value))
                {
                    this.OnRolesChanging(value);
                    this.SendPropertyChanging();
                    this._Roles = value;
                    this.SendPropertyChanged("Roles");
                    this.OnRolesChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Disable", DbType = "Bit")]
        public System.Nullable<bool> Disable
        {
            get
            {
                return this._Disable;
            }
            set
            {
                if ((this._Disable != value))
                {
                    this.OnDisableChanging(value);
                    this.SendPropertyChanging();
                    this._Disable = value;
                    this.SendPropertyChanged("Disable");
                    this.OnDisableChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_HasAccess", DbType = "Bit")]
        public System.Nullable<bool> HasAccess
        {
            get
            {
                return this._HasAccess;
            }
            set
            {
                if ((this._HasAccess != value))
                {
                    this.OnHasAccessChanging(value);
                    this.SendPropertyChanging();
                    this._HasAccess = value;
                    this.SendPropertyChanged("HasAccess");
                    this.OnHasAccessChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Parent", DbType = "Int")]
        public System.Nullable<int> Parent
        {
            get
            {
                return this._Parent;
            }
            set
            {
                if ((this._Parent != value))
                {
                    this.OnParentChanging(value);
                    this.SendPropertyChanging();
                    this._Parent = value;
                    this.SendPropertyChanged("Parent");
                    this.OnParentChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_MenuOrder", DbType = "Int")]
        public System.Nullable<int> MenuOrder
        {
            get
            {
                return this._MenuOrder;
            }
            set
            {
                if ((this._MenuOrder != value))
                {
                    this.OnMenuOrderChanging(value);
                    this.SendPropertyChanging();
                    this._MenuOrder = value;
                    this.SendPropertyChanged("MenuOrder");
                    this.OnMenuOrderChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int")]
        public System.Nullable<int> ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.PeriodicAccountBalance")]
    public partial class PeriodicAccountBalance : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _Id;

        private string _Name;

        private string _AccountId;

        private string _Periode;

        private decimal _Debit;

        private decimal _Credit;

        private string _CompanyID;

        private string _Currency;

        private decimal _FinalBalance;

        private decimal _InitialBalance;

        private string _oYear;

        private string _oMonth;

        private int _ModelId;

        private EntityRef<Account> _Account;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(int value);
        partial void OnIdChanged();
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        partial void OnAccountIdChanging(string value);
        partial void OnAccountIdChanged();
        partial void OnPeriodeChanging(string value);
        partial void OnPeriodeChanged();
        partial void OnDebitChanging(decimal value);
        partial void OnDebitChanged();
        partial void OnCreditChanging(decimal value);
        partial void OnCreditChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnCurrencyChanging(string value);
        partial void OnCurrencyChanged();
        partial void OnFinalBalanceChanging(decimal value);
        partial void OnFinalBalanceChanged();
        partial void OnInitialBalanceChanging(decimal value);
        partial void OnInitialBalanceChanged();
        partial void OnoYearChanging(string value);
        partial void OnoYearChanged();
        partial void OnoMonthChanging(string value);
        partial void OnoMonthChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public PeriodicAccountBalance()
        {
            this._Account = default(EntityRef<Account>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this.OnNameChanging(value);
                    this.SendPropertyChanging();
                    this._Name = value;
                    this.SendPropertyChanged("Name");
                    this.OnNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string AccountId
        {
            get
            {
                return this._AccountId;
            }
            set
            {
                if ((this._AccountId != value))
                {
                    if (this._Account.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnAccountIdChanging(value);
                    this.SendPropertyChanging();
                    this._AccountId = value;
                    this.SendPropertyChanged("AccountId");
                    this.OnAccountIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Periode", DbType = "NVarChar(6) NOT NULL", CanBeNull = false)]
        public string Periode
        {
            get
            {
                return this._Periode;
            }
            set
            {
                if ((this._Periode != value))
                {
                    this.OnPeriodeChanging(value);
                    this.SendPropertyChanging();
                    this._Periode = value;
                    this.SendPropertyChanged("Periode");
                    this.OnPeriodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Debit", DbType = "Decimal(18,2) NOT NULL")]
        public decimal Debit
        {
            get
            {
                return this._Debit;
            }
            set
            {
                if ((this._Debit != value))
                {
                    this.OnDebitChanging(value);
                    this.SendPropertyChanging();
                    this._Debit = value;
                    this.SendPropertyChanged("Debit");
                    this.OnDebitChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Credit", DbType = "Decimal(18,2) NOT NULL")]
        public decimal Credit
        {
            get
            {
                return this._Credit;
            }
            set
            {
                if ((this._Credit != value))
                {
                    this.OnCreditChanging(value);
                    this.SendPropertyChanging();
                    this._Credit = value;
                    this.SendPropertyChanged("Credit");
                    this.OnCreditChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this.OnCurrencyChanging(value);
                    this.SendPropertyChanging();
                    this._Currency = value;
                    this.SendPropertyChanged("Currency");
                    this.OnCurrencyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FinalBalance", DbType = "Decimal(18,2) NOT NULL")]
        public decimal FinalBalance
        {
            get
            {
                return this._FinalBalance;
            }
            set
            {
                if ((this._FinalBalance != value))
                {
                    this.OnFinalBalanceChanging(value);
                    this.SendPropertyChanging();
                    this._FinalBalance = value;
                    this.SendPropertyChanged("FinalBalance");
                    this.OnFinalBalanceChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_InitialBalance", DbType = "Decimal(18,2) NOT NULL")]
        public decimal InitialBalance
        {
            get
            {
                return this._InitialBalance;
            }
            set
            {
                if ((this._InitialBalance != value))
                {
                    this.OnInitialBalanceChanging(value);
                    this.SendPropertyChanging();
                    this._InitialBalance = value;
                    this.SendPropertyChanged("InitialBalance");
                    this.OnInitialBalanceChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oYear", AutoSync = AutoSync.Always, DbType = "Char(4)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string oYear
        {
            get
            {
                return this._oYear;
            }
            set
            {
                if ((this._oYear != value))
                {
                    this.OnoYearChanging(value);
                    this.SendPropertyChanging();
                    this._oYear = value;
                    this.SendPropertyChanged("oYear");
                    this.OnoYearChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oMonth", AutoSync = AutoSync.Always, DbType = "Char(2)", IsDbGenerated = true, UpdateCheck = UpdateCheck.Never)]
        public string oMonth
        {
            get
            {
                return this._oMonth;
            }
            set
            {
                if ((this._oMonth != value))
                {
                    this.OnoMonthChanging(value);
                    this.SendPropertyChanging();
                    this._oMonth = value;
                    this.SendPropertyChanged("oMonth");
                    this.OnoMonthChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_PeriodicAccountBalance", Storage = "_Account", ThisKey = "AccountId", OtherKey = "id", IsForeignKey = true)]
        public Account Account
        {
            get
            {
                return this._Account.Entity;
            }
            set
            {
                Account previousValue = this._Account.Entity;
                if (((previousValue != value)
                            || (this._Account.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Account.Entity = null;
                        previousValue.PeriodicAccountBalances.Remove(this);
                    }
                    this._Account.Entity = value;
                    if ((value != null))
                    {
                        value.PeriodicAccountBalances.Add(this);
                        this._AccountId = value.id;
                    }
                    else
                    {
                        this._AccountId = default(string);
                    }
                    this.SendPropertyChanged("Account");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.QuantityUnit")]
    public partial class QuantityUnit : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _id;

        private string _name;

        private string _description;

        private string _CompanyID;

        private System.DateTime _Posted;

        private System.DateTime _Updated;

        private int _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(string value);
        partial void OnidChanged();
        partial void OnnameChanging(string value);
        partial void OnnameChanged();
        partial void OndescriptionChanging(string value);
        partial void OndescriptionChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnPostedChanging(System.DateTime value);
        partial void OnPostedChanged();
        partial void OnUpdatedChanging(System.DateTime value);
        partial void OnUpdatedChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public QuantityUnit()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this.OnnameChanging(value);
                    this.SendPropertyChanging();
                    this._name = value;
                    this.SendPropertyChanged("name");
                    this.OnnameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_description", DbType = "NVarChar(255)")]
        public string description
        {
            get
            {
                return this._description;
            }
            set
            {
                if ((this._description != value))
                {
                    this.OndescriptionChanging(value);
                    this.SendPropertyChanging();
                    this._description = value;
                    this.SendPropertyChanged("description");
                    this.OndescriptionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Posted", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Posted
        {
            get
            {
                return this._Posted;
            }
            set
            {
                if ((this._Posted != value))
                {
                    this.OnPostedChanging(value);
                    this.SendPropertyChanging();
                    this._Posted = value;
                    this.SendPropertyChanged("Posted");
                    this.OnPostedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Updated", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Updated
        {
            get
            {
                return this._Updated;
            }
            set
            {
                if ((this._Updated != value))
                {
                    this.OnUpdatedChanging(value);
                    this.SendPropertyChanging();
                    this._Updated = value;
                    this.SendPropertyChanged("Updated");
                    this.OnUpdatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Stock")]
    public partial class Stock : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private int _id;

        private string _name;

        private string _description;

        private string _itemid;

        private string _storeid;

        private float _quantity;

        private short _minstock;

        private string _CompanyID;

        private string _Currency;

        private int _ModelId;

        private EntityRef<Article> _Article;

        private EntityRef<Store> _Store;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(int value);
        partial void OnidChanged();
        partial void OnnameChanging(string value);
        partial void OnnameChanged();
        partial void OndescriptionChanging(string value);
        partial void OndescriptionChanged();
        partial void OnitemidChanging(string value);
        partial void OnitemidChanged();
        partial void OnstoreidChanging(string value);
        partial void OnstoreidChanged();
        partial void OnquantityChanging(float value);
        partial void OnquantityChanged();
        partial void OnminstockChanging(short value);
        partial void OnminstockChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnCurrencyChanging(string value);
        partial void OnCurrencyChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public Stock()
        {
            this._Article = default(EntityRef<Article>);
            this._Store = default(EntityRef<Store>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", AutoSync = AutoSync.OnInsert, DbType = "Int NOT NULL IDENTITY", IsPrimaryKey = true, IsDbGenerated = true)]
        public int id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this.OnnameChanging(value);
                    this.SendPropertyChanging();
                    this._name = value;
                    this.SendPropertyChanged("name");
                    this.OnnameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_description", DbType = "NVarChar(255)")]
        public string description
        {
            get
            {
                return this._description;
            }
            set
            {
                if ((this._description != value))
                {
                    this.OndescriptionChanging(value);
                    this.SendPropertyChanging();
                    this._description = value;
                    this.SendPropertyChanged("description");
                    this.OndescriptionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_itemid", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string itemid
        {
            get
            {
                return this._itemid;
            }
            set
            {
                if ((this._itemid != value))
                {
                    if (this._Article.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnitemidChanging(value);
                    this.SendPropertyChanging();
                    this._itemid = value;
                    this.SendPropertyChanged("itemid");
                    this.OnitemidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_storeid", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string storeid
        {
            get
            {
                return this._storeid;
            }
            set
            {
                if ((this._storeid != value))
                {
                    if (this._Store.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnstoreidChanging(value);
                    this.SendPropertyChanging();
                    this._storeid = value;
                    this.SendPropertyChanged("storeid");
                    this.OnstoreidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_quantity", DbType = "Real NOT NULL")]
        public float quantity
        {
            get
            {
                return this._quantity;
            }
            set
            {
                if ((this._quantity != value))
                {
                    this.OnquantityChanging(value);
                    this.SendPropertyChanging();
                    this._quantity = value;
                    this.SendPropertyChanged("quantity");
                    this.OnquantityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_minstock", DbType = "SmallInt NOT NULL")]
        public short minstock
        {
            get
            {
                return this._minstock;
            }
            set
            {
                if ((this._minstock != value))
                {
                    this.OnminstockChanging(value);
                    this.SendPropertyChanging();
                    this._minstock = value;
                    this.SendPropertyChanged("minstock");
                    this.OnminstockChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this.OnCurrencyChanging(value);
                    this.SendPropertyChanging();
                    this._Currency = value;
                    this.SendPropertyChanged("Currency");
                    this.OnCurrencyChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Article_Stock", Storage = "_Article", ThisKey = "itemid", OtherKey = "id", IsForeignKey = true)]
        public Article Article
        {
            get
            {
                return this._Article.Entity;
            }
            set
            {
                Article previousValue = this._Article.Entity;
                if (((previousValue != value)
                            || (this._Article.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Article.Entity = null;
                        previousValue.Stocks.Remove(this);
                    }
                    this._Article.Entity = value;
                    if ((value != null))
                    {
                        value.Stocks.Add(this);
                        this._itemid = value.id;
                    }
                    else
                    {
                        this._itemid = default(string);
                    }
                    this.SendPropertyChanged("Article");
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Store_Stock", Storage = "_Store", ThisKey = "storeid", OtherKey = "id", IsForeignKey = true)]
        public Store Store
        {
            get
            {
                return this._Store.Entity;
            }
            set
            {
                Store previousValue = this._Store.Entity;
                if (((previousValue != value)
                            || (this._Store.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Store.Entity = null;
                        previousValue.Stocks.Remove(this);
                    }
                    this._Store.Entity = value;
                    if ((value != null))
                    {
                        value.Stocks.Add(this);
                        this._storeid = value.id;
                    }
                    else
                    {
                        this._storeid = default(string);
                    }
                    this.SendPropertyChanged("Store");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Store")]
    public partial class Store : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _id;

        private string _name;

        private string _street;

        private string _city;

        private string _state;

        private string _zip;

        private string _accountid;

        private string _CompanyID;

        private System.DateTime _Posted;

        private System.DateTime _Updated;

        private int _ModelId;

        private EntitySet<MasterLogistic> _MasterLogistics;

        private EntitySet<Stock> _Stocks;

        private EntityRef<Account> _Account;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(string value);
        partial void OnidChanged();
        partial void OnnameChanging(string value);
        partial void OnnameChanged();
        partial void OnstreetChanging(string value);
        partial void OnstreetChanged();
        partial void OncityChanging(string value);
        partial void OncityChanged();
        partial void OnstateChanging(string value);
        partial void OnstateChanged();
        partial void OnzipChanging(string value);
        partial void OnzipChanged();
        partial void OnaccountidChanging(string value);
        partial void OnaccountidChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnPostedChanging(System.DateTime value);
        partial void OnPostedChanged();
        partial void OnUpdatedChanging(System.DateTime value);
        partial void OnUpdatedChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public Store()
        {
            this._MasterLogistics = new EntitySet<MasterLogistic>(new Action<MasterLogistic>(this.attach_MasterLogistics), new Action<MasterLogistic>(this.detach_MasterLogistics));
            this._Stocks = new EntitySet<Stock>(new Action<Stock>(this.attach_Stocks), new Action<Stock>(this.detach_Stocks));
            this._Account = default(EntityRef<Account>);
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this.OnnameChanging(value);
                    this.SendPropertyChanging();
                    this._name = value;
                    this.SendPropertyChanged("name");
                    this.OnnameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_street", DbType = "NVarChar(50)")]
        public string street
        {
            get
            {
                return this._street;
            }
            set
            {
                if ((this._street != value))
                {
                    this.OnstreetChanging(value);
                    this.SendPropertyChanging();
                    this._street = value;
                    this.SendPropertyChanged("street");
                    this.OnstreetChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_city", DbType = "NVarChar(50)")]
        public string city
        {
            get
            {
                return this._city;
            }
            set
            {
                if ((this._city != value))
                {
                    this.OncityChanging(value);
                    this.SendPropertyChanging();
                    this._city = value;
                    this.SendPropertyChanged("city");
                    this.OncityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_state", DbType = "NVarChar(50)")]
        public string state
        {
            get
            {
                return this._state;
            }
            set
            {
                if ((this._state != value))
                {
                    this.OnstateChanging(value);
                    this.SendPropertyChanging();
                    this._state = value;
                    this.SendPropertyChanged("state");
                    this.OnstateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_zip", DbType = "NVarChar(50)")]
        public string zip
        {
            get
            {
                return this._zip;
            }
            set
            {
                if ((this._zip != value))
                {
                    this.OnzipChanging(value);
                    this.SendPropertyChanging();
                    this._zip = value;
                    this.SendPropertyChanged("zip");
                    this.OnzipChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_accountid", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string accountid
        {
            get
            {
                return this._accountid;
            }
            set
            {
                if ((this._accountid != value))
                {
                    if (this._Account.HasLoadedOrAssignedValue)
                    {
                        throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
                    }
                    this.OnaccountidChanging(value);
                    this.SendPropertyChanging();
                    this._accountid = value;
                    this.SendPropertyChanged("accountid");
                    this.OnaccountidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Posted", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Posted
        {
            get
            {
                return this._Posted;
            }
            set
            {
                if ((this._Posted != value))
                {
                    this.OnPostedChanging(value);
                    this.SendPropertyChanging();
                    this._Posted = value;
                    this.SendPropertyChanged("Posted");
                    this.OnPostedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Updated", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Updated
        {
            get
            {
                return this._Updated;
            }
            set
            {
                if ((this._Updated != value))
                {
                    this.OnUpdatedChanging(value);
                    this.SendPropertyChanging();
                    this._Updated = value;
                    this.SendPropertyChanged("Updated");
                    this.OnUpdatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Store_MasterLogistic", Storage = "_MasterLogistics", ThisKey = "id", OtherKey = "store")]
        public EntitySet<MasterLogistic> MasterLogistics
        {
            get
            {
                return this._MasterLogistics;
            }
            set
            {
                this._MasterLogistics.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Store_Stock", Storage = "_Stocks", ThisKey = "id", OtherKey = "storeid")]
        public EntitySet<Stock> Stocks
        {
            get
            {
                return this._Stocks;
            }
            set
            {
                this._Stocks.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Account_Store", Storage = "_Account", ThisKey = "accountid", OtherKey = "id", IsForeignKey = true)]
        public Account Account
        {
            get
            {
                return this._Account.Entity;
            }
            set
            {
                Account previousValue = this._Account.Entity;
                if (((previousValue != value)
                            || (this._Account.HasLoadedOrAssignedValue == false)))
                {
                    this.SendPropertyChanging();
                    if ((previousValue != null))
                    {
                        this._Account.Entity = null;
                        previousValue.Stores.Remove(this);
                    }
                    this._Account.Entity = value;
                    if ((value != null))
                    {
                        value.Stores.Add(this);
                        this._accountid = value.id;
                    }
                    else
                    {
                        this._accountid = default(string);
                    }
                    this.SendPropertyChanged("Account");
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_MasterLogistics(MasterLogistic entity)
        {
            this.SendPropertyChanging();
            entity.Store1 = this;
        }

        private void detach_MasterLogistics(MasterLogistic entity)
        {
            this.SendPropertyChanging();
            entity.Store1 = null;
        }

        private void attach_Stocks(Stock entity)
        {
            this.SendPropertyChanging();
            entity.Store = this;
        }

        private void detach_Stocks(Stock entity)
        {
            this.SendPropertyChanging();
            entity.Store = null;
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Supplier")]
    public partial class Supplier : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _id;

        private string _name;

        private string _street;

        private string _city;

        private string _state;

        private string _zip;

        private string _Phone;

        private string _Email;

        private string _accountid;

        private string _CompanyID;

        private string _IBAN;

        private string _Bank;

        private string _BIC;

        private string _VatCode;

        private string _Charge;

        private System.DateTime _Posted;

        private System.DateTime _Updated;

        private int _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(string value);
        partial void OnidChanged();
        partial void OnnameChanging(string value);
        partial void OnnameChanged();
        partial void OnstreetChanging(string value);
        partial void OnstreetChanged();
        partial void OncityChanging(string value);
        partial void OncityChanged();
        partial void OnstateChanging(string value);
        partial void OnstateChanged();
        partial void OnzipChanging(string value);
        partial void OnzipChanged();
        partial void OnPhoneChanging(string value);
        partial void OnPhoneChanged();
        partial void OnEmailChanging(string value);
        partial void OnEmailChanged();
        partial void OnaccountidChanging(string value);
        partial void OnaccountidChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnIBANChanging(string value);
        partial void OnIBANChanged();
        partial void OnBankChanging(string value);
        partial void OnBankChanged();
        partial void OnBICChanging(string value);
        partial void OnBICChanged();
        partial void OnVatCodeChanging(string value);
        partial void OnVatCodeChanged();
        partial void OnChargeChanging(string value);
        partial void OnChargeChanged();
        partial void OnPostedChanging(System.DateTime value);
        partial void OnPostedChanged();
        partial void OnUpdatedChanging(System.DateTime value);
        partial void OnUpdatedChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public Supplier()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this.OnnameChanging(value);
                    this.SendPropertyChanging();
                    this._name = value;
                    this.SendPropertyChanged("name");
                    this.OnnameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_street", DbType = "NVarChar(255)")]
        public string street
        {
            get
            {
                return this._street;
            }
            set
            {
                if ((this._street != value))
                {
                    this.OnstreetChanging(value);
                    this.SendPropertyChanging();
                    this._street = value;
                    this.SendPropertyChanged("street");
                    this.OnstreetChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_city", DbType = "NVarChar(255)")]
        public string city
        {
            get
            {
                return this._city;
            }
            set
            {
                if ((this._city != value))
                {
                    this.OncityChanging(value);
                    this.SendPropertyChanging();
                    this._city = value;
                    this.SendPropertyChanged("city");
                    this.OncityChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_state", DbType = "NVarChar(255)")]
        public string state
        {
            get
            {
                return this._state;
            }
            set
            {
                if ((this._state != value))
                {
                    this.OnstateChanging(value);
                    this.SendPropertyChanging();
                    this._state = value;
                    this.SendPropertyChanged("state");
                    this.OnstateChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_zip", DbType = "NVarChar(255)")]
        public string zip
        {
            get
            {
                return this._zip;
            }
            set
            {
                if ((this._zip != value))
                {
                    this.OnzipChanging(value);
                    this.SendPropertyChanging();
                    this._zip = value;
                    this.SendPropertyChanged("zip");
                    this.OnzipChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Phone", DbType = "NVarChar(50)")]
        public string Phone
        {
            get
            {
                return this._Phone;
            }
            set
            {
                if ((this._Phone != value))
                {
                    this.OnPhoneChanging(value);
                    this.SendPropertyChanging();
                    this._Phone = value;
                    this.SendPropertyChanged("Phone");
                    this.OnPhoneChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Email", DbType = "NVarChar(50)")]
        public string Email
        {
            get
            {
                return this._Email;
            }
            set
            {
                if ((this._Email != value))
                {
                    this.OnEmailChanging(value);
                    this.SendPropertyChanging();
                    this._Email = value;
                    this.SendPropertyChanged("Email");
                    this.OnEmailChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_accountid", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string accountid
        {
            get
            {
                return this._accountid;
            }
            set
            {
                if ((this._accountid != value))
                {
                    this.OnaccountidChanging(value);
                    this.SendPropertyChanging();
                    this._accountid = value;
                    this.SendPropertyChanged("accountid");
                    this.OnaccountidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IBAN", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string IBAN
        {
            get
            {
                return this._IBAN;
            }
            set
            {
                if ((this._IBAN != value))
                {
                    this.OnIBANChanging(value);
                    this.SendPropertyChanging();
                    this._IBAN = value;
                    this.SendPropertyChanged("IBAN");
                    this.OnIBANChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Bank", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string Bank
        {
            get
            {
                return this._Bank;
            }
            set
            {
                if ((this._Bank != value))
                {
                    this.OnBankChanging(value);
                    this.SendPropertyChanging();
                    this._Bank = value;
                    this.SendPropertyChanged("Bank");
                    this.OnBankChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_BIC", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string BIC
        {
            get
            {
                return this._BIC;
            }
            set
            {
                if ((this._BIC != value))
                {
                    this.OnBICChanging(value);
                    this.SendPropertyChanging();
                    this._BIC = value;
                    this.SendPropertyChanged("BIC");
                    this.OnBICChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_VatCode", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string VatCode
        {
            get
            {
                return this._VatCode;
            }
            set
            {
                if ((this._VatCode != value))
                {
                    this.OnVatCodeChanging(value);
                    this.SendPropertyChanging();
                    this._VatCode = value;
                    this.SendPropertyChanged("VatCode");
                    this.OnVatCodeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Charge", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string Charge
        {
            get
            {
                return this._Charge;
            }
            set
            {
                if ((this._Charge != value))
                {
                    this.OnChargeChanging(value);
                    this.SendPropertyChanging();
                    this._Charge = value;
                    this.SendPropertyChanged("Charge");
                    this.OnChargeChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Posted", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Posted
        {
            get
            {
                return this._Posted;
            }
            set
            {
                if ((this._Posted != value))
                {
                    this.OnPostedChanging(value);
                    this.SendPropertyChanging();
                    this._Posted = value;
                    this.SendPropertyChanged("Posted");
                    this.OnPostedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Updated", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Updated
        {
            get
            {
                return this._Updated;
            }
            set
            {
                if ((this._Updated != value))
                {
                    this.OnUpdatedChanging(value);
                    this.SendPropertyChanging();
                    this._Updated = value;
                    this.SendPropertyChanged("Updated");
                    this.OnUpdatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.tempAccountAmount")]
    public partial class tempAccountAmount : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private decimal _AccountAmount;

        private string _AccountCode;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnAccountAmountChanging(decimal value);
        partial void OnAccountAmountChanged();
        partial void OnAccountCodeChanging(string value);
        partial void OnAccountCodeChanged();
        #endregion

        public tempAccountAmount()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountAmount", DbType = "Decimal(18,2) NOT NULL", IsPrimaryKey = true)]
        public decimal AccountAmount
        {
            get
            {
                return this._AccountAmount;
            }
            set
            {
                if ((this._AccountAmount != value))
                {
                    this.OnAccountAmountChanging(value);
                    this.SendPropertyChanging();
                    this._AccountAmount = value;
                    this.SendPropertyChanged("AccountAmount");
                    this.OnAccountAmountChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountCode", DbType = "NVarChar(10) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string AccountCode
        {
            get
            {
                return this._AccountCode;
            }
            set
            {
                if ((this._AccountCode != value))
                {
                    this.OnAccountCodeChanging(value);
                    this.SendPropertyChanging();
                    this._AccountCode = value;
                    this.SendPropertyChanged("AccountCode");
                    this.OnAccountCodeChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.TypeBrouillard")]
    public partial class TypeBrouillard : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _ItemID;

        private string _UICulture;

        private string _Name;

        private System.Nullable<int> _ModelId;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnItemIDChanging(string value);
        partial void OnItemIDChanged();
        partial void OnUICultureChanging(string value);
        partial void OnUICultureChanged();
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        partial void OnModelIdChanging(System.Nullable<int> value);
        partial void OnModelIdChanged();
        #endregion

        public TypeBrouillard()
        {
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ItemID", DbType = "Char(2) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string ItemID
        {
            get
            {
                return this._ItemID;
            }
            set
            {
                if ((this._ItemID != value))
                {
                    this.OnItemIDChanging(value);
                    this.SendPropertyChanging();
                    this._ItemID = value;
                    this.SendPropertyChanged("ItemID");
                    this.OnItemIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_UICulture", DbType = "Char(5) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string UICulture
        {
            get
            {
                return this._UICulture;
            }
            set
            {
                if ((this._UICulture != value))
                {
                    this.OnUICultureChanging(value);
                    this.SendPropertyChanging();
                    this._UICulture = value;
                    this.SendPropertyChanged("UICulture");
                    this.OnUICultureChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this.OnNameChanging(value);
                    this.SendPropertyChanging();
                    this._Name = value;
                    this.SendPropertyChanged("Name");
                    this.OnNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int")]
        public System.Nullable<int> ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.TypeJournal")]
    public partial class TypeJournal : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _Id;

        private string _Name;

        private string _Description;

        private System.DateTime _Posted;

        private System.DateTime _Updated;

        private string _CompanyId;

        private int _ModelId;

        private EntitySet<Account> _Accounts;

        private EntitySet<AffectationJournal> _AffectationJournals;

        private EntitySet<MasterCompta> _MasterComptas;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnIdChanging(string value);
        partial void OnIdChanged();
        partial void OnNameChanging(string value);
        partial void OnNameChanged();
        partial void OnDescriptionChanging(string value);
        partial void OnDescriptionChanged();
        partial void OnPostedChanging(System.DateTime value);
        partial void OnPostedChanged();
        partial void OnUpdatedChanging(System.DateTime value);
        partial void OnUpdatedChanged();
        partial void OnCompanyIdChanging(string value);
        partial void OnCompanyIdChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public TypeJournal()
        {
            this._Accounts = new EntitySet<Account>(new Action<Account>(this.attach_Accounts), new Action<Account>(this.detach_Accounts));
            this._AffectationJournals = new EntitySet<AffectationJournal>(new Action<AffectationJournal>(this.attach_AffectationJournals), new Action<AffectationJournal>(this.detach_AffectationJournals));
            this._MasterComptas = new EntitySet<MasterCompta>(new Action<MasterCompta>(this.attach_MasterComptas), new Action<MasterCompta>(this.detach_MasterComptas));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", DbType = "VarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this.OnIdChanging(value);
                    this.SendPropertyChanging();
                    this._Id = value;
                    this.SendPropertyChanged("Id");
                    this.OnIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(150) NOT NULL", CanBeNull = false)]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this.OnNameChanging(value);
                    this.SendPropertyChanging();
                    this._Name = value;
                    this.SendPropertyChanged("Name");
                    this.OnNameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Description", DbType = "NVarChar(250)")]
        public string Description
        {
            get
            {
                return this._Description;
            }
            set
            {
                if ((this._Description != value))
                {
                    this.OnDescriptionChanging(value);
                    this.SendPropertyChanging();
                    this._Description = value;
                    this.SendPropertyChanged("Description");
                    this.OnDescriptionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Posted", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Posted
        {
            get
            {
                return this._Posted;
            }
            set
            {
                if ((this._Posted != value))
                {
                    this.OnPostedChanging(value);
                    this.SendPropertyChanging();
                    this._Posted = value;
                    this.SendPropertyChanged("Posted");
                    this.OnPostedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Updated", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Updated
        {
            get
            {
                return this._Updated;
            }
            set
            {
                if ((this._Updated != value))
                {
                    this.OnUpdatedChanging(value);
                    this.SendPropertyChanging();
                    this._Updated = value;
                    this.SendPropertyChanged("Updated");
                    this.OnUpdatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyId
        {
            get
            {
                return this._CompanyId;
            }
            set
            {
                if ((this._CompanyId != value))
                {
                    this.OnCompanyIdChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyId = value;
                    this.SendPropertyChanged("CompanyId");
                    this.OnCompanyIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "TypeJournal_Account", Storage = "_Accounts", ThisKey = "Id", OtherKey = "TypeJournal")]
        public EntitySet<Account> Accounts
        {
            get
            {
                return this._Accounts;
            }
            set
            {
                this._Accounts.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "TypeJournal_AffectationJournal", Storage = "_AffectationJournals", ThisKey = "Id", OtherKey = "TypeJournalID")]
        public EntitySet<AffectationJournal> AffectationJournals
        {
            get
            {
                return this._AffectationJournals;
            }
            set
            {
                this._AffectationJournals.Assign(value);
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "TypeJournal_MasterCompta", Storage = "_MasterComptas", ThisKey = "Id", OtherKey = "TypeJournal")]
        public EntitySet<MasterCompta> MasterComptas
        {
            get
            {
                return this._MasterComptas;
            }
            set
            {
                this._MasterComptas.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_Accounts(Account entity)
        {
            this.SendPropertyChanging();
            entity.TypeJournal1 = this;
        }

        private void detach_Accounts(Account entity)
        {
            this.SendPropertyChanging();
            entity.TypeJournal1 = null;
        }

        private void attach_AffectationJournals(AffectationJournal entity)
        {
            this.SendPropertyChanging();
            entity.TypeJournal = this;
        }

        private void detach_AffectationJournals(AffectationJournal entity)
        {
            this.SendPropertyChanging();
            entity.TypeJournal = null;
        }

        private void attach_MasterComptas(MasterCompta entity)
        {
            this.SendPropertyChanging();
            entity.TypeJournal1 = this;
        }

        private void detach_MasterComptas(MasterCompta entity)
        {
            this.SendPropertyChanging();
            entity.TypeJournal1 = null;
        }
    }

    [global::System.Data.Linq.Mapping.TableAttribute(Name = "dbo.Vat")]
    public partial class Vat : INotifyPropertyChanging, INotifyPropertyChanged
    {

        private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);

        private string _id;

        private string _name;

        private string _description;

        private decimal _PVat;

        private string _inputvataccountid;

        private string _outputvataccountid;

        private string _revenueaccountid;

        private string _CompanyID;

        private System.DateTime _Posted;

        private System.DateTime _Updated;

        private int _ModelId;

        private EntitySet<Article> _Articles;

        #region Extensibility Method Definitions
        partial void OnLoaded();
        partial void OnValidate(System.Data.Linq.ChangeAction action);
        partial void OnCreated();
        partial void OnidChanging(string value);
        partial void OnidChanged();
        partial void OnnameChanging(string value);
        partial void OnnameChanged();
        partial void OndescriptionChanging(string value);
        partial void OndescriptionChanged();
        partial void OnPVatChanging(decimal value);
        partial void OnPVatChanged();
        partial void OninputvataccountidChanging(string value);
        partial void OninputvataccountidChanged();
        partial void OnoutputvataccountidChanging(string value);
        partial void OnoutputvataccountidChanged();
        partial void OnrevenueaccountidChanging(string value);
        partial void OnrevenueaccountidChanged();
        partial void OnCompanyIDChanging(string value);
        partial void OnCompanyIDChanged();
        partial void OnPostedChanging(System.DateTime value);
        partial void OnPostedChanged();
        partial void OnUpdatedChanging(System.DateTime value);
        partial void OnUpdatedChanged();
        partial void OnModelIdChanging(int value);
        partial void OnModelIdChanged();
        #endregion

        public Vat()
        {
            this._Articles = new EntitySet<Article>(new Action<Article>(this.attach_Articles), new Action<Article>(this.detach_Articles));
            OnCreated();
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50) NOT NULL", CanBeNull = false, IsPrimaryKey = true)]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this.OnidChanging(value);
                    this.SendPropertyChanging();
                    this._id = value;
                    this.SendPropertyChanged("id");
                    this.OnidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this.OnnameChanging(value);
                    this.SendPropertyChanging();
                    this._name = value;
                    this.SendPropertyChanged("name");
                    this.OnnameChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_description", DbType = "NVarChar(255)")]
        public string description
        {
            get
            {
                return this._description;
            }
            set
            {
                if ((this._description != value))
                {
                    this.OndescriptionChanging(value);
                    this.SendPropertyChanging();
                    this._description = value;
                    this.SendPropertyChanged("description");
                    this.OndescriptionChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_PVat", DbType = "Decimal(3,2) NOT NULL")]
        public decimal PVat
        {
            get
            {
                return this._PVat;
            }
            set
            {
                if ((this._PVat != value))
                {
                    this.OnPVatChanging(value);
                    this.SendPropertyChanging();
                    this._PVat = value;
                    this.SendPropertyChanged("PVat");
                    this.OnPVatChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_inputvataccountid", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string inputvataccountid
        {
            get
            {
                return this._inputvataccountid;
            }
            set
            {
                if ((this._inputvataccountid != value))
                {
                    this.OninputvataccountidChanging(value);
                    this.SendPropertyChanging();
                    this._inputvataccountid = value;
                    this.SendPropertyChanged("inputvataccountid");
                    this.OninputvataccountidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_outputvataccountid", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string outputvataccountid
        {
            get
            {
                return this._outputvataccountid;
            }
            set
            {
                if ((this._outputvataccountid != value))
                {
                    this.OnoutputvataccountidChanging(value);
                    this.SendPropertyChanging();
                    this._outputvataccountid = value;
                    this.SendPropertyChanged("outputvataccountid");
                    this.OnoutputvataccountidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_revenueaccountid", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string revenueaccountid
        {
            get
            {
                return this._revenueaccountid;
            }
            set
            {
                if ((this._revenueaccountid != value))
                {
                    this.OnrevenueaccountidChanging(value);
                    this.SendPropertyChanging();
                    this._revenueaccountid = value;
                    this.SendPropertyChanged("revenueaccountid");
                    this.OnrevenueaccountidChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this.OnCompanyIDChanging(value);
                    this.SendPropertyChanging();
                    this._CompanyID = value;
                    this.SendPropertyChanged("CompanyID");
                    this.OnCompanyIDChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Posted", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Posted
        {
            get
            {
                return this._Posted;
            }
            set
            {
                if ((this._Posted != value))
                {
                    this.OnPostedChanging(value);
                    this.SendPropertyChanging();
                    this._Posted = value;
                    this.SendPropertyChanged("Posted");
                    this.OnPostedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Updated", DbType = "DateTime2 NOT NULL")]
        public System.DateTime Updated
        {
            get
            {
                return this._Updated;
            }
            set
            {
                if ((this._Updated != value))
                {
                    this.OnUpdatedChanging(value);
                    this.SendPropertyChanging();
                    this._Updated = value;
                    this.SendPropertyChanged("Updated");
                    this.OnUpdatedChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ModelId", DbType = "Int NOT NULL")]
        public int ModelId
        {
            get
            {
                return this._ModelId;
            }
            set
            {
                if ((this._ModelId != value))
                {
                    this.OnModelIdChanging(value);
                    this.SendPropertyChanging();
                    this._ModelId = value;
                    this.SendPropertyChanged("ModelId");
                    this.OnModelIdChanged();
                }
            }
        }

        [global::System.Data.Linq.Mapping.AssociationAttribute(Name = "Vat_Article", Storage = "_Articles", ThisKey = "id", OtherKey = "VatCode")]
        public EntitySet<Article> Articles
        {
            get
            {
                return this._Articles;
            }
            set
            {
                this._Articles.Assign(value);
            }
        }

        public event PropertyChangingEventHandler PropertyChanging;

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void SendPropertyChanging()
        {
            if ((this.PropertyChanging != null))
            {
                this.PropertyChanging(this, emptyChangingEventArgs);
            }
        }

        protected virtual void SendPropertyChanged(String propertyName)
        {
            if ((this.PropertyChanged != null))
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void attach_Articles(Article entity)
        {
            this.SendPropertyChanging();
            entity.Vat = this;
        }

        private void detach_Articles(Article entity)
        {
            this.SendPropertyChanging();
            entity.Vat = null;
        }
    }

    public partial class account1To7Result
    {

        private int _gr;

        private string _ID;

        private string _AccountId;

        private string _Name;

        private System.Nullable<decimal> _TDebit;

        private System.Nullable<decimal> _TCredit;

        private System.Nullable<decimal> _SDebit;

        private System.Nullable<decimal> _SCredit;

        private string _Currency;

        public account1To7Result()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_gr", DbType = "Int NOT NULL")]
        public int gr
        {
            get
            {
                return this._gr;
            }
            set
            {
                if ((this._gr != value))
                {
                    this._gr = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ID", DbType = "NVarChar(1)")]
        public string ID
        {
            get
            {
                return this._ID;
            }
            set
            {
                if ((this._ID != value))
                {
                    this._ID = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string AccountId
        {
            get
            {
                return this._AccountId;
            }
            set
            {
                if ((this._AccountId != value))
                {
                    this._AccountId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this._Name = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TDebit", DbType = "Decimal(38,2)")]
        public System.Nullable<decimal> TDebit
        {
            get
            {
                return this._TDebit;
            }
            set
            {
                if ((this._TDebit != value))
                {
                    this._TDebit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TCredit", DbType = "Decimal(38,2)")]
        public System.Nullable<decimal> TCredit
        {
            get
            {
                return this._TCredit;
            }
            set
            {
                if ((this._TCredit != value))
                {
                    this._TCredit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SDebit", DbType = "Decimal(38,2)")]
        public System.Nullable<decimal> SDebit
        {
            get
            {
                return this._SDebit;
            }
            set
            {
                if ((this._SDebit != value))
                {
                    this._SDebit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SCredit", DbType = "Decimal(38,2)")]
        public System.Nullable<decimal> SCredit
        {
            get
            {
                return this._SCredit;
            }
            set
            {
                if ((this._SCredit != value))
                {
                    this._SCredit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this._Currency = value;
                }
            }
        }
    }

    public partial class ClassAccountBalanceResult
    {

        private string _ID;

        private string _AccountId;

        private string _Name;

        private System.Nullable<decimal> _TDebit;

        private System.Nullable<decimal> _TCredit;

        private System.Nullable<decimal> _SDebit;

        private System.Nullable<decimal> _SCredit;

        private string _Currency;

        public ClassAccountBalanceResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ID", DbType = "NVarChar(1)")]
        public string ID
        {
            get
            {
                return this._ID;
            }
            set
            {
                if ((this._ID != value))
                {
                    this._ID = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string AccountId
        {
            get
            {
                return this._AccountId;
            }
            set
            {
                if ((this._AccountId != value))
                {
                    this._AccountId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this._Name = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TDebit", DbType = "Decimal(38,2)")]
        public System.Nullable<decimal> TDebit
        {
            get
            {
                return this._TDebit;
            }
            set
            {
                if ((this._TDebit != value))
                {
                    this._TDebit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TCredit", DbType = "Decimal(38,2)")]
        public System.Nullable<decimal> TCredit
        {
            get
            {
                return this._TCredit;
            }
            set
            {
                if ((this._TCredit != value))
                {
                    this._TCredit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SDebit", DbType = "Decimal(38,2)")]
        public System.Nullable<decimal> SDebit
        {
            get
            {
                return this._SDebit;
            }
            set
            {
                if ((this._SDebit != value))
                {
                    this._SDebit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SCredit", DbType = "Decimal(38,2)")]
        public System.Nullable<decimal> SCredit
        {
            get
            {
                return this._SCredit;
            }
            set
            {
                if ((this._SCredit != value))
                {
                    this._SCredit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this._Currency = value;
                }
            }
        }
    }

    public partial class ClassAccountBalancesResult
    {

        private int _ID;

        private string _ClassId;

        private string _ClassName;

        private string _SubClassId;

        private string _SubClassName;

        private string _AccountId;

        private string _AccountName;

        private System.Nullable<decimal> _TDebit;

        private System.Nullable<decimal> _TCredit;

        private System.Nullable<decimal> _SDebit;

        private System.Nullable<decimal> _SCredit;

        private string _Currency;

        private System.Nullable<decimal> _Balance;

        private string _CompanyId;

        private System.Nullable<bool> _IsBalance;

        public ClassAccountBalancesResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ID", DbType = "Int NOT NULL")]
        public int ID
        {
            get
            {
                return this._ID;
            }
            set
            {
                if ((this._ID != value))
                {
                    this._ID = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ClassId", DbType = "NVarChar(50)")]
        public string ClassId
        {
            get
            {
                return this._ClassId;
            }
            set
            {
                if ((this._ClassId != value))
                {
                    this._ClassId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ClassName", DbType = "NVarChar(150)")]
        public string ClassName
        {
            get
            {
                return this._ClassName;
            }
            set
            {
                if ((this._ClassName != value))
                {
                    this._ClassName = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SubClassId", DbType = "NVarChar(50)")]
        public string SubClassId
        {
            get
            {
                return this._SubClassId;
            }
            set
            {
                if ((this._SubClassId != value))
                {
                    this._SubClassId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SubClassName", DbType = "NVarChar(150)")]
        public string SubClassName
        {
            get
            {
                return this._SubClassName;
            }
            set
            {
                if ((this._SubClassName != value))
                {
                    this._SubClassName = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountId", DbType = "NVarChar(50)")]
        public string AccountId
        {
            get
            {
                return this._AccountId;
            }
            set
            {
                if ((this._AccountId != value))
                {
                    this._AccountId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountName", DbType = "NVarChar(150)")]
        public string AccountName
        {
            get
            {
                return this._AccountName;
            }
            set
            {
                if ((this._AccountName != value))
                {
                    this._AccountName = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TDebit", DbType = "Money")]
        public System.Nullable<decimal> TDebit
        {
            get
            {
                return this._TDebit;
            }
            set
            {
                if ((this._TDebit != value))
                {
                    this._TDebit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TCredit", DbType = "Money")]
        public System.Nullable<decimal> TCredit
        {
            get
            {
                return this._TCredit;
            }
            set
            {
                if ((this._TCredit != value))
                {
                    this._TCredit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SDebit", DbType = "Money")]
        public System.Nullable<decimal> SDebit
        {
            get
            {
                return this._SDebit;
            }
            set
            {
                if ((this._SDebit != value))
                {
                    this._SDebit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SCredit", DbType = "Money")]
        public System.Nullable<decimal> SCredit
        {
            get
            {
                return this._SCredit;
            }
            set
            {
                if ((this._SCredit != value))
                {
                    this._SCredit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(50)")]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this._Currency = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Balance", DbType = "Money")]
        public System.Nullable<decimal> Balance
        {
            get
            {
                return this._Balance;
            }
            set
            {
                if ((this._Balance != value))
                {
                    this._Balance = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyId
        {
            get
            {
                return this._CompanyId;
            }
            set
            {
                if ((this._CompanyId != value))
                {
                    this._CompanyId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsBalance", DbType = "Bit")]
        public System.Nullable<bool> IsBalance
        {
            get
            {
                return this._IsBalance;
            }
            set
            {
                if ((this._IsBalance != value))
                {
                    this._IsBalance = value;
                }
            }
        }
    }

    public partial class GetAccountBalanceResult
    {

        private string _AccountId;

        private string _Name;

        private decimal _Debit;

        private decimal _Credit;

        private string _Currency;

        public GetAccountBalanceResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string AccountId
        {
            get
            {
                return this._AccountId;
            }
            set
            {
                if ((this._AccountId != value))
                {
                    this._AccountId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this._Name = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Debit", DbType = "Decimal(18,2) NOT NULL")]
        public decimal Debit
        {
            get
            {
                return this._Debit;
            }
            set
            {
                if ((this._Debit != value))
                {
                    this._Debit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Credit", DbType = "Decimal(18,2) NOT NULL")]
        public decimal Credit
        {
            get
            {
                return this._Credit;
            }
            set
            {
                if ((this._Credit != value))
                {
                    this._Credit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this._Currency = value;
                }
            }
        }
    }

    public partial class GetAccountBalancesResult
    {

        private string _AccountId;

        private string _Name;

        private System.Nullable<decimal> _TDebit;

        private System.Nullable<decimal> _TCredit;

        private System.Nullable<decimal> _SDebit;

        private System.Nullable<decimal> _SCredit;

        private string _Currency;

        public GetAccountBalancesResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string AccountId
        {
            get
            {
                return this._AccountId;
            }
            set
            {
                if ((this._AccountId != value))
                {
                    this._AccountId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this._Name = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TDebit", DbType = "Decimal(38,2)")]
        public System.Nullable<decimal> TDebit
        {
            get
            {
                return this._TDebit;
            }
            set
            {
                if ((this._TDebit != value))
                {
                    this._TDebit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TCredit", DbType = "Decimal(38,2)")]
        public System.Nullable<decimal> TCredit
        {
            get
            {
                return this._TCredit;
            }
            set
            {
                if ((this._TCredit != value))
                {
                    this._TCredit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SDebit", DbType = "Decimal(38,2)")]
        public System.Nullable<decimal> SDebit
        {
            get
            {
                return this._SDebit;
            }
            set
            {
                if ((this._SDebit != value))
                {
                    this._SDebit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SCredit", DbType = "Decimal(38,2)")]
        public System.Nullable<decimal> SCredit
        {
            get
            {
                return this._SCredit;
            }
            set
            {
                if ((this._SCredit != value))
                {
                    this._SCredit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this._Currency = value;
                }
            }
        }
    }

    public partial class GetBalanceSheetChildrenResult
    {

        private string _id;

        private string _name;

        public GetBalanceSheetChildrenResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50)")]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this._id = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(255)")]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this._name = value;
                }
            }
        }
    }

    public partial class GetChildrenResult
    {

        private string _id;

        public GetChildrenResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50)")]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this._id = value;
                }
            }
        }
    }

    public partial class GetParentsResult
    {

        private string _id;

        private string _name;

        public GetParentsResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50)")]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this._id = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(255)")]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this._name = value;
                }
            }
        }
    }

    public partial class GetFiscalYearsResult
    {

        private string _CompanyId;

        private string _CStart;

        private string _CEnd;

        private string _OStart;

        private string _OEnd;

        public GetFiscalYearsResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyId", DbType = "NVarChar(50)")]
        public string CompanyId
        {
            get
            {
                return this._CompanyId;
            }
            set
            {
                if ((this._CompanyId != value))
                {
                    this._CompanyId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CStart", DbType = "NChar(6)")]
        public string CStart
        {
            get
            {
                return this._CStart;
            }
            set
            {
                if ((this._CStart != value))
                {
                    this._CStart = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CEnd", DbType = "NChar(6)")]
        public string CEnd
        {
            get
            {
                return this._CEnd;
            }
            set
            {
                if ((this._CEnd != value))
                {
                    this._CEnd = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OStart", DbType = "NChar(6)")]
        public string OStart
        {
            get
            {
                return this._OStart;
            }
            set
            {
                if ((this._OStart != value))
                {
                    this._OStart = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OEnd", DbType = "NChar(6)")]
        public string OEnd
        {
            get
            {
                return this._OEnd;
            }
            set
            {
                if ((this._OEnd != value))
                {
                    this._OEnd = value;
                }
            }
        }
    }

    public partial class CloseFiscalYearResult
    {

        private int _Id;

        private string _Name;

        private string _AccountId;

        private string _Periode;

        private decimal _Debit;

        private decimal _Credit;

        private string _CompanyID;

        private string _Currency;

        private decimal _InitialBalance;

        private decimal _FinalBalance;

        private string _oYear;

        private string _oMonth;

        public CloseFiscalYearResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", DbType = "Int NOT NULL")]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this._Id = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Name", DbType = "NVarChar(255) NOT NULL", CanBeNull = false)]
        public string Name
        {
            get
            {
                return this._Name;
            }
            set
            {
                if ((this._Name != value))
                {
                    this._Name = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string AccountId
        {
            get
            {
                return this._AccountId;
            }
            set
            {
                if ((this._AccountId != value))
                {
                    this._AccountId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Periode", DbType = "NChar(6) NOT NULL", CanBeNull = false)]
        public string Periode
        {
            get
            {
                return this._Periode;
            }
            set
            {
                if ((this._Periode != value))
                {
                    this._Periode = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Debit", DbType = "Decimal(18,2) NOT NULL")]
        public decimal Debit
        {
            get
            {
                return this._Debit;
            }
            set
            {
                if ((this._Debit != value))
                {
                    this._Debit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Credit", DbType = "Decimal(18,2) NOT NULL")]
        public decimal Credit
        {
            get
            {
                return this._Credit;
            }
            set
            {
                if ((this._Credit != value))
                {
                    this._Credit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this._CompanyID = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this._Currency = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_InitialBalance", DbType = "Decimal(18,2) NOT NULL")]
        public decimal InitialBalance
        {
            get
            {
                return this._InitialBalance;
            }
            set
            {
                if ((this._InitialBalance != value))
                {
                    this._InitialBalance = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FinalBalance", DbType = "Decimal(18,2) NOT NULL")]
        public decimal FinalBalance
        {
            get
            {
                return this._FinalBalance;
            }
            set
            {
                if ((this._FinalBalance != value))
                {
                    this._FinalBalance = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oYear", DbType = "Char(4)")]
        public string oYear
        {
            get
            {
                return this._oYear;
            }
            set
            {
                if ((this._oYear != value))
                {
                    this._oYear = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oMonth", DbType = "Char(2)")]
        public string oMonth
        {
            get
            {
                return this._oMonth;
            }
            set
            {
                if ((this._oMonth != value))
                {
                    this._oMonth = value;
                }
            }
        }
    }

    public partial class GetBrouillardResult
    {

        private int _Id;

        private System.DateTime _Period;

        private string _NumPiece;

        private string _AccountID;

        private System.Nullable<bool> _Side;

        private string _OAccountID;

        private string _Owner;

        private string _HeaderText;

        private System.Nullable<decimal> _Amount;

        private string _Currency;

        private string _TypeDoc;

        private string _CompanyId;

        private System.Nullable<bool> _IsValidated;

        public GetBrouillardResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", DbType = "Int NOT NULL")]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this._Id = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Period", DbType = "DateTime NOT NULL")]
        public System.DateTime Period
        {
            get
            {
                return this._Period;
            }
            set
            {
                if ((this._Period != value))
                {
                    this._Period = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_NumPiece", DbType = "NVarChar(10)")]
        public string NumPiece
        {
            get
            {
                return this._NumPiece;
            }
            set
            {
                if ((this._NumPiece != value))
                {
                    this._NumPiece = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string AccountID
        {
            get
            {
                return this._AccountID;
            }
            set
            {
                if ((this._AccountID != value))
                {
                    this._AccountID = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Side", DbType = "Bit")]
        public System.Nullable<bool> Side
        {
            get
            {
                return this._Side;
            }
            set
            {
                if ((this._Side != value))
                {
                    this._Side = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OAccountID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string OAccountID
        {
            get
            {
                return this._OAccountID;
            }
            set
            {
                if ((this._OAccountID != value))
                {
                    this._OAccountID = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Owner", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Owner
        {
            get
            {
                return this._Owner;
            }
            set
            {
                if ((this._Owner != value))
                {
                    this._Owner = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_HeaderText", DbType = "NVarChar(306) NOT NULL", CanBeNull = false)]
        public string HeaderText
        {
            get
            {
                return this._HeaderText;
            }
            set
            {
                if ((this._HeaderText != value))
                {
                    this._HeaderText = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Amount", DbType = "Money")]
        public System.Nullable<decimal> Amount
        {
            get
            {
                return this._Amount;
            }
            set
            {
                if ((this._Amount != value))
                {
                    this._Amount = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this._Currency = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TypeDoc", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string TypeDoc
        {
            get
            {
                return this._TypeDoc;
            }
            set
            {
                if ((this._TypeDoc != value))
                {
                    this._TypeDoc = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyId
        {
            get
            {
                return this._CompanyId;
            }
            set
            {
                if ((this._CompanyId != value))
                {
                    this._CompanyId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsValidated", DbType = "Bit")]
        public System.Nullable<bool> IsValidated
        {
            get
            {
                return this._IsValidated;
            }
            set
            {
                if ((this._IsValidated != value))
                {
                    this._IsValidated = value;
                }
            }
        }
    }

    public partial class PeriodicBalancesResult
    {

        private int _Id;

        private string _AccountId;

        private string _AccountName;

        private string _Periode;

        private string _OYear;

        private string _OMonth;

        private System.Nullable<decimal> _Debit;

        private System.Nullable<decimal> _Credit;

        private System.Nullable<decimal> _InitialBalance;

        private System.Nullable<decimal> _FinalBalance;

        private System.Nullable<decimal> _Balance;

        private System.Nullable<decimal> _SDebit;

        private System.Nullable<decimal> _SCredit;

        private string _Currency;

        private System.Nullable<bool> _IsBalance;

        private string _CompanyId;

        public PeriodicBalancesResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Id", DbType = "Int NOT NULL")]
        public int Id
        {
            get
            {
                return this._Id;
            }
            set
            {
                if ((this._Id != value))
                {
                    this._Id = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string AccountId
        {
            get
            {
                return this._AccountId;
            }
            set
            {
                if ((this._AccountId != value))
                {
                    this._AccountId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountName", DbType = "NVarChar(150)")]
        public string AccountName
        {
            get
            {
                return this._AccountName;
            }
            set
            {
                if ((this._AccountName != value))
                {
                    this._AccountName = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Periode", DbType = "NVarChar(16) NOT NULL", CanBeNull = false)]
        public string Periode
        {
            get
            {
                return this._Periode;
            }
            set
            {
                if ((this._Periode != value))
                {
                    this._Periode = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OYear", DbType = "NVarChar(4)")]
        public string OYear
        {
            get
            {
                return this._OYear;
            }
            set
            {
                if ((this._OYear != value))
                {
                    this._OYear = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OMonth", DbType = "NVarChar(2)")]
        public string OMonth
        {
            get
            {
                return this._OMonth;
            }
            set
            {
                if ((this._OMonth != value))
                {
                    this._OMonth = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Debit", DbType = "Money")]
        public System.Nullable<decimal> Debit
        {
            get
            {
                return this._Debit;
            }
            set
            {
                if ((this._Debit != value))
                {
                    this._Debit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Credit", DbType = "Money")]
        public System.Nullable<decimal> Credit
        {
            get
            {
                return this._Credit;
            }
            set
            {
                if ((this._Credit != value))
                {
                    this._Credit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_InitialBalance", DbType = "Money")]
        public System.Nullable<decimal> InitialBalance
        {
            get
            {
                return this._InitialBalance;
            }
            set
            {
                if ((this._InitialBalance != value))
                {
                    this._InitialBalance = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_FinalBalance", DbType = "Money")]
        public System.Nullable<decimal> FinalBalance
        {
            get
            {
                return this._FinalBalance;
            }
            set
            {
                if ((this._FinalBalance != value))
                {
                    this._FinalBalance = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Balance", DbType = "Money")]
        public System.Nullable<decimal> Balance
        {
            get
            {
                return this._Balance;
            }
            set
            {
                if ((this._Balance != value))
                {
                    this._Balance = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SDebit", DbType = "Money")]
        public System.Nullable<decimal> SDebit
        {
            get
            {
                return this._SDebit;
            }
            set
            {
                if ((this._SDebit != value))
                {
                    this._SDebit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SCredit", DbType = "Money")]
        public System.Nullable<decimal> SCredit
        {
            get
            {
                return this._SCredit;
            }
            set
            {
                if ((this._SCredit != value))
                {
                    this._SCredit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(50)")]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this._Currency = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsBalance", DbType = "Bit")]
        public System.Nullable<bool> IsBalance
        {
            get
            {
                return this._IsBalance;
            }
            set
            {
                if ((this._IsBalance != value))
                {
                    this._IsBalance = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyId
        {
            get
            {
                return this._CompanyId;
            }
            set
            {
                if ((this._CompanyId != value))
                {
                    this._CompanyId = value;
                }
            }
        }
    }

    public partial class GetChildResult
    {

        private string _ChildId;

        private string _ChildName;

        private string _ParentId;

        private string _ParentName;

        public GetChildResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ChildId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string ChildId
        {
            get
            {
                return this._ChildId;
            }
            set
            {
                if ((this._ChildId != value))
                {
                    this._ChildId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ChildName", DbType = "NVarChar(255)")]
        public string ChildName
        {
            get
            {
                return this._ChildName;
            }
            set
            {
                if ((this._ChildName != value))
                {
                    this._ChildName = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ParentId", DbType = "NVarChar(50)")]
        public string ParentId
        {
            get
            {
                return this._ParentId;
            }
            set
            {
                if ((this._ParentId != value))
                {
                    this._ParentId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ParentName", DbType = "NVarChar(255)")]
        public string ParentName
        {
            get
            {
                return this._ParentName;
            }
            set
            {
                if ((this._ParentName != value))
                {
                    this._ParentName = value;
                }
            }
        }
    }

    public partial class ClassChildrenResult
    {

        private string _id;

        private string _name;

        public ClassChildrenResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_id", DbType = "NVarChar(50)")]
        public string id
        {
            get
            {
                return this._id;
            }
            set
            {
                if ((this._id != value))
                {
                    this._id = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_name", DbType = "NVarChar(255)")]
        public string name
        {
            get
            {
                return this._name;
            }
            set
            {
                if ((this._name != value))
                {
                    this._name = value;
                }
            }
        }
    }

    public partial class ClassChildResult
    {

        private string _ChildId;

        private string _ChildName;

        private string _ParentId;

        private string _ParentName;

        public ClassChildResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ChildId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string ChildId
        {
            get
            {
                return this._ChildId;
            }
            set
            {
                if ((this._ChildId != value))
                {
                    this._ChildId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ChildName", DbType = "NVarChar(255)")]
        public string ChildName
        {
            get
            {
                return this._ChildName;
            }
            set
            {
                if ((this._ChildName != value))
                {
                    this._ChildName = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ParentId", DbType = "NVarChar(50)")]
        public string ParentId
        {
            get
            {
                return this._ParentId;
            }
            set
            {
                if ((this._ParentId != value))
                {
                    this._ParentId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ParentName", DbType = "NVarChar(255)")]
        public string ParentName
        {
            get
            {
                return this._ParentName;
            }
            set
            {
                if ((this._ParentName != value))
                {
                    this._ParentName = value;
                }
            }
        }
    }

    public partial class AccountBalanceResult
    {

        private int _ID;

        private string _ClassId;

        private string _ClassName;

        private string _SubClassId;

        private string _SubClassName;

        private string _AccountId;

        private string _AccountName;

        private System.Nullable<decimal> _TDebit;

        private System.Nullable<decimal> _TCredit;

        private System.Nullable<decimal> _SDebit;

        private System.Nullable<decimal> _SCredit;

        private string _Currency;

        private System.Nullable<decimal> _Balance;

        private string _CompanyId;

        private System.Nullable<bool> _IsBalance;

        private System.Nullable<bool> _IsResult;

        public AccountBalanceResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ID", DbType = "Int NOT NULL")]
        public int ID
        {
            get
            {
                return this._ID;
            }
            set
            {
                if ((this._ID != value))
                {
                    this._ID = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ClassId", DbType = "NVarChar(50)")]
        public string ClassId
        {
            get
            {
                return this._ClassId;
            }
            set
            {
                if ((this._ClassId != value))
                {
                    this._ClassId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ClassName", DbType = "NVarChar(150)")]
        public string ClassName
        {
            get
            {
                return this._ClassName;
            }
            set
            {
                if ((this._ClassName != value))
                {
                    this._ClassName = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SubClassId", DbType = "NVarChar(50)")]
        public string SubClassId
        {
            get
            {
                return this._SubClassId;
            }
            set
            {
                if ((this._SubClassId != value))
                {
                    this._SubClassId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SubClassName", DbType = "NVarChar(150)")]
        public string SubClassName
        {
            get
            {
                return this._SubClassName;
            }
            set
            {
                if ((this._SubClassName != value))
                {
                    this._SubClassName = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountId", DbType = "NVarChar(50)")]
        public string AccountId
        {
            get
            {
                return this._AccountId;
            }
            set
            {
                if ((this._AccountId != value))
                {
                    this._AccountId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountName", DbType = "NVarChar(150)")]
        public string AccountName
        {
            get
            {
                return this._AccountName;
            }
            set
            {
                if ((this._AccountName != value))
                {
                    this._AccountName = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TDebit", DbType = "Money")]
        public System.Nullable<decimal> TDebit
        {
            get
            {
                return this._TDebit;
            }
            set
            {
                if ((this._TDebit != value))
                {
                    this._TDebit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TCredit", DbType = "Money")]
        public System.Nullable<decimal> TCredit
        {
            get
            {
                return this._TCredit;
            }
            set
            {
                if ((this._TCredit != value))
                {
                    this._TCredit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SDebit", DbType = "Money")]
        public System.Nullable<decimal> SDebit
        {
            get
            {
                return this._SDebit;
            }
            set
            {
                if ((this._SDebit != value))
                {
                    this._SDebit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_SCredit", DbType = "Money")]
        public System.Nullable<decimal> SCredit
        {
            get
            {
                return this._SCredit;
            }
            set
            {
                if ((this._SCredit != value))
                {
                    this._SCredit = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(50)")]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this._Currency = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Balance", DbType = "Money")]
        public System.Nullable<decimal> Balance
        {
            get
            {
                return this._Balance;
            }
            set
            {
                if ((this._Balance != value))
                {
                    this._Balance = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyId", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyId
        {
            get
            {
                return this._CompanyId;
            }
            set
            {
                if ((this._CompanyId != value))
                {
                    this._CompanyId = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsBalance", DbType = "Bit")]
        public System.Nullable<bool> IsBalance
        {
            get
            {
                return this._IsBalance;
            }
            set
            {
                if ((this._IsBalance != value))
                {
                    this._IsBalance = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_IsResult", DbType = "Bit")]
        public System.Nullable<bool> IsResult
        {
            get
            {
                return this._IsResult;
            }
            set
            {
                if ((this._IsResult != value))
                {
                    this._IsResult = value;
                }
            }
        }
    }

    public partial class GetJournalResult
    {

        private int _ID;

        private int _ItemID;

        private int _OID;

        private string _LocalName;

        private string _CustSupplierID;

        private System.DateTime _TransDate;

        private string _Periode;

        private string _OYear;

        private string _oMonth;

        private string _Account;

        private string _AccountName;

        private string _OAccount;

        private string _OAccountName;

        private decimal _Amount;

        private string _Side;

        private string _Currency;

        private string _CompanyID;

        private string _Owner;

        private string _TypeJournal;

        public GetJournalResult()
        {
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ID", DbType = "Int NOT NULL")]
        public int ID
        {
            get
            {
                return this._ID;
            }
            set
            {
                if ((this._ID != value))
                {
                    this._ID = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_ItemID", DbType = "Int NOT NULL")]
        public int ItemID
        {
            get
            {
                return this._ItemID;
            }
            set
            {
                if ((this._ItemID != value))
                {
                    this._ItemID = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OID", DbType = "Int NOT NULL")]
        public int OID
        {
            get
            {
                return this._OID;
            }
            set
            {
                if ((this._OID != value))
                {
                    this._OID = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_LocalName", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string LocalName
        {
            get
            {
                return this._LocalName;
            }
            set
            {
                if ((this._LocalName != value))
                {
                    this._LocalName = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CustSupplierID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CustSupplierID
        {
            get
            {
                return this._CustSupplierID;
            }
            set
            {
                if ((this._CustSupplierID != value))
                {
                    this._CustSupplierID = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TransDate", DbType = "DateTime NOT NULL")]
        public System.DateTime TransDate
        {
            get
            {
                return this._TransDate;
            }
            set
            {
                if ((this._TransDate != value))
                {
                    this._TransDate = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Periode", DbType = "NChar(6) NOT NULL", CanBeNull = false)]
        public string Periode
        {
            get
            {
                return this._Periode;
            }
            set
            {
                if ((this._Periode != value))
                {
                    this._Periode = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OYear", DbType = "Char(4)")]
        public string OYear
        {
            get
            {
                return this._OYear;
            }
            set
            {
                if ((this._OYear != value))
                {
                    this._OYear = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_oMonth", DbType = "Char(2)")]
        public string oMonth
        {
            get
            {
                return this._oMonth;
            }
            set
            {
                if ((this._oMonth != value))
                {
                    this._oMonth = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Account", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string Account
        {
            get
            {
                return this._Account;
            }
            set
            {
                if ((this._Account != value))
                {
                    this._Account = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_AccountName", DbType = "NVarChar(150)")]
        public string AccountName
        {
            get
            {
                return this._AccountName;
            }
            set
            {
                if ((this._AccountName != value))
                {
                    this._AccountName = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OAccount", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string OAccount
        {
            get
            {
                return this._OAccount;
            }
            set
            {
                if ((this._OAccount != value))
                {
                    this._OAccount = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_OAccountName", DbType = "NVarChar(150)")]
        public string OAccountName
        {
            get
            {
                return this._OAccountName;
            }
            set
            {
                if ((this._OAccountName != value))
                {
                    this._OAccountName = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Amount", DbType = "Money NOT NULL")]
        public decimal Amount
        {
            get
            {
                return this._Amount;
            }
            set
            {
                if ((this._Amount != value))
                {
                    this._Amount = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Side", DbType = "NVarChar(6) NOT NULL", CanBeNull = false)]
        public string Side
        {
            get
            {
                return this._Side;
            }
            set
            {
                if ((this._Side != value))
                {
                    this._Side = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Currency", DbType = "NVarChar(10) NOT NULL", CanBeNull = false)]
        public string Currency
        {
            get
            {
                return this._Currency;
            }
            set
            {
                if ((this._Currency != value))
                {
                    this._Currency = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_CompanyID", DbType = "NVarChar(50) NOT NULL", CanBeNull = false)]
        public string CompanyID
        {
            get
            {
                return this._CompanyID;
            }
            set
            {
                if ((this._CompanyID != value))
                {
                    this._CompanyID = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_Owner", DbType = "NVarChar(150)")]
        public string Owner
        {
            get
            {
                return this._Owner;
            }
            set
            {
                if ((this._Owner != value))
                {
                    this._Owner = value;
                }
            }
        }

        [global::System.Data.Linq.Mapping.ColumnAttribute(Storage = "_TypeJournal", DbType = "VarChar(50)")]
        public string TypeJournal
        {
            get
            {
                return this._TypeJournal;
            }
            set
            {
                if ((this._TypeJournal != value))
                {
                    this._TypeJournal = value;
                }
            }
        }
    }
}
