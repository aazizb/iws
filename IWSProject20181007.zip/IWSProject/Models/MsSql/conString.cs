﻿namespace IWSProject.Models.MsSql
{
    #region connectionstring
    /*

    public IWSDataContext() :
    base(global::System.Configuration.ConfigurationManager.ConnectionStrings["IWSConnectionString"].ConnectionString, mappingSource)
    {
        OnCreated();
    }
    public IWSDataContext(string connection) :
            base(connection, mappingSource)
    {
        OnCreated();
    }
    public IWSDataContext(IDbConnection connection) :
            base(connection, mappingSource)
    {
        OnCreated();
    }
    public IWSDataContext(string connection, MappingSource mappingSource) :
            base(connection, mappingSource)
    {
        OnCreated();
    }
    public IWSDataContext(IDbConnection connection, MappingSource mappingSource) :
            base(connection, mappingSource)
    {
        OnCreated();
    }
    
     */
    #endregion
}